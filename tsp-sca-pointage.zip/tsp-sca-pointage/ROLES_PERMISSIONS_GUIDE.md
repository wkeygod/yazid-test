# Guide d'utilisation : Système de Gestion des Rôles et Permissions

## Installation et initialisation

### 1. Exécuter les migrations
```bash
php artisan migrate
```

### 2. Seeder les permissions (automatique)
Les permissions sont auto-créées avec les migrations. Pour re-seeder :
```bash
php artisan db:seed --class=PermissionSeeder
```

### 3. Accès à la page de gestion des rôles
- URL : `http://localhost:8000/roles`
- Accès : **Admin uniquement**
- Route : `roles.index`

## Utilisation

### Pour ajouter un utilisateur

1. Connectez-vous en tant qu'administrateur
2. Allez à **Système → Gestion des rôles**
3. Cliquez sur **Ajouter un utilisateur**
4. Remplissez le formulaire :
   - **Prénom** : Le prénom de l'utilisateur
   - **Nom** : Le nom de famille
   - **Email** : Email unique pour la connexion
   - **Mot de passe** : Minimum 8 caractères
   - **Pages autorisées** : Cochez les pages accessibles
5. Cliquez sur **Ajouter l'utilisateur**

### Pour modifier un utilisateur

1. Allez à **Système → Gestion des rôles**
2. Cliquez sur le bouton **✏️ Éditer** dans la ligne de l'utilisateur
3. Modifiez les informations
4. Modifiez les permissions si nécessaire
5. Cliquez sur **Mettre à jour l'utilisateur**

### Pour supprimer un utilisateur

1. Allez à **Système → Gestion des rôles**
2. Cliquez sur le bouton **🗑️ Supprimer** dans la ligne de l'utilisateur
3. Confirmez la suppression dans le dialog
4. L'utilisateur et ses permissions sont supprimés

## Pages et permissions disponibles

| Page | Slug | Description |
|------|------|-------------|
| Tableau de bord | `dashboard.index` | Page principale d'administration |
| Gestion employés | `employees.index` | Gestion des employés (NFC) |
| Historique employes | `employee-history.index` | Historique des employés |
| Historique global repas | `meal-logs.index` | Vue unifiée des repas (NFC, La Relève, Extra) |
| Gestion des règles | `meal-rules.index` | Configuration des règles de repas |
| Historique La Relève | `la-releve.index` | Gestion des accès manuels |
| Historique Extra | `extra.index` | Gestion des extras |
| Rapports | `reports.index` | Rapports et tendances |
| Catalogue système | `system-catalog.index` | Configuration système |
| Départements | `departments.index` | Gestion des départements |
| Appareils | `devices.index` | Gestion des bornes/lecteurs de pointage |
| Kiosque | `kiosk.index` | Accès au kiosque de pointage |

## Comportement spécial

### Redirection automatique
- Si un utilisateur n'a accès qu'à **une seule page**, il sera redirigé directement vers celle-ci à la connexion
- Exemple : Un utilisateur avec accès uniquement au Kiosque sera automatiquement redirigé vers `/kiosk`

### Navigation filtrée
- Les utilisateurs non-admin ne voient que les pages pour lesquelles ils ont des permissions
- Les admins voient toutes les pages

## UX et dialogues

### Formulaire modal d'ajout/modification
- Formulaire moderne avec bootstrap
- Liste scrollable des permissions
- Validation côté client et serveur
- Messages d'erreur détaillés

### Dialog de confirmation
- Confirmation avant suppression d'un utilisateur
- Affiche le nom de l'utilisateur à supprimer
- Design intuitif avec couleur d'alerte

### Notifications
- Messages de succès/erreur automatiques
- Disparaissent après 5 secondes
- Rechargement de la page après création/modification réussie

## Architecture technique

### Middleware `check_permission`
Chaque route protégée par permissions utilise le middleware :
```blade
Route::get('page', Controller@action)
    ->middleware('check_permission:page.slug')
    ->name('page.name');
```

### Vérification des permissions dans le code
```php
// Dans un contrôleur ou vue
if ($user->hasPermission('page.slug')) {
    // Accès autorisé
}

// Obtenir toutes les pages accessibles
$pages = $user->getAccessiblePages(); // ['page1.slug', 'page2.slug']
```

### Relation de données
- Un utilisateur peut avoir **un seul rôle personnalisé**
- Un rôle peut avoir **plusieurs permissions**
- Les permissions sont uniques par page

## Dépannage

### L'utilisateur ne peut pas accéder à une page
1. Vérifiez que l'utilisateur a la permission assignée
2. Vérifiez que le middleware est correctement appliqué à la route
3. Vérifiez que la base de données a la permission enregistrée

### Le formulaire modal ne s'ouvre pas
- Vérifiez que Bootstrap 5 CSS/JS est chargé
- Vérifiez la console du navigateur pour les erreurs JavaScript

### Les permissions ne changent pas après modification
- Rafraîchissez la page (Ctrl+F5)
- Vérifiez que la requête PUT/PATCH a réussi (200 OK)

## Exemple d'utilisation complète

### Scénario : Créer un utilisateur Kiosque uniquement

1. Connexion en tant qu'admin
2. Aller à **Système → Gestion des rôles**
3. **Ajouter un utilisateur** :
   - Prénom : `Jean`
   - Nom : `Pointeur`
   - Email : `jean.pointeur@example.com`
   - Mot de passe : `SecurePassword123`
   - Pages : ✓ Kiosque (seulement)
4. Cliquer **Ajouter l'utilisateur**
5. L'utilisateur reçoit ses identifiants
6. À la prochaine connexion, il accédera directement au Kiosque

### Scénario : Créer un utilisateur avec accès complet (sauf admin)

1. Ajouter un utilisateur
2. Sélectionner **TOUTES** les pages excepté la gestion des rôles
3. L'utilisateur aura accès à tout le système sauf la gestion des utilisateurs

## Sécurité

- ✅ Les mots de passe sont hashés avec bcrypt
- ✅ Seul un admin peut gérer les rôles et utilisateurs
- ✅ Middleware de vérification des permissions sur toutes les routes
- ✅ CSRF protection sur tous les formulaires
- ✅ Validation des données côté serveur
- ✅ Les utilisateurs ne peuvent pas modifier leurs propres permissions via l'API

## Notes importantes

1. **Gestion des rôles** : Chaque utilisateur non-admin a automatiquement un rôle personnalisé créé
2. **Suppression** : Supprimer un utilisateur supprime aussi son rôle associé
3. **Email unique** : Chaque utilisateur doit avoir un email unique
4. **Mot de passe** : Minimum 8 caractères, hash automatique avec bcrypt
5. **Permissions** : Les permissions ne peuvent pas être modifiées mais seulement assignées à des utilisateurs
