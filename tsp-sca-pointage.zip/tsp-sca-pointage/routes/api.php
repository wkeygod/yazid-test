<?php

use App\Http\Controllers\Api\CardScanController;
use App\Http\Controllers\Api\MealCheckController;
use Illuminate\Support\Facades\Route;

Route::post('/scan/validate', [CardScanController::class, 'validateScan']);
Route::post('/meal/check', [MealCheckController::class, 'check']);
