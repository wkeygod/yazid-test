<?php

use App\Http\Controllers\CardController;
use App\Http\Controllers\Auth\AdminAuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\DeviceController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\EmployeeHistoryController;
use App\Http\Controllers\ExtraDashboardController;
use App\Http\Controllers\KioskController;
use App\Http\Controllers\LaReleveController;
use App\Http\Controllers\MealLogController;
use App\Http\Controllers\MealRuleController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\SystemCatalogController;
use Illuminate\Support\Facades\Route;

Route::redirect('/', '/dashboard')->middleware('auth')->name('home');

Route::middleware('guest')->group(function (): void {
    Route::get('/login', [AdminAuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AdminAuthController::class, 'login'])->name('login.attempt');
});

Route::post('/logout', [AdminAuthController::class, 'logout'])
    ->middleware('auth')
    ->name('logout');

Route::view('/welcome', 'welcome')->name('welcome');


// User permission-based routes (authenticated users with permissions)

Route::middleware(['auth'])->group(function (): void {
    // Dashboard
    Route::get('dashboard', [DashboardController::class, 'index'])
        ->middleware('check_permission:dashboard.index')
        ->name('dashboard.index');

    // Employees
    Route::middleware('check_permission:employees.index')->group(function (): void {
        Route::resource('employees', EmployeeController::class);
        Route::patch('employees/{employee}/toggle-status', [EmployeeController::class, 'toggleStatus'])->name('employees.toggle-status');
        Route::patch('employees/{employee}/deactivate', [EmployeeController::class, 'deactivate'])->name('employees.deactivate');
        Route::patch('employees/{employee}/reactivate', [EmployeeController::class, 'reactivate'])->name('employees.reactivate');
        Route::patch('cards/{card}/block', [CardController::class, 'block'])->name('cards.block');
        Route::patch('cards/{card}/unblock', [CardController::class, 'unblock'])->name('cards.unblock');
        Route::patch('cards/{card}/mark-lost', [CardController::class, 'markLost'])->name('cards.mark-lost');
        Route::patch('cards/{card}/detach', [CardController::class, 'detach'])->name('cards.detach');
        Route::patch('cards/{card}/reassign', [CardController::class, 'reassign'])->name('cards.reassign');
        Route::post('cards/{card}/replace', [CardController::class, 'replace'])->name('cards.replace');
    });

    // Employee History
    Route::get('employee-history', [EmployeeHistoryController::class, 'index'])
        ->middleware('check_permission:employee-history.index')
        ->name('employee-history.index');
    Route::get('employee-history/export', [EmployeeHistoryController::class, 'export'])
        ->middleware('check_permission:employee-history.index')
        ->name('employee-history.export');

    // Meal Rules
    Route::middleware('check_permission:meal-rules.index')->group(function (): void {
        Route::resource('meal-rules', MealRuleController::class);
    });

    // Meal Logs
    Route::get('meal-logs', [MealLogController::class, 'index'])
        ->middleware('check_permission:meal-logs.index')
        ->name('meal-logs.index');
    Route::get('meal-logs/export', [MealLogController::class, 'export'])
        ->middleware('check_permission:meal-logs.index')
        ->name('meal-logs.export');
    Route::delete('meal-logs/{mealLog}', [MealLogController::class, 'destroy'])
        ->middleware('check_permission:meal-logs.index')
        ->name('meal-logs.destroy');

    // La Releve
    Route::middleware('check_permission:la-releve.index')->group(function (): void {
        Route::get('la-releve/import', [LaReleveController::class, 'showImport'])->name('la-releve.import');
        Route::post('la-releve/import', [LaReleveController::class, 'import'])->name('la-releve.import.store');
        Route::resource('la-releve', LaReleveController::class)
            ->parameters(['la-releve' => 'laReleveEntry'])
            ->except(['show']);
        Route::get('la-releve/export', [LaReleveController::class, 'export'])->name('la-releve.export');
    });

    // Extra
    Route::get('extra', [ExtraDashboardController::class, 'index'])
        ->middleware('check_permission:extra.index')
        ->name('extra.index');
    Route::get('extra/export', [ExtraDashboardController::class, 'export'])
        ->middleware('check_permission:extra.index')
        ->name('extra.export');

    // Reports
    Route::get('reports', [ReportController::class, 'index'])
        ->middleware('check_permission:reports.index')
        ->name('reports.index');
    Route::get('reports/export', [ReportController::class, 'export'])
        ->middleware('check_permission:reports.index')
        ->name('reports.export');

    // System Catalog
    Route::get('system-catalog', [SystemCatalogController::class, 'index'])
        ->middleware('check_permission:system-catalog.index')
        ->name('system-catalog.index');

    // Departments
    Route::middleware('check_permission:departments.index')->group(function (): void {
        Route::resource('departments', DepartmentController::class)
            ->except(['show']);
    });

    // Devices
    Route::middleware('check_permission:devices.index')->group(function (): void {
        Route::resource('devices', DeviceController::class)
            ->except(['show']);
    });

    // Roles
    Route::middleware('check_permission:roles.index')->group(function (): void {
        Route::resource('roles', RoleController::class)
            ->parameters(['roles' => 'user'])
            ->only(['index', 'create', 'store', 'show', 'edit', 'update', 'destroy']);
    });

    // Kiosk (no admin check)
    Route::get('kiosk', [KioskController::class, 'index'])
        ->middleware('check_permission:kiosk.index')
        ->name('kiosk.index');
    Route::get('kiosk/la-releve', [KioskController::class, 'laRelevePage'])
        ->middleware('check_permission:kiosk.index')
        ->name('kiosk.la-releve.page');
    Route::get('kiosk/extra', [KioskController::class, 'extraPage'])
        ->middleware('check_permission:kiosk.index')
        ->name('kiosk.extra.page');
    Route::post('kiosk/scan', [KioskController::class, 'scan'])
        ->middleware('check_permission:kiosk.index')
        ->name('kiosk.scan');
    Route::post('kiosk/la-releve/search', [KioskController::class, 'searchLaReleve'])
        ->middleware('check_permission:kiosk.index')
        ->name('kiosk.la-releve.search');
    Route::post('kiosk/la-releve/consume', [KioskController::class, 'consumeLaReleve'])
        ->middleware('check_permission:kiosk.index')
        ->name('kiosk.la-releve.consume');
    Route::post('kiosk/la-releve/toggle', [KioskController::class, 'toggleLaReleve'])
        ->middleware('check_permission:kiosk.index')
        ->name('kiosk.la-releve.toggle');
    Route::post('kiosk/extra/toggle', [KioskController::class, 'toggleExtra'])
        ->middleware('check_permission:kiosk.index')
        ->name('kiosk.extra.toggle');
    Route::post('kiosk/extra/store', [KioskController::class, 'storeExtra'])
        ->middleware('check_permission:kiosk.index')
        ->name('kiosk.extra.store');
    Route::get('kiosk/extra/suggest', [KioskController::class, 'suggestExtraNames'])
        ->middleware('check_permission:kiosk.index')
        ->name('kiosk.extra.suggest');
});
