<div <?php echo e($attributes->class(['table-actions', 'ds-table-actions'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\xampp\htdocs\TSP-Restaurant-pointage\resources\views/components/admin/table-actions.blade.php ENDPATH**/ ?>