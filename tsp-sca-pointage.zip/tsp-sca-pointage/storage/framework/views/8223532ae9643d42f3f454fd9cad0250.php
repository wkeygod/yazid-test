<?php $__env->startSection('title', 'Fiche employe'); ?>
<?php $__env->startSection('topbar_actions'); ?>
    <a class="btn" href="<?php echo e(route('employees.edit', $employee)); ?>">Modifier</a>
    <a class="btn btn-secondary" href="<?php echo e(route('employees.index')); ?>">Retour liste</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $cardStatusTone = match($employee->card?->status) {
            \App\Models\Card::STATUS_ACTIVE => 'active',
            \App\Models\Card::STATUS_BLOCKED, \App\Models\Card::STATUS_LOST => 'warning',
            \App\Models\Card::STATUS_REPLACED => 'info',
            \App\Models\Card::STATUS_INACTIVE => 'inactive',
            default => 'inactive',
        };
    ?>

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Fiche employe','subtitle' => trim($employee->first_name . ' ' . $employee->last_name)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Fiche employe','subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(trim($employee->first_name . ' ' . $employee->last_name))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <div class="grid" style="grid-template-columns:minmax(0, 1fr) 340px; align-items:start; gap:1rem;">
        <div style="min-width:0;">
            <div class="card" style="background:linear-gradient(120deg, #e6f0ff, #f7fbff); border-color:#c9dbf3;">
                <div class="panel-header" style="margin-bottom:0; align-items:flex-start;">
                    <div>
                        <div style="font-size:.82rem; letter-spacing:.6px; color:#48607d; text-transform:uppercase; font-weight:700;">Identite employe</div>
                        <h2 style="margin:.2rem 0 0;"><?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?></h2>
                        <div class="muted" style="margin-top:.2rem;">Profil employe NFC</div>
                    </div>
                    <?php if (isset($component)) { $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.badge','data' => ['tone' => $employee->is_active ? 'active' : 'inactive']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($employee->is_active ? 'active' : 'inactive')]); ?>
                        <?php echo e($employee->is_active ? 'ACTIF' : 'INACTIF'); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $attributes = $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $component = $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
                </div>
            </div>

            <div class="card">
                <h3 style="margin-top:0;">Informations courantes</h3>
                <?php if (isset($component)) { $__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.data-table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <tbody>
                    <tr>
                        <th style="width:220px;">Nom complet</th>
                        <td><?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?></td>
                    </tr>
                    <tr>
                        <th>Poste</th>
                        <td><?php echo e($employee->position ?: '-'); ?></td>
                    </tr>
                    <tr>
                        <th>RiG (entreprise)</th>
                        <td><?php echo e($employee->rig_company ?: '-'); ?></td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td><?php echo e($employee->user?->email ?: '-'); ?></td>
                    </tr>
                    <tr>
                        <th>Carte actuelle</th>
                        <td>
                            <?php if($employee->card): ?>
                                <span style="font-weight:700;"><?php echo e($employee->card->uid); ?></span>
                                <?php if (isset($component)) { $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.badge','data' => ['tone' => $cardStatusTone,'style' => 'margin-left:.4rem;']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($cardStatusTone),'style' => 'margin-left:.4rem;']); ?>
                                    <?php echo e(strtoupper(str_replace('_', ' ', $employee->card->status))); ?>

                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $attributes = $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $component = $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
                            <?php else: ?>
                                <?php if (isset($component)) { $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.badge','data' => ['tone' => 'inactive']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'inactive']); ?>AUCUNE <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $attributes = $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $component = $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Dernier repas</th>
                        <td>
                            <?php if($employee->lastMealLog): ?>
                                <?php echo e($employee->lastMealLog->logged_at?->format('Y-m-d H:i:s') ?: '-'); ?>

                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                    </tr>
                    </tbody>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0)): ?>
<?php $attributes = $__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0; ?>
<?php unset($__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0)): ?>
<?php $component = $__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0; ?>
<?php unset($__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0); ?>
<?php endif; ?>
            </div>

            <div class="card">
                <div class="panel-header">
                    <h3 style="margin:0;">Logs repas recents</h3>
                    <a class="btn-action" style="background:#3f6bb5;" href="<?php echo e(route('meal-logs.index', ['employee_id' => $employee->id])); ?>">Voir tous</a>
                </div>

                <?php if (isset($component)) { $__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.data-table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <thead>
                        <tr>
                            <th>Date/Heure</th>
                            <th>Carte</th>
                            <th>Resultat</th>
                            <th>Motif</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $employee->mealLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($log->logged_at?->format('Y-m-d H:i:s') ?: '-'); ?></td>
                                <td>
                                    <?php if($log->card): ?>
                                        <?php echo e($log->card->uid); ?>

                                    <?php else: ?>
                                        <?php echo e($log->card_uid ?: '-'); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (isset($component)) { $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.badge','data' => ['tone' => $log->status === 'approved' ? 'approved' : 'rejected']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($log->status === 'approved' ? 'approved' : 'rejected')]); ?>
                                        <?php echo e($log->status === 'approved' ? 'AUTORISE' : 'REFUSE'); ?>

                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $attributes = $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $component = $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
                                </td>
                                <td><?php echo e($log->reason ?: '-'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5">
                                    <?php if (isset($component)) { $__componentOriginal99089f8e2ef4184d7d35db81d60c6521 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.empty-state','data' => ['title' => 'Aucun historique repas','message' => 'Cet employe n\'a pas encore de passages enregistres.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Aucun historique repas','message' => 'Cet employe n\'a pas encore de passages enregistres.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $attributes = $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $component = $__componentOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0)): ?>
<?php $attributes = $__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0; ?>
<?php unset($__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0)): ?>
<?php $component = $__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0; ?>
<?php unset($__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0); ?>
<?php endif; ?>
            </div>

            <div class="card">
                <h3 style="margin-top:0;">Historique cartes</h3>
                <?php if($cardHistory->isEmpty()): ?>
                    <?php if (isset($component)) { $__componentOriginal99089f8e2ef4184d7d35db81d60c6521 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.empty-state','data' => ['title' => 'Aucun historique carte','message' => 'Aucune carte n\'a encore ete attribuee ou remplacee.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Aucun historique carte','message' => 'Aucune carte n\'a encore ete attribuee ou remplacee.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $attributes = $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $component = $__componentOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
                <?php else: ?>
                    <?php if (isset($component)) { $__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.data-table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <thead>
                            <tr>
                                <th>Carte</th>
                                <th>Assignee le</th>
                                <th>Retiree le</th>
                                <th>Par</th>
                                <th>Motif</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $cardHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php if($item->card): ?>
                                            <?php echo e($item->card->uid); ?>

                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($item->assigned_at?->format('Y-m-d H:i:s') ?: '-'); ?></td>
                                    <td><?php echo e($item->unassigned_at?->format('Y-m-d H:i:s') ?: '-'); ?></td>
                                    <td><?php echo e($item->changedBy?->name ?: '-'); ?></td>
                                    <td><?php echo e($item->change_reason ?: '-'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0)): ?>
<?php $attributes = $__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0; ?>
<?php unset($__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0)): ?>
<?php $component = $__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0; ?>
<?php unset($__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0); ?>
<?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

        <aside class="card" style="position:sticky; top:82px;">
            <h3 style="margin-top:0;">Actions</h3>

            <div style="display:grid; gap:.55rem;">
                <a class="btn" href="<?php echo e(route('employees.edit', $employee)); ?>">Modifier employe</a>

                <?php if($employee->is_active): ?>
                    <form method="POST" action="<?php echo e(route('employees.deactivate', $employee)); ?>"
                          data-confirm="true"
                          data-confirm-type="warning"
                          data-confirm-title="Desactiver employe : <?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>"
                          data-confirm-message="Confirmer la desactivation de cet employe ? Il ne pourra plus utiliser sa carte."
                          data-confirm-cancel-label="Annuler"
                          data-confirm-approve-label="Confirmer">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <input type="text" name="reason" placeholder="Motif desactivation (optionnel)">
                        <button class="btn" type="submit" style="width:100%; background:#566f8f;">
                            Desactiver
                        </button>
                    </form>
                <?php else: ?>
                    <form method="POST" action="<?php echo e(route('employees.reactivate', $employee)); ?>"
                          data-confirm="true"
                          data-confirm-type="info"
                          data-confirm-title="Reactiver employe"
                          data-confirm-message="Confirmer la reactivation de cet employe ?">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <input type="text" name="reason" placeholder="Motif reactivation (optionnel)">
                        <button class="btn" type="submit" style="width:100%; background:#2b8a3e;">
                            Reactiver
                        </button>
                    </form>
                <?php endif; ?>

                <?php if($employee->card): ?>
                    <a class="btn" style="background:#1f8f4e;" href="<?php echo e(route('employees.edit', $employee)); ?>">Modifier UID NFC</a>
                <?php else: ?>
                    <a class="btn" style="background:#1f8f4e;" href="<?php echo e(route('employees.edit', $employee)); ?>">Assigner UID NFC</a>
                <?php endif; ?>

                <?php if($employee->card): ?>
                    <form method="POST" action="<?php echo e(route('cards.block', $employee->card)); ?>"
                          data-confirm="true"
                          data-confirm-type="danger"
                          data-confirm-title="Bloquer carte"
                          data-confirm-message="Confirmer le blocage de la carte actuelle ?">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <input type="text" name="block_reason" placeholder="Motif blocage" required>
                        <button class="btn" type="submit" style="width:100%; background:#c53030;">Bloquer carte actuelle</button>
                    </form>

                    <?php if($employee->card->status === \App\Models\Card::STATUS_BLOCKED): ?>
                        <form method="POST" action="<?php echo e(route('cards.unblock', $employee->card)); ?>"
                              data-confirm="true"
                              data-confirm-type="warning"
                              data-confirm-title="Debloquer carte"
                              data-confirm-message="Confirmer le debloquage de la carte actuelle ?">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button class="btn" type="submit" style="width:100%; background:#2b8a3e;">Debloquer carte actuelle</button>
                        </form>
                    <?php endif; ?>

                    <?php if($employee->card->status !== \App\Models\Card::STATUS_LOST): ?>
                        <form method="POST" action="<?php echo e(route('cards.mark-lost', $employee->card)); ?>"
                              data-confirm="true"
                              data-confirm-type="danger"
                              data-confirm-title="Marquer carte perdue"
                              data-confirm-message="Confirmer le passage de la carte au statut perdue ?">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <input type="text" name="block_reason" placeholder="Motif carte perdue" required>
                            <button class="btn" type="submit" style="width:100%; background:#8b1f1f;">Marquer carte perdue</button>
                        </form>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('cards.replace', $employee->card)); ?>"
                          data-confirm="true"
                          data-confirm-type="warning"
                          data-confirm-title="Remplacer carte"
                          data-confirm-message="Confirmer le remplacement de la carte actuelle ?">
                        <?php echo csrf_field(); ?>
                        <input type="text" name="new_uid" placeholder="Nouveau UID carte" required>
                        <input type="hidden" name="employee_id" value="<?php echo e($employee->id); ?>">
                        <input type="text" name="reason" placeholder="Motif remplacement (optionnel)">
                        <button class="btn" type="submit" style="width:100%; background:#5f3dc4;">Remplacer carte</button>
                    </form>
                <?php endif; ?>

                <a class="btn" style="background:#3f6bb5;" href="<?php echo e(route('meal-logs.index', ['employee_id' => $employee->id])); ?>">Voir tous les logs</a>
            </div>

            <?php if($availableCards->isNotEmpty()): ?>
                <hr>
                <h4 style="margin-top:0;">Assigner une carte disponible</h4>
                <form method="POST" action="<?php echo e(route('cards.reassign', $employee->card ?? $availableCards->first())); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <label>Selection</label>
                    <select id="card_select_action" required>
                        <?php $__currentLoopData = $availableCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e(route('cards.reassign', $candidate)); ?>"><?php echo e($candidate->uid); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input type="hidden" name="employee_id" value="<?php echo e($employee->id); ?>">
                    <button class="btn" type="submit" style="width:100%;">Assigner</button>
                </form>
                <script>
                    (function () {
                        var form = document.currentScript.previousElementSibling;
                        var select = document.getElementById('card_select_action');
                        if (form && select) {
                            form.addEventListener('submit', function () {
                                form.action = select.value;
                            });
                        }
                    })();
                </script>
            <?php endif; ?>
        </aside>
    </div>

    <div class="card">
        <h3 style="margin-top:0;">Journal d'audit des actions admin</h3>
        <?php if($auditLogs->isEmpty()): ?>
            <?php if (isset($component)) { $__componentOriginal99089f8e2ef4184d7d35db81d60c6521 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.empty-state','data' => ['title' => 'Aucune action admin','message' => 'Aucun evenement administratif n\'a ete enregistre pour ce profil.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Aucune action admin','message' => 'Aucun evenement administratif n\'a ete enregistre pour ce profil.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $attributes = $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $component = $__componentOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
        <?php else: ?>
            <?php if (isset($component)) { $__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.data-table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Action</th>
                        <th>Admin</th>
                        <th>Motif</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $auditLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(optional($entry->performed_at)->format('Y-m-d H:i:s') ?: '-'); ?></td>
                            <td><?php echo e($entry->action_type); ?></td>
                            <td><?php echo e($entry->performedBy?->name ?? '-'); ?></td>
                            <td><?php echo e($entry->reason ?: '-'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0)): ?>
<?php $attributes = $__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0; ?>
<?php unset($__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0)): ?>
<?php $component = $__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0; ?>
<?php unset($__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0); ?>
<?php endif; ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/employees/show.blade.php ENDPATH**/ ?>