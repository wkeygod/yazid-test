<?php $__env->startSection('content'); ?>
<div style="max-width: 1400px; margin: 0 auto; padding: 2rem 1.5rem;">
    <!-- Header -->
    <div style="margin-bottom: 3rem; border-bottom: 2px solid #10639a; padding-bottom: 1.5rem;">
        <h1 style="font-size: 2.5rem; font-weight: 700; color: #11669c; margin-bottom: 0.5rem;">
            📋 Catalogue du Système
        </h1>
        <p style="font-size: 1rem; color: #666; margin-bottom: 1rem;">
            Documentation complète de la logique et de l'architecture du système de gestion de repas
        </p>
        <div style="display: flex; gap: 1rem; flex-wrap: wrap; font-size: 0.9rem;">
            <span style="background: #e8f4f8; padding: 0.5rem 1rem; border-radius: 0.5rem; color: #0d5a7f;">
                ✓ Version 1.0 - TSP Restaurant Pointage
            </span>
            <span style="background: #f0f8e8; padding: 0.5rem 1rem; border-radius: 0.5rem; color: #3a6b2a;">
                Last Updated: <?php echo e(now()->format('d/m/Y H:i')); ?>

            </span>
        </div>
    </div>

    <!-- Stats Cards -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1.5rem; margin-bottom: 3rem;">
        <div style="background: linear-gradient(135deg, #11669c 0%, #1a79b8 100%); padding: 1.5rem; border-radius: 1rem; color: white; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
            <div style="font-size: 0.85rem; opacity: 0.9; margin-bottom: 0.5rem;">Employés Actifs</div>
            <div style="font-size: 2rem; font-weight: 700;"><?php echo e($stats['employees']); ?></div>
        </div>
        <div style="background: linear-gradient(135deg, #18a870 0%, #12845b 100%); padding: 1.5rem; border-radius: 1rem; color: white; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
            <div style="font-size: 0.85rem; opacity: 0.9; margin-bottom: 0.5rem;">Entrées La Relève</div>
            <div style="font-size: 2rem; font-weight: 700;"><?php echo e($stats['la_releve_entries']); ?></div>
        </div>
        <div style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); padding: 1.5rem; border-radius: 1rem; color: white; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
            <div style="font-size: 0.85rem; opacity: 0.9; margin-bottom: 0.5rem;">Cartes Actives</div>
            <div style="font-size: 2rem; font-weight: 700;"><?php echo e($stats['active_cards']); ?>/<?php echo e($stats['cards']); ?></div>
        </div>
        <div style="background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); padding: 1.5rem; border-radius: 1rem; color: white; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
            <div style="font-size: 0.85rem; opacity: 0.9; margin-bottom: 0.5rem;">Règles de Repas</div>
            <div style="font-size: 2rem; font-weight: 700;"><?php echo e($stats['active_meal_rules']); ?>/<?php echo e($stats['meal_rules']); ?></div>
        </div>
        <div style="background: linear-gradient(135deg, #ec4899 0%, #db2777 100%); padding: 1.5rem; border-radius: 1rem; color: white; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
            <div style="font-size: 0.85rem; opacity: 0.9; margin-bottom: 0.5rem;">Logs de Repas</div>
            <div style="font-size: 2rem; font-weight: 700;"><?php echo e($stats['total_meal_logs']); ?></div>
        </div>
        <div style="background: linear-gradient(135deg, #06b6d4 0%, #0891b2 100%); padding: 1.5rem; border-radius: 1rem; color: white; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
            <div style="font-size: 0.85rem; opacity: 0.9; margin-bottom: 0.5rem;">Départements</div>
            <div style="font-size: 2rem; font-weight: 700;"><?php echo e($stats['departments']); ?></div>
        </div>
    </div>

    <!-- Main Content Tabs -->
    <div style="background: white; border-radius: 1rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); overflow: hidden;">
        <!-- Tab Navigation -->
        <div style="display: flex; border-bottom: 2px solid #e5e7eb; background: #f9fafb;">
            <button onclick="showTab('architecture')" class="tab-btn" style="color: white; background: #11669c;">
                🏗️ Architecture
            </button>
            <button onclick="showTab('meal-rules')" class="tab-btn">
                🍽️ Règles de Repas
            </button>
            <button onclick="showTab('data-flow')" class="tab-btn">
                🔄 Flux de Données
            </button>
            <button onclick="showTab('entities')" class="tab-btn">
                📊 Entités
            </button>
            <button onclick="showTab('workflows')" class="tab-btn">
                ⚙️ Workflows
            </button>
        </div>

        <!-- Tab Contents -->
        <div style="padding: 2rem;">
            <!-- Architecture Tab -->
            <div id="architecture" class="tab-content">
                <h2 style="color: #11669c; font-size: 1.5rem; margin-bottom: 1.5rem;">
                    🏗️ Architecture du Système
                </h2>

                <div style="margin-bottom: 2rem;">
                    <h3 style="color: #333; font-size: 1.2rem; margin-bottom: 1rem; padding-bottom: 0.5rem; border-bottom: 2px solid #e5e7eb;">
                        Couches d'Application
                    </h3>
                    <div style="background: #f3f4f6; padding: 1.5rem; border-radius: 0.75rem; border-left: 4px solid #11669c;">
                        <div style="margin-bottom: 1.5rem;">
                            <h4 style="color: #11669c; font-weight: 600; margin-bottom: 0.5rem;">🔐 Couche Authentification</h4>
                            <p style="color: #666; margin-bottom: 0.5rem;"><strong>Contrôleur:</strong> AdminAuthController</p>
                            <p style="color: #666; margin-bottom: 0.5rem;">Gère la connexion/déconnexion des administrateurs avec authentification sécurisée</p>
                            <p style="color: #666; font-size: 0.9rem; background: white; padding: 0.75rem; border-radius: 0.5rem; margin-top: 0.5rem;">
                                <strong>Routes:</strong> /login (GET/POST), /logout (POST)
                            </p>
                        </div>

                        <div style="margin-bottom: 1.5rem;">
                            <h4 style="color: #11669c; font-weight: 600; margin-bottom: 0.5rem;">📊 Couche Dashboard</h4>
                            <p style="color: #666; margin-bottom: 0.5rem;"><strong>Contrôleurs:</strong> DashboardController, ExtraDashboardController, SystemCatalogController</p>
                            <p style="color: #666; margin-bottom: 0.5rem;">Interface de gestion principale avec statistiques en temps réel, graphiques et métriques</p>
                            <p style="color: #666; font-size: 0.9rem; background: white; padding: 0.75rem; border-radius: 0.5rem; margin-top: 0.5rem;">
                                <strong>Fonctionnalités:</strong> Vue d'ensemble générale, extra-pointage, rapport d'analyse système
                            </p>
                        </div>

                        <div style="margin-bottom: 1.5rem;">
                            <h4 style="color: #11669c; font-weight: 600; margin-bottom: 0.5rem;">📱 Couche Kiosk</h4>
                            <p style="color: #666; margin-bottom: 0.5rem;"><strong>Contrôleur:</strong> KioskController</p>
                            <p style="color: #666; margin-bottom: 0.5rem;">Interface dédiée aux bornes (kiosques) NFC pour le pointage repas rapide</p>
                            <p style="color: #666; font-size: 0.9rem; background: white; padding: 0.75rem; border-radius: 0.5rem; margin-top: 0.5rem;">
                                <strong>Pages:</strong> Scan NFC, Extra (pointage rapide), La Relève (externes)
                            </p>
                        </div>

                        <div style="margin-bottom: 1.5rem;">
                            <h4 style="color: #11669c; font-weight: 600; margin-bottom: 0.5rem;">⚙️ Couche Métier</h4>
                            <p style="color: #666; margin-bottom: 0.5rem;"><strong>Services:</strong> LaReleveMealAccessService</p>
                            <p style="color: #666; margin-bottom: 0.5rem;">Logique métier centralisée pour autorisation, validation et suivi des repas</p>
                            <p style="color: #666; font-size: 0.9rem; background: white; padding: 0.75rem; border-radius: 0.5rem; margin-top: 0.5rem;">
                                <strong>Responsabilités:</strong> Vérification quotas, autorisation repas, révocation, gestion MealRule
                            </p>
                        </div>

                        <div>
                            <h4 style="color: #11669c; font-weight: 600; margin-bottom: 0.5rem;">💾 Couche Données</h4>
                            <p style="color: #666; margin-bottom: 0.5rem;"><strong>ORM:</strong> Eloquent (Laravel)</p>
                            <p style="color: #666; margin-bottom: 0.5rem;">Base de données SQLite avec 11 modèles principaux interconnectés</p>
                            <p style="color: #666; font-size: 0.9rem; background: white; padding: 0.75rem; border-radius: 0.5rem; margin-top: 0.5rem;">
                                <strong>Patterns:</strong> Relations HasMany, BelongsTo, HasOne avec soft deletes et timestamps
                            </p>
                        </div>
                    </div>
                </div>

                <div>
                    <h3 style="color: #333; font-size: 1.2rem; margin-bottom: 1rem; padding-bottom: 0.5rem; border-bottom: 2px solid #e5e7eb;">
                        Stack Technologique
                    </h3>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem;">
                        <div style="background: #eff6ff; padding: 1rem; border-radius: 0.75rem; border-left: 4px solid #3b82f6;">
                            <strong style="color: #1e40af;">Backend</strong>
                            <div style="color: #666; margin-top: 0.5rem; font-size: 0.9rem;">
                                • Laravel 12 (PHP 8.5)<br>
                                • SQLite (Database)<br>
                                • Eloquent ORM
                            </div>
                        </div>
                        <div style="background: #f0fdf4; padding: 1rem; border-radius: 0.75rem; border-left: 4px solid #22c55e;">
                            <strong style="color: #166534;">Frontend</strong>
                            <div style="color: #666; margin-top: 0.5rem; font-size: 0.9rem;">
                                • Blade Templates<br>
                                • Vanilla CSS/JavaScript<br>
                                • Responsive Design
                            </div>
                        </div>
                        <div style="background: #fef3c7; padding: 1rem; border-radius: 0.75rem; border-left: 4px solid #f59e0b;">
                            <strong style="color: #92400e;">Infrastructure</strong>
                            <div style="color: #666; margin-top: 0.5rem; font-size: 0.9rem;">
                                • NFC Card Scanning<br>
                                • RESTful API<br>
                                • Request Validation
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Meal Rules Tab -->
            <div id="meal-rules" class="tab-content" style="display: none;">
                <h2 style="color: #11669c; font-size: 1.5rem; margin-bottom: 1.5rem;">
                    🍽️ Règles de Repas
                </h2>

                <div style="background: #f3f4f6; padding: 1.5rem; border-radius: 0.75rem; border-left: 4px solid #11669c; margin-bottom: 2rem;">
                    <h3 style="color: #333; margin-bottom: 1rem;">Concept Fondamental</h3>
                    <p style="color: #666; line-height: 1.6;">
                        Les <strong>Règles de Repas (MealRule)</strong> sont le cœur du système. Elles définissent:
                    </p>
                    <ul style="color: #666; margin-left: 1.5rem; margin-top: 0.75rem; line-height: 1.8;">
                        <li><strong>Nom du repas</strong> (Petit-déjeuner, Déjeuner, Dîner, etc.)</li>
                        <li><strong>Horaires</strong> (heure_début → heure_fin)</li>
                        <li><strong>Jours applicables</strong> (Lun, Mar, Mer, Jeu, Ven, etc.)</li>
                        <li><strong>Coût unitaire</strong> du repas en devise locale</li>
                        <li><strong>Quotas journaliers/hebdomadaires</strong> par employé</li>
                        <li><strong>Status d'activation</strong> (actif/inactif)</li>
                        <li><strong>Autorisation universelle</strong> (tous les employés ou sélectionnés)</li>
                    </ul>
                </div>

                <div style="margin-bottom: 2rem;">
                    <h3 style="color: #333; font-size: 1.2rem; margin-bottom: 1rem; padding-bottom: 0.5rem; border-bottom: 2px solid #e5e7eb;">
                        Règles Actuellement Configurées
                    </h3>

                    <?php if($mealRules->count() > 0): ?>
                        <div style="display: grid; gap: 1rem;">
                            <?php $__currentLoopData = $mealRules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $ruleClass = $rule->is_active ? 'rule-card-active' : 'rule-card-inactive';
                                ?>
                                <div class="<?php echo e($ruleClass); ?>" style="background: white; border-radius: 0.75rem; padding: 1.5rem;">
                                    <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1rem;">
                                        <div>
                                            <h4 style="color: #11669c; font-size: 1.1rem; font-weight: 600; margin-bottom: 0.25rem;">
                                                <?php echo e($rule->name); ?>

                                            </h4>
                                            <p style="color: #999; font-size: 0.9rem;">
                                                ID: <?php echo e($rule->id); ?> • Créé par: <?php echo e($rule->creator?->name ?? 'Système'); ?>

                                            </p>
                                        </div>
                                        <span class="<?php echo e($rule->is_active ? 'rule-status-active' : 'rule-status-inactive'); ?>" style="display: inline-block; padding: 0.5rem 1rem; border-radius: 0.5rem; font-size: 0.85rem; font-weight: 600;">
                                            <?php echo e($rule->is_active ? '✓ Actif' : '✗ Inactif'); ?>

                                        </span>
                                    </div>

                                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1rem;">
                                        <div style="background: #f9fafb; padding: 0.75rem; border-radius: 0.5rem;">
                                            <p style="color: #999; font-size: 0.85rem; font-weight: 600; margin-bottom: 0.25rem;">⏰ Horaires</p>
                                            <p style="color: #333; font-weight: 500;"><?php echo e(substr($rule->start_time, 0, 5)); ?> - <?php echo e(substr($rule->end_time, 0, 5)); ?></p>
                                        </div>

                                        <div style="background: #f9fafb; padding: 0.75rem; border-radius: 0.5rem;">
                                            <p style="color: #999; font-size: 0.85rem; font-weight: 600; margin-bottom: 0.25rem;">💰 Coût</p>
                                            <p style="color: #333; font-weight: 500;"><?php echo e(number_format($rule->cost, 2)); ?> DA</p>
                                        </div>

                                        <div style="background: #f9fafb; padding: 0.75rem; border-radius: 0.5rem;">
                                            <p style="color: #999; font-size: 0.85rem; font-weight: 600; margin-bottom: 0.25rem;">📅 Jours</p>
                                            <p style="color: #333; font-weight: 500; font-size: 0.9rem;">
                                                <?php if(is_array($rule->days_of_week)): ?>
                                                    <?php
                                                        $dayLabels = ['Lun' => 'Mon', 'Mar' => 'Tue', 'Mer' => 'Wed', 'Jeu' => 'Thu', 'Ven' => 'Fri', 'Sam' => 'Sat', 'Dim' => 'Sun'];
                                                        $dayNames = ['Mon' => 'Lun', 'Tue' => 'Mar', 'Wed' => 'Mer', 'Thu' => 'Jeu', 'Fri' => 'Ven', 'Sat' => 'Sam', 'Sun' => 'Dim'];
                                                        $selected = implode(', ', array_map(fn($d) => $dayNames[$d] ?? $d, $rule->days_of_week));
                                                    ?>
                                                    <?php echo e($selected ?: 'Tous'); ?>

                                                <?php else: ?>
                                                    Tous
                                                <?php endif; ?>
                                            </p>
                                        </div>

                                        <div style="background: #f9fafb; padding: 0.75rem; border-radius: 0.5rem;">
                                            <p style="color: #999; font-size: 0.85rem; font-weight: 600; margin-bottom: 0.25rem;">📊 Quotas</p>
                                            <p style="color: #333; font-weight: 500; font-size: 0.9rem;">
                                                <?php echo e($rule->max_meals_per_day ?? '∞'); ?>/jour • <?php echo e($rule->max_meals_per_week ?? '∞'); ?>/sem
                                            </p>
                                        </div>

                                        <div style="background: #f9fafb; padding: 0.75rem; border-radius: 0.5rem;">
                                            <p style="color: #999; font-size: 0.85rem; font-weight: 600; margin-bottom: 0.25rem;">👥 Portée</p>
                                            <p style="color: #333; font-weight: 500;">
                                                <?php echo e($rule->authorize_for_all_employees ? 'Tous les employés' : 'Sélectionnés'); ?>

                                            </p>
                                        </div>
                                    </div>

                                    <div style="background: #f9fafb; padding: 0.75rem; border-radius: 0.5rem;">
                                        <p style="color: #999; font-size: 0.85rem; font-weight: 600; margin-bottom: 0.25rem;">📝 Logs associés</p>
                                        <p style="color: #333; font-weight: 500;"><?php echo e($rule->mealLogs->count()); ?> repas enregistrés</p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <div style="background: #fef3c7; padding: 1.5rem; border-radius: 0.75rem; color: #92400e; border-left: 4px solid #f59e0b;">
                            ⚠️ Aucune règle de repas configurée. <a href="<?php echo e(route('meal-rules.index')); ?>" style="color: #d97706; font-weight: 600; text-decoration: underline;">Créer une règle</a>
                        </div>
                    <?php endif; ?>
                </div>

                <div style="background: #eff6ff; padding: 1.5rem; border-radius: 0.75rem; border-left: 4px solid #3b82f6;">
                    <h3 style="color: #1e40af; margin-bottom: 1rem;">💡 Impact des Règles de Repas</h3>
                    <ul style="color: #1e40af; margin-left: 1.5rem; line-height: 1.8;">
                        <li><strong>Kiosk Extra:</strong> Affiche uniquement les repas de règles actives au moment du pointage</li>
                        <li><strong>Kiosk La Relève:</strong> Vérifie les autorisations via les règles avant d'accepter un repas</li>
                        <li><strong>Validation:</strong> Les requêtes utilisent meal_rule_id au lieu de meal_type</li>
                        <li><strong>MealLog:</strong> Chaque log enregistre la règle utilisée pour la traçabilité</li>
                        <li><strong>Quotas:</strong> Le système vérifie les limites quotidiennes et hebdomadaires avant d'autoriser</li>
                    </ul>
                </div>
            </div>

            <!-- Data Flow Tab -->
            <div id="data-flow" class="tab-content" style="display: none;">
                <h2 style="color: #11669c; font-size: 1.5rem; margin-bottom: 1.5rem;">
                    🔄 Flux de Données du Système
                </h2>

                <div style="margin-bottom: 2rem;">
                    <h3 style="color: #333; font-size: 1.2rem; margin-bottom: 1rem; padding-bottom: 0.5rem; border-bottom: 2px solid #e5e7eb;">
                        1️⃣ Pointage Standard (Dashboard Kiosk Extra)
                    </h3>
                    <div style="background: #f3f4f6; padding: 1.5rem; border-radius: 0.75rem;">
                        <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem; flex-wrap: wrap;">
                            <div style="background: white; padding: 1rem; border-radius: 0.5rem; border: 2px solid #11669c; min-width: 150px;">
                                <strong style="color: #11669c;">1. Sélection</strong><br>
                                <span style="font-size: 0.9rem; color: #666;">Employé + Règle</span>
                            </div>
                            <span style="color: #11669c; font-weight: bold;">→</span>
                            <div style="background: white; padding: 1rem; border-radius: 0.5rem; border: 2px solid #11669c; min-width: 150px;">
                                <strong style="color: #11669c;">2. Validation</strong><br>
                                <span style="font-size: 0.9rem; color: #666;">Quota + Règle</span>
                            </div>
                            <span style="color: #11669c; font-weight: bold;">→</span>
                            <div style="background: white; padding: 1rem; border-radius: 0.5rem; border: 2px solid #11669c; min-width: 150px;">
                                <strong style="color: #11669c;">3. Enregistrement</strong><br>
                                <span style="font-size: 0.9rem; color: #666;">MealLog créé</span>
                            </div>
                        </div>
                        <div style="background: white; padding: 1rem; border-radius: 0.5rem; margin-top: 1rem; border-left: 4px solid #11669c;">
                            <strong>Points clés:</strong>
                            <ul style="color: #666; margin-left: 1.5rem; margin-top: 0.5rem;">
                                <li>Utilise KioskController::storeExtra() ou toggleExtra()</li>
                                <li>Vérifie LaReleveMealAccessService::mealRuleAllowed()</li>
                                <li>Crée MealLog avec status 'approved' ou 'denied'</li>
                                <li>Répond avec JSON pour mise à jour instantanée UI</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div style="margin-bottom: 2rem;">
                    <h3 style="color: #333; font-size: 1.2rem; margin-bottom: 1rem; padding-bottom: 0.5rem; border-bottom: 2px solid #e5e7eb;">
                        2️⃣ Pointage La Relève (Externes)
                    </h3>
                    <div style="background: #f3f4f6; padding: 1.5rem; border-radius: 0.75rem;">
                        <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem; flex-wrap: wrap;">
                            <div style="background: white; padding: 1rem; border-radius: 0.5rem; border: 2px solid #18a870; min-width: 150px;">
                                <strong style="color: #18a870;">1. Identification</strong><br>
                                <span style="font-size: 0.9rem; color: #666;">Nom/ID NFC</span>
                            </div>
                            <span style="color: #18a870; font-weight: bold;">→</span>
                            <div style="background: white; padding: 1rem; border-radius: 0.5rem; border: 2px solid #18a870; min-width: 150px;">
                                <strong style="color: #18a870;">2. Lookup</strong><br>
                                <span style="font-size: 0.9rem; color: #666;">LaReleveEntry</span>
                            </div>
                            <span style="color: #18a870; font-weight: bold;">→</span>
                            <div style="background: white; padding: 1rem; border-radius: 0.5rem; border: 2px solid #18a870; min-width: 150px;">
                                <strong style="color: #18a870;">3. Autorisation</strong><br>
                                <span style="font-size: 0.9rem; color: #666;">Basée Règle</span>
                            </div>
                            <span style="color: #18a870; font-weight: bold;">→</span>
                            <div style="background: white; padding: 1rem; border-radius: 0.5rem; border: 2px solid #18a870; min-width: 150px;">
                                <strong style="color: #18a870;">4. LaRelveMealLog</strong><br>
                                <span style="font-size: 0.9rem; color: #666;">Enregistré</span>
                            </div>
                        </div>
                        <div style="background: white; padding: 1rem; border-radius: 0.5rem; margin-top: 1rem; border-left: 4px solid #18a870;">
                            <strong>Points clés:</strong>
                            <ul style="color: #666; margin-left: 1.5rem; margin-top: 0.5rem;">
                                <li>LaReleveEntry stocke les externe (non-employés) avec allowed_meal_rule_ids</li>
                                <li>Service vérifie LaReleveMealAccessService::evaluateAuthorization()</li>
                                <li>Crée LaReleveMealLog avec traçabilité complète</li>
                                <li>Gère quotas journaliers/hebdomadaires séparément</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div style="margin-bottom: 2rem;">
                    <h3 style="color: #333; font-size: 1.2rem; margin-bottom: 1rem; padding-bottom: 0.5rem; border-bottom: 2px solid #e5e7eb;">
                        3️⃣ Gestion Cartes NFC
                    </h3>
                    <div style="background: #f3f4f6; padding: 1.5rem; border-radius: 0.75rem;">
                        <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem; flex-wrap: wrap;">
                            <div style="background: white; padding: 1rem; border-radius: 0.5rem; border: 2px solid #f59e0b; min-width: 150px;">
                                <strong style="color: #f59e0b;">Scan NFC</strong><br>
                                <span style="font-size: 0.9rem; color: #666;">Card.id trouvé</span>
                            </div>
                            <span style="color: #f59e0b; font-weight: bold;">→</span>
                            <div style="background: white; padding: 1rem; border-radius: 0.5rem; border: 2px solid #f59e0b; min-width: 150px;">
                                <strong style="color: #f59e0b;">Lookup Employee</strong><br>
                                <span style="font-size: 0.9rem; color: #666;">via Card</span>
                            </div>
                            <span style="color: #f59e0b; font-weight: bold;">→</span>
                            <div style="background: white; padding: 1rem; border-radius: 0.5rem; border: 2px solid #f59e0b; min-width: 150px;">
                                <strong style="color: #f59e0b;">Charge MealRules</strong><br>
                                <span style="font-size: 0.9rem; color: #666;">actives</span>
                            </div>
                            <span style="color: #f59e0b; font-weight: bold;">→</span>
                            <div style="background: white; padding: 1rem; border-radius: 0.5rem; border: 2px solid #f59e0b; min-width: 150px;">
                                <strong style="color: #f59e0b;">Affiche Kiosk</strong><br>
                                <span style="font-size: 0.9rem; color: #666;">Interface</span>
                            </div>
                        </div>
                        <div style="background: white; padding: 1rem; border-radius: 0.5rem; margin-top: 1rem; border-left: 4px solid #f59e0b;">
                            <strong>Points clés:</strong>
                            <ul style="color: #666; margin-left: 1.5rem; margin-top: 0.5rem;">
                                <li>Card model lie Employee à NFC uid/number</li>
                                <li>CardStatusHistory trace les changements (active → inactive → unauthorized)</li>
                                <li>KioskController::laRelevePage() charge les règles actives</li>
                                <li>Interface segmented button affiche dynamiquement les options</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Entities Tab -->
            <div id="entities" class="tab-content" style="display: none;">
                <h2 style="color: #11669c; font-size: 1.5rem; margin-bottom: 1.5rem;">
                    📊 Entités du Système
                </h2>

                <div style="display: grid; gap: 1.5rem;">
                    <!-- Employee -->
                    <div style="background: white; border: 1px solid #e5e7eb; border-radius: 0.75rem; overflow: hidden;">
                        <div style="background: linear-gradient(135deg, #11669c 0%, #1a79b8 100%); padding: 1rem; color: white;">
                            <h3 style="font-size: 1.1rem; margin: 0;">👤 Employee (Employé)</h3>
                        </div>
                        <div style="padding: 1.5rem;">
                            <p style="color: #666; margin-bottom: 1rem;">
                                Représente un employé du système avec ses données personnelles, attribution de département et permissions de repas.
                            </p>
                            <div style="background: #f9fafb; padding: 1rem; border-radius: 0.5rem; margin-bottom: 1rem;">
                                <strong style="color: #333;">Attributs clés:</strong>
                                <div style="color: #666; font-size: 0.9rem; margin-top: 0.5rem; line-height: 1.6;">
                                    • employee_no (ID unique)<br>
                                    • first_name, last_name, position<br>
                                    • department_id (relation à Department)<br>
                                    • allowed_meal_types (array de meal_rule_ids)<br>
                                    • hired_at, is_active<br>
                                    • Relation: Card (1:1), Department (N:1), User (N:1)
                                </div>
                            </div>
                            <p style="color: #666; font-size: 0.9rem; background: #eff6ff; padding: 0.75rem; border-radius: 0.5rem;">
                                <strong>Usage:</strong> Pivot central - chaque pointage repas référence un Employee
                            </p>
                        </div>
                    </div>

                    <!-- MealRule -->
                    <div style="background: white; border: 1px solid #e5e7eb; border-radius: 0.75rem; overflow: hidden;">
                        <div style="background: linear-gradient(135deg, #18a870 0%, #12845b 100%); padding: 1rem; color: white;">
                            <h3 style="font-size: 1.1rem; margin: 0;">🍽️ MealRule (Règle de Repas)</h3>
                        </div>
                        <div style="padding: 1.5rem;">
                            <p style="color: #666; margin-bottom: 1rem;">
                                Définit ce qui constitue un "repas" dans le système: horaires, jours, coûts et quotas.
                            </p>
                            <div style="background: #f9fafb; padding: 1rem; border-radius: 0.5rem; margin-bottom: 1rem;">
                                <strong style="color: #333;">Attributs clés:</strong>
                                <div style="color: #666; font-size: 0.9rem; margin-top: 0.5rem; line-height: 1.6;">
                                    • name (ex: "Petit-déjeuner")<br>
                                    • start_time, end_time (plages horaires)<br>
                                    • days_of_week (array: Mon, Tue, ...)<br>
                                    • cost (décimal)<br>
                                    • max_meals_per_day, max_meals_per_week<br>
                                    • is_active (boolean)<br>
                                    • authorize_for_all_employees
                                </div>
                            </div>
                            <p style="color: #666; font-size: 0.9rem; background: #d1fae5; padding: 0.75rem; border-radius: 0.5rem;">
                                <strong>Impact:</strong> Cœur du système - contrôle toute la logique d'autorisation
                            </p>
                        </div>
                    </div>

                    <!-- MealLog -->
                    <div style="background: white; border: 1px solid #e5e7eb; border-radius: 0.75rem; overflow: hidden;">
                        <div style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); padding: 1rem; color: white;">
                            <h3 style="font-size: 1.1rem; margin: 0;">📝 MealLog (Log de Repas Employé)</h3>
                        </div>
                        <div style="padding: 1.5rem;">
                            <p style="color: #666; margin-bottom: 1rem;">
                                Enregistrement de chaque repas pointé par un employé - audit trail complet.
                            </p>
                            <div style="background: #f9fafb; padding: 1rem; border-radius: 0.5rem; margin-bottom: 1rem;">
                                <strong style="color: #333;">Attributs clés:</strong>
                                <div style="color: #666; font-size: 0.9rem; margin-top: 0.5rem; line-height: 1.6;">
                                    • employee_id (FK Employee)<br>
                                    • meal_rule_id (FK MealRule)<br>
                                    • status (approved/denied/pending)<br>
                                    • logged_at (timestamp du pointage)<br>
                                    • reason (motif si denied)<br>
                                    • Timestamps: created_at, updated_at
                                </div>
                            </div>
                            <p style="color: #666; font-size: 0.9rem; background: #fef3c7; padding: 0.75rem; border-radius: 0.5rem;">
                                <strong>Usage:</strong> Archivage - chaque action crée un log immuable
                            </p>
                        </div>
                    </div>

                    <!-- LaReleveEntry -->
                    <div style="background: white; border: 1px solid #e5e7eb; border-radius: 0.75rem; overflow: hidden;">
                        <div style="background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); padding: 1rem; color: white;">
                            <h3 style="font-size: 1.1rem; margin: 0;">🚀 LaReleveEntry (Entrée Externe)</h3>
                        </div>
                        <div style="padding: 1.5rem;">
                            <p style="color: #666; margin-bottom: 1rem;">
                                Représente une personne externe (non-employée) autorisée à pointer des repas pour un jour spécifique.
                            </p>
                            <div style="background: #f9fafb; padding: 1rem; border-radius: 0.5rem; margin-bottom: 1rem;">
                                <strong style="color: #333;">Attributs clés:</strong>
                                <div style="color: #666; font-size: 0.9rem; margin-top: 0.5rem; line-height: 1.6;">
                                    • full_name<br>
                                    • external_id (ID externe/temporaire)<br>
                                    • entry_date (date du jour d'accès)<br>
                                    • allowed_meal_types (array de meal_rule_ids)<br>
                                    • position, rig_company<br>
                                    • source, notes<br>
                                    • Relation: LaReleveMealLog (1:N)
                                </div>
                            </div>
                            <p style="color: #666; font-size: 0.9rem; background: #f3e8ff; padding: 0.75rem; border-radius: 0.5rem;">
                                <strong>Usage:</strong> Gestion temporaire des visiteurs/contractuels journaliers
                            </p>
                        </div>
                    </div>

                    <!-- Card -->
                    <div style="background: white; border: 1px solid #e5e7eb; border-radius: 0.75rem; overflow: hidden;">
                        <div style="background: linear-gradient(135deg, #ec4899 0%, #db2777 100%); padding: 1rem; color: white;">
                            <h3 style="font-size: 1.1rem; margin: 0;">🎫 Card (Carte NFC)</h3>
                        </div>
                        <div style="padding: 1.5rem;">
                            <p style="color: #666; margin-bottom: 1rem;">
                                Représente une carte NFC physique avec ses identificateurs et son état.
                            </p>
                            <div style="background: #f9fafb; padding: 1rem; border-radius: 0.5rem; margin-bottom: 1rem;">
                                <strong style="color: #333;">Attributs clés:</strong>
                                <div style="color: #666; font-size: 0.9rem; margin-top: 0.5rem; line-height: 1.6;">
                                    • uid (ID unique NFC)<br>
                                    • number (numéro carte lisible)<br>
                                    • assigned_employee_id (FK Employee)<br>
                                    • status (active/inactive/lost/unauthorized)<br>
                                    • Relation: CardStatusHistory (1:N)
                                </div>
                            </div>
                            <p style="color: #666; font-size: 0.9rem; background: #fce7f3; padding: 0.75rem; border-radius: 0.5rem;">
                                <strong>Usage:</strong> Bridge entre scan physique et employé digital
                            </p>
                        </div>
                    </div>

                    <!-- Department -->
                    <div style="background: white; border: 1px solid #e5e7eb; border-radius: 0.75rem; overflow: hidden;">
                        <div style="background: linear-gradient(135deg, #06b6d4 0%, #0891b2 100%); padding: 1rem; color: white;">
                            <h3 style="font-size: 1.1rem; margin: 0;">🏢 Department (Département)</h3>
                        </div>
                        <div style="padding: 1.5rem;">
                            <p style="color: #666; margin-bottom: 1rem;">
                                Groupement organisationnel d'employés pour la reporting et la gestion administrative.
                            </p>
                            <div style="background: #f9fafb; padding: 1rem; border-radius: 0.5rem; margin-bottom: 1rem;">
                                <strong style="color: #333;">Attributs clés:</strong>
                                <div style="color: #666; font-size: 0.9rem; margin-top: 0.5rem; line-height: 1.6;">
                                    • name<br>
                                    • description<br>
                                    • is_active<br>
                                    • Relation: Employee (1:N)
                                </div>
                            </div>
                            <p style="color: #666; font-size: 0.9rem; background: #cffafe; padding: 0.75rem; border-radius: 0.5rem;">
                                <strong>Usage:</strong> Segmentation organisationnelle
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Workflows Tab -->
            <div id="workflows" class="tab-content" style="display: none;">
                <h2 style="color: #11669c; font-size: 1.5rem; margin-bottom: 1.5rem;">
                    ⚙️ Workflows & Processus
                </h2>

                <div style="margin-bottom: 2rem;">
                    <h3 style="color: #333; font-size: 1.2rem; margin-bottom: 1rem; padding-bottom: 0.5rem; border-bottom: 2px solid #e5e7eb;">
                        Workflow Pointage Employé
                    </h3>
                    <div style="background: #fff7ed; padding: 1.5rem; border-radius: 0.75rem; border-left: 4px solid #f59e0b;">
                        <ol style="color: #666; margin-left: 1.5rem; line-height: 2;">
                            <li><strong>Employé scanne</strong> sa carte NFC sur le kiosk</li>
                            <li><strong>KioskController::laRelevePage()</strong> récupère Employee via Card</li>
                            <li><strong>Charge MealRules actives</strong> depuis base de données</li>
                            <li><strong>Affiche interface segmented button</strong> avec 4 options (règles actives)</li>
                            <li><strong>Employé sélectionne</strong> une règle (ex: Déjeuner)</li>
                            <li><strong>KioskController::storeExtra() ou toggleExtra()</strong> traite la requête</li>
                            <li><strong>LaReleveMealAccessService::consumeWithMealRule()</strong> valide:
                                <ul style="margin-left: 1.5rem; margin-top: 0.5rem;">
                                    <li>La règle est active</li>
                                    <li>L'employé y est autorisé</li>
                                    <li>Les quotas ne sont pas dépassés</li>
                                    <li>La règle n'est pas déjà consommée (duplicata)</li>
                                </ul>
                            </li>
                            <li><strong>Crée MealLog</strong> avec status approved/denied</li>
                            <li><strong>Répond en JSON</strong> pour mise à jour UI instantanée</li>
                            <li><strong>Display feedback visuel</strong> (toast success/error)</li>
                        </ol>
                    </div>
                </div>

                <div style="margin-bottom: 2rem;">
                    <h3 style="color: #333; font-size: 1.2rem; margin-bottom: 1rem; padding-bottom: 0.5rem; border-bottom: 2px solid #e5e7eb;">
                        Workflow La Relève (Externes)
                    </h3>
                    <div style="background: #f0fdf4; padding: 1.5rem; border-radius: 0.75rem; border-left: 4px solid #18a870;">
                        <ol style="color: #666; margin-left: 1.5rem; line-height: 2;">
                            <li><strong>Manager accède</strong> à page /la-releve</li>
                            <li><strong>Recherche nom</strong> d'une personne externe (ex: "Taleb")</li>
                            <li><strong>LaReleveController::search()</strong> retourne correspondances</li>
                            <li><strong>Affiche liste dynamique</strong> avec options repas autorisées</li>
                            <li><strong>Manager clique</strong> sur une option de repas</li>
                            <li><strong>LaReleveController::toggleLaReleve()</strong> traite</li>
                            <li><strong>LaReleveMealAccessService::evaluateAuthorization()** valide:
                                <ul style="margin-left: 1.5rem; margin-top: 0.5rem;">
                                    <li>La personne est autorisée pour cette date</li>
                                    <li>La règle est dans allowed_meal_types</li>
                                    <li>Les quotas journaliers ne sont pas atteints</li>
                                    <li>Pas de duplicata pour cette règle aujourd'hui</li>
                                </ul>
                            </li>
                            <li><strong>Crée LaReleveMealLog</strong> (table séparé pour externes)</li>
                            <li><strong>Marque comme consommé</strong> dans UI</li>
                        </ol>
                    </div>
                </div>

                <div style="margin-bottom: 2rem;">
                    <h3 style="color: #333; font-size: 1.2rem; margin-bottom: 1rem; padding-bottom: 0.5rem; border-bottom: 2px solid #e5e7eb;">
                        Workflow Gestion Règles
                    </h3>
                    <div style="background: #f0f8ff; padding: 1.5rem; border-radius: 0.75rem; border-left: 4px solid #3b82f6;">
                        <ol style="color: #666; margin-left: 1.5rem; line-height: 2;">
                            <li><strong>Admin accède</strong> à /meal-rules</li>
                            <li><strong>Liste toutes les règles</strong> avec leur status (actif/inactif)</li>
                            <li><strong>Admin crée une nouvelle</strong> (ex: "Snack 15h-16h")</li>
                            <li><strong>MealRuleController::store()</strong> valide et crée l'entrée</li>
                            <li><strong>Admin configure:</strong>
                                <ul style="margin-left: 1.5rem; margin-top: 0.5rem;">
                                    <li>Horaires (start_time, end_time)</li>
                                    <li>Jours applicables (days_of_week)</li>
                                    <li>Coût</li>
                                    <li>Quotas (per day/week)</li>
                                    <li>Autorisation (tous vs. sélectionnés)</li>
                                </ul>
                            </li>
                            <li><strong>Règle sauvegardée</strong> et peut être activée</li>
                            <li><strong>Une fois active:</strong>
                                <ul style="margin-left: 1.5rem; margin-top: 0.5rem;">
                                    <li>Apparaît dans kiosks</li>
                                    <li>Peut être pointée par employés autorisés</li>
                                    <li>Ses quotas sont vérifiés</li>
                                </ul>
                            </li>
                            <li><strong>Admin peut désactiver</strong> à tout moment (historique conservé)</li>
                        </ol>
                    </div>
                </div>

                <div>
                    <h3 style="color: #333; font-size: 1.2rem; margin-bottom: 1rem; padding-bottom: 0.5rem; border-bottom: 2px solid #e5e7eb;">
                        Service Central: LaReleveMealAccessService
                    </h3>
                    <div style="background: #f3f4f6; padding: 1.5rem; border-radius: 0.75rem;">
                        <p style="color: #666; margin-bottom: 1rem;">
                            Classe métier pivotale qui encapsule TOUTE la logique d'autorisation et de validation des repas.
                        </p>
                        <div style="display: grid; gap: 1rem;">
                            <div style="background: white; padding: 1rem; border-radius: 0.5rem; border-left: 4px solid #11669c;">
                                <h4 style="color: #11669c; margin-bottom: 0.5rem;">consumeWithMealRule()</h4>
                                <p style="color: #666; font-size: 0.9rem;">
                                    Consomme un repas pour un employé sur une règle spécifique. Vérifie toutes les conditions et crée MealLog si valide.
                                </p>
                            </div>
                            <div style="background: white; padding: 1rem; border-radius: 0.5rem; border-left: 4px solid #11669c;">
                                <h4 style="color: #11669c; margin-bottom: 0.5rem;">evaluateAuthorization()</h4>
                                <p style="color: #666; font-size: 0.9rem;">
                                    Évalue si une personne externe est autorisée pour une règle spécifique à une date donnée.
                                </p>
                            </div>
                            <div style="background: white; padding: 1rem; border-radius: 0.5rem; border-left: 4px solid #11669c;">
                                <h4 style="color: #11669c; margin-bottom: 0.5rem;">mealRuleAllowed()</h4>
                                <p style="color: #666; font-size: 0.9rem;">
                                    Vérifie si un employé a le droit de consommer une règle basé sur allowed_meal_types.
                                </p>
                            </div>
                            <div style="background: white; padding: 1rem; border-radius: 0.5rem; border-left: 4px solid #11669c;">
                                <h4 style="color: #11669c; margin-bottom: 0.5rem;">mealRuleConsumed()</h4>
                                <p style="color: #666; font-size: 0.9rem;">
                                    Vérifie si une règle a déjà été consommée aujourd'hui par une entité (employé/externe).
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <div style="margin-top: 3rem; padding-top: 2rem; border-top: 2px solid #e5e7eb; text-align: center;">
        <p style="color: #999; font-size: 0.9rem;">
            📖 <strong>Catalogue Système v1.0</strong> • Documentation auto-générée<br>
            Pour des questions sur l'architecture, consultez les fichiers: <br>
            <code style="background: #f3f4f6; padding: 0.25rem 0.5rem; border-radius: 0.25rem; color: #666; font-size: 0.85rem;">
                app/Services/LaReleveMealAccessService.php • app/Http/Controllers/KioskController.php
            </code>
        </p>
    </div>
</div>

<style>
    .tab-btn {
        flex: 1;
        padding: 1rem 1.5rem;
        border: none;
        background: transparent;
        cursor: pointer;
        font-weight: 600;
        font-size: 0.95rem;
        color: #666;
        transition: all 0.3s ease;
        border-bottom: 3px solid transparent;
        margin-bottom: -2px;
    }

    .tab-btn:hover {
        background: #f3f4f6;
        color: #11669c;
    }

    .tab-btn[style*="background: #11669c"] {
        color: white;
        border-bottom-color: white !important;
    }

    .tab-content {
        animation: fadeIn 0.3s ease-in;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    code {
        font-family: 'Courier New', monospace;
    }

    /* Meal Rule Cards */
    .rule-card-active {
        border: 2px solid #10b981 !important;
    }

    .rule-card-inactive {
        border: 2px solid #d1d5db !important;
    }

    .rule-status-active {
        background: #d1fae5 !important;
        color: #065f46 !important;
    }

    .rule-status-inactive {
        background: #f3f4f6 !important;
        color: #666 !important;
    }

    /* Responsive */
    @media (max-width: 980px) {
        .tab-btn {
            padding: 0.75rem 0.5rem;
            font-size: 0.85rem;
        }

        h2 {
            font-size: 1.3rem !important;
        }
    }

    @media (max-width: 768px) {
        .tab-btn {
            padding: 0.6rem 0.3rem;
            font-size: 0.75rem;
        }

        div[style*="grid"] {
            grid-template-columns: 1fr !important;
        }
    }
</style>

<script>
    function showTab(tabName) {
        // Hide all tabs
        document.querySelectorAll('.tab-content').forEach(tab => {
            tab.style.display = 'none';
        });

        // Reset button styles
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.style.background = 'transparent';
            btn.style.color = '#666';
        });

        // Show selected tab
        document.getElementById(tabName).style.display = 'block';

        // Highlight selected button
        event.target.style.background = '#11669c';
        event.target.style.color = 'white';
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/dashboard/system-catalog.blade.php ENDPATH**/ ?>