<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'variant' => 'primary',
    'size' => 'md',
    'type' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'variant' => 'primary',
    'size' => 'md',
    'type' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $variantClass = match($variant) {
        'danger' => 'btn-danger',
        'success' => 'btn-ok',
        'secondary' => 'btn-secondary',
        default => '',
    };

    $sizeClass = match($size) {
        'sm' => 'btn-sm',
        'lg' => 'btn-lg',
        default => '',
    };

    $tag = $type ? 'button' : 'a';
?>

<?php if($tag === 'button'): ?>
    <button type="<?php echo e($type); ?>" <?php echo e($attributes->class(['btn', $variantClass, $sizeClass])); ?>>
        <?php echo e($slot); ?>

    </button>
<?php else: ?>
    <a <?php echo e($attributes->class(['btn', $variantClass, $sizeClass])); ?>>
        <?php echo e($slot); ?>

    </a>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\TSP-Restaurant-pointage\resources\views\components\admin\button.blade.php ENDPATH**/ ?>