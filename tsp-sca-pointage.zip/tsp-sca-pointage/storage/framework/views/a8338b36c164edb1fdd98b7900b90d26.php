<?php $__env->startSection('title', 'Dashboard Admin'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $f = $filters ?? [];
  $dateMode = $f['mode'] ?? 'range';
    $sourceFilter = $f['source'] ?? 'all';
    $rangeLabel = ($f['date_from'] ?? null) && ($f['date_to'] ?? null)
        ? (($f['date_from'] ?? '') . ' au ' . ($f['date_to'] ?? ''))
        : now()->toDateString();
?>

<style>
:root{--expanded-vh:100vh;--expanded-card-inset:0rem;--expanded-header-offset:250px}
.dashboard-grid{display:grid;gap:1.05rem}
.dashboard-chart-open{overflow:hidden;overscroll-behavior:none}
.dashboard-chart-open .topbar,.dashboard-chart-open .single-page-topbar{display:none!important}
.dashboard-chart-open .dashboard-hero{display:none}
.chart-expand-overlay{position:fixed;inset:0;background:transparent;display:none;opacity:0;pointer-events:none;transition:opacity .18s ease;z-index:1900}
.chart-expand-overlay.is-visible{display:block;opacity:1;pointer-events:none}
.dashboard-grid > *{animation:dashRise .45s ease both}
.dashboard-grid > *:nth-child(2){animation-delay:.04s}
.dashboard-grid > *:nth-child(3){animation-delay:.08s}
.dashboard-grid > *:nth-child(4){animation-delay:.12s}
.dashboard-grid > *:nth-child(5){animation-delay:.16s}
.dashboard-hero{background:radial-gradient(circle at 4% 6%,rgba(255,255,255,.3),transparent 46%),radial-gradient(circle at 96% 0%,rgba(196,221,255,.45),transparent 46%),linear-gradient(142deg,#0b3e7d 0%,#1458a7 46%,#1f70c6 100%);border:1px solid rgba(166,205,255,.34);border-radius:var(--radius);padding:1.12rem 1.2rem;color:#eef5ff;box-shadow:0 20px 40px rgba(11,50,100,.32);position:relative;overflow:hidden}
.dashboard-hero::after{content:"";position:absolute;width:220px;height:220px;right:-70px;top:-90px;border-radius:50%;background:rgba(255,255,255,.12);pointer-events:none}
.dashboard-hero::before{content:"";position:absolute;left:-120px;bottom:-120px;width:260px;height:260px;border-radius:50%;background:radial-gradient(circle,rgba(255,255,255,.22),rgba(255,255,255,0));pointer-events:none}
.dashboard-hero .ds-page-header{margin-bottom:.42rem;padding-bottom:0;border-bottom:0}
.dashboard-hero .ds-page-title{color:#f7fbff;font-size:1.25rem;letter-spacing:.22px;text-shadow:0 1px 0 rgba(5,23,46,.26)}
.dashboard-hero .ds-page-subtitle{color:rgba(227,238,255,.95);font-size:.92rem;max-width:920px;line-height:1.5}
.hero-context{margin-top:.2rem;padding:.48rem .68rem;border-radius:12px;background:linear-gradient(180deg,rgba(255,255,255,.15),rgba(255,255,255,.08));border:1px solid rgba(220,235,255,.35);color:#eaf3ff;font-size:.84rem;font-weight:700;width:fit-content;max-width:100%}
.hero-context strong{color:#ffffff;font-weight:800}
.hero-badges{margin-top:.72rem;display:flex;gap:.46rem;flex-wrap:wrap}
.hero-badge{display:inline-flex;align-items:center;border-radius:999px;padding:.28rem .7rem;font-size:.74rem;font-weight:800;letter-spacing:.22px;background:rgba(237,246,255,.2);border:1px solid rgba(221,237,255,.44);color:#f7fbff;box-shadow:inset 0 1px 0 rgba(255,255,255,.25)}
.filter-shell{background:linear-gradient(180deg,#ffffff,#f7fbff);border:1px solid var(--border);border-radius:var(--radius);padding:.95rem;box-shadow:var(--shadow-sm);position:relative;overflow:hidden}
.filter-shell::before{content:"";position:absolute;left:0;right:0;top:0;height:3px;background:linear-gradient(90deg,rgba(17,102,156,.72),rgba(26,121,184,.52),rgba(24,168,112,.36))}
.filter-shell h3{margin:0 0 .6rem;color:#1a3f6d;font-size:1rem}
.filter-grid{display:grid;gap:.75rem;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));align-items:end}
.filter-grid .actions{display:flex;gap:.45rem;flex-wrap:wrap}
.field-hidden{display:none!important}
.kpi-grid{display:grid;gap:.8rem;grid-template-columns:repeat(auto-fit,minmax(180px,1fr))}
.kpi-grid .card{transition:transform .16s ease,box-shadow .16s ease}
.kpi-grid .card:hover{transform:translateY(-2px) scale(1.01)}
.chart-grid{display:grid;gap:1rem;grid-template-columns:repeat(auto-fit,minmax(320px,1fr))}
.chart-card{background:linear-gradient(180deg,#ffffff,#f9fcff);border:1px solid var(--border);border-radius:var(--radius);padding:.95rem;box-shadow:var(--shadow-sm);display:grid;gap:.7rem;transition:transform .2s ease,box-shadow .2s ease;position:relative;overflow:hidden}
.chart-card::before{content:"";position:absolute;left:0;right:0;top:0;height:3px;background:linear-gradient(90deg,rgba(17,102,156,.65),rgba(26,121,184,.48),rgba(24,168,112,.34))}
.chart-card:hover{transform:translateY(-2px);box-shadow:0 16px 30px rgba(17,54,98,.14)}
.chart-card.is-expanded{position:fixed;inset:var(--expanded-card-inset);z-index:2000;display:flex;flex-direction:column;gap:.65rem;overflow-y:auto;overflow-x:hidden;height:calc(var(--expanded-vh) - (var(--expanded-card-inset) * 2));max-height:calc(var(--expanded-vh) - (var(--expanded-card-inset) * 2));padding:.8rem 0 1rem;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;touch-action:pan-y;box-shadow:0 18px 48px rgba(8,29,54,.22);transform:none;background:linear-gradient(180deg,#ffffff,#f7fbff);border-color:#a9c7ea;border-radius:0;border-left:0;border-right:0}
.chart-card.is-expanded:fullscreen{inset:0;width:100vw;height:100dvh;max-height:none;border-radius:0;border:0;padding:.8rem 0 1rem}
.chart-card.is-expanded:fullscreen .chart-head{top:0}
.chart-card.is-expanded .chart-head{position:sticky;top:0;z-index:3;background:linear-gradient(180deg,rgba(255,255,255,.99),rgba(248,252,255,.97));margin:0;padding:.95rem 1rem .75rem;border-bottom:1px solid #d8e7fa}
.chart-card.is-expanded .chart-meta,.chart-card.is-expanded .chart-box,.chart-card.is-expanded .chart-explain{margin:0 1rem}
.chart-card.is-expanded .chart-box{flex:1 1 auto;height:auto;min-height:240px;max-height:none;border-color:#c9dcf4}
.chart-card.is-expanded[data-chart-id="chartTopMeals"] .chart-box{min-height:300px}
.chart-card.is-expanded .chart-expand-btn{background:linear-gradient(180deg,#1458a7,#0f4c90);color:#fff;border-color:#0f4c90}
.chart-card.is-expanded .chart-close-btn{display:inline-flex}
.chart-card.is-expanded .chart-tools{width:100%;justify-content:flex-end;gap:.5rem}
.chart-card.is-expanded .chart-tools select{min-width:150px;min-height:2.3rem;font-size:.8rem;padding:.42rem .55rem}
.chart-card.is-expanded .chart-tools button{min-height:2.3rem;font-size:.8rem;padding:.42rem .68rem}
.chart-card.is-expanded .chart-tools select,.chart-card.is-expanded .chart-tools button{touch-action:manipulation}
.chart-card.is-expanded .chart-tools [data-export-chart]{background:#f2f8ff;border-color:#c6daf5;color:#1e5086}
.chart-card.is-expanded .chart-tools [data-export-chart]:hover{background:#e8f2ff}
.chart-card.is-expanded .chart-close-btn{border-color:#e0b6b6!important;color:#8d2e2e!important;background:#fff4f4!important}
.chart-card.is-expanded .chart-close-btn:hover{background:#ffeaea!important}
.chart-head{display:flex;align-items:flex-start;justify-content:space-between;gap:.7rem;flex-wrap:wrap}
.chart-head h3{margin:0;font-size:1rem;color:#1a3f6d}
.chart-sub{margin:.15rem 0 0;color:#567496;font-size:.8rem;font-weight:600}
.chart-tools{display:flex;align-items:center;gap:.45rem;flex-wrap:wrap}
.chart-tools select,.chart-tools button{margin:0;min-height:2rem;font-size:.76rem;font-weight:700;border-radius:9px}
.chart-tools select{width:auto;padding:.35rem .45rem;border:1px solid #c8dbf2;background:#f8fbff;color:#23476f}
.chart-tools button{border:1px solid #c8dbf2;background:#f8fbff;color:#1f4f84;padding:.34rem .55rem;cursor:pointer;transition:transform .14s ease,box-shadow .14s ease,background .14s ease}
.chart-tools button:hover{background:#eef5ff;transform:translateY(-1px);box-shadow:0 8px 14px rgba(28,74,129,.14)}
.chart-expand-btn{display:inline-flex;align-items:center;gap:.35rem}
.chart-expand-btn::before{content:"⤢";font-size:.85rem;line-height:1}
.chart-close-btn{display:none;align-items:center;gap:.35rem;border-color:#d3a6a6!important;color:#8d2e2e!important;background:#fff5f5!important}
.chart-close-btn::before{content:"✕";font-size:.82rem;line-height:1}
.chart-expanded-hint{display:none;font-size:.74rem;color:#5a7697;font-weight:700;background:#edf5ff;border:1px solid #d6e6fb;border-radius:999px;padding:.22rem .5rem}
.chart-card.is-expanded .chart-expanded-hint{display:inline-flex}
.chart-meta{display:flex;flex-wrap:wrap;gap:.4rem;font-size:.74rem;color:#5f7e9f;font-weight:700}
.chart-meta span{border-radius:999px;background:#f1f7ff;border:1px solid #d8e6fa;padding:.2rem .48rem}
.chart-box{min-height:250px;height:260px;position:relative;background:linear-gradient(180deg,#fbfdff,#f5f9ff);border-radius:10px;overflow:hidden;border:1px solid #e2ecfa}
.chart-card[data-chart-id="chartTopMeals"] .chart-box{min-height:250px}
.chart-box::after{content:"";position:absolute;inset:auto 0 0 0;height:1px;background:linear-gradient(90deg,rgba(43,123,216,.05),rgba(43,123,216,.35),rgba(43,123,216,.05));pointer-events:none}
.chart-box canvas{display:block;width:100%!important;height:100%!important;max-width:100%!important}
.chart-explain{margin:0;color:#5d7b9a;font-size:.82rem;line-height:1.45;border-top:1px dashed #d9e7f7;padding-top:.55rem}
.section-grid{display:grid;gap:1rem;grid-template-columns:repeat(auto-fit,minmax(460px,1fr))}
.section-card{background:linear-gradient(180deg,#ffffff,#f9fcff);border:1px solid var(--border);border-radius:var(--radius);padding:.9rem;box-shadow:var(--shadow-sm);position:relative;overflow:hidden}
.section-card::before{content:"";position:absolute;left:0;right:0;top:0;height:2px;background:linear-gradient(90deg,rgba(17,102,156,.48),rgba(26,121,184,.34),rgba(24,168,112,.26))}
.section-card h3{margin:0 0 .75rem;font-size:1rem;color:#1a3f6d}
.section-table-wrap{width:100%;overflow:auto;border-radius:var(--radius-sm);border:1px solid var(--border);background:#fff}
.section-table-wrap table{border:0;border-radius:0;min-width:640px}
.pill{display:inline-block;border-radius:999px;padding:.18rem .5rem;font-size:.76rem;font-weight:700;text-transform:uppercase}
.pill-approved{background:#ddf6e6;color:#155c33}
.pill-denied{background:#feeaea;color:#8a2424}
.pill-info{background:#e7f0ff;color:#194a82}
.empty-note{color:var(--muted);font-size:.9rem}
tbody tr{transition:background .14s ease,transform .14s ease}
tbody tr:hover{background:#f4f9ff;transform:translateX(1px)}
@keyframes dashRise{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
@media (prefers-reduced-motion:reduce){.dashboard-grid > *,.kpi-grid .card,.chart-card,.chart-tools button,tbody tr{animation:none!important;transition:none!important}}
@media(max-width:960px){.section-grid{grid-template-columns:1fr}.chart-box{height:230px}.dashboard-hero{padding:1rem}.dashboard-hero .ds-page-title{font-size:1.12rem}.hero-context{width:100%}.chart-card.is-expanded{inset:var(--expanded-card-inset);padding:.55rem 0 .75rem;max-height:calc(var(--expanded-vh) - (var(--expanded-card-inset) * 2))}.chart-card.is-expanded .chart-head{top:0;padding:.75rem .7rem .6rem}.chart-card.is-expanded .chart-meta,.chart-card.is-expanded .chart-box,.chart-card.is-expanded .chart-explain{margin:0 .7rem}.chart-card.is-expanded .chart-box{min-height:190px}.chart-card.is-expanded[data-chart-id="chartTopMeals"] .chart-box{min-height:240px}.chart-card[data-chart-id="chartTopMeals"] .chart-box{min-height:220px}.chart-card.is-expanded .chart-tools{display:grid;grid-template-columns:1fr 1fr;gap:.45rem;align-items:stretch}.chart-card.is-expanded .chart-tools select{grid-column:1/-1;width:100%;min-width:0}.chart-card.is-expanded .chart-tools button{width:100%;justify-content:center}}
</style>

<div class="dashboard-grid">
    <div class="dashboard-hero">
        <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Dashboard Administration','subtitle' => 'Pilotage global: Employés, La Relève, Extra, plats et performance financière']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dashboard Administration','subtitle' => 'Pilotage global: Employés, La Relève, Extra, plats et performance financière']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
      <div class="hero-context">
        <strong>Période analysée:</strong> <?php echo e($rangeLabel); ?> &nbsp;•&nbsp; <strong>Source:</strong> <?php echo e(strtoupper(str_replace('_', ' ', $sourceFilter))); ?>

      </div> 
      <div class="hero-badges">
        <span class="hero-badge">Vue multi-sources</span>
        <span class="hero-badge">Analyse financière</span>
        <span class="hero-badge">Graphes interactifs</span>
      </div>
    </div>

    <section class="filter-shell">
        <h3>Filtres analytiques avancés</h3>
        <form method="GET" action="<?php echo e(route('dashboard.index')); ?>" class="filter-grid">
            <div>
                <label for="mode">Mode période</label>
                <select id="mode" name="mode">
                    <option value="day" <?php echo e($dateMode === 'day' ? 'selected' : ''); ?>>Jour unique</option>
                    <option value="range" <?php echo e($dateMode === 'range' ? 'selected' : ''); ?>>Intervalle</option>
                </select>
            </div>

            <div id="singleDateField">
                <label for="date">Date</label>
                <input id="date" type="date" name="date" value="<?php echo e($f['date'] ?? now()->toDateString()); ?>">
            </div>

            <div id="rangeDateFromField">
                <label for="date_from">Du</label>
                <input id="date_from" type="date" name="date_from" value="<?php echo e($f['date_from'] ?? ''); ?>">
            </div>

            <div id="rangeDateToField">
                <label for="date_to">Au</label>
                <input id="date_to" type="date" name="date_to" value="<?php echo e($f['date_to'] ?? ''); ?>">
            </div>

            <div>
                <label for="source">Source des données</label>
                <select id="source" name="source">
                    <option value="all" <?php echo e($sourceFilter === 'all' ? 'selected' : ''); ?>>Tout</option>
                    <option value="employee" <?php echo e($sourceFilter === 'employee' ? 'selected' : ''); ?>>Employés NFC</option>
                    <option value="la_releve" <?php echo e($sourceFilter === 'la_releve' ? 'selected' : ''); ?>>La Relève</option>
                    <option value="extra" <?php echo e($sourceFilter === 'extra' ? 'selected' : ''); ?>>Extra</option>
                </select>
            </div>

            <div>
                <label for="meal_rule_id">Filtrer par plat / règle</label>
                <select id="meal_rule_id" name="meal_rule_id">
                    <option value="0">Tous les plats</option>
                    <?php $__currentLoopData = $mealRules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($rule->id); ?>" <?php echo e((int) ($f['meal_rule_id'] ?? 0) === (int) $rule->id ? 'selected' : ''); ?>>
                            <?php echo e($rule->name); ?><?php echo e($rule->is_active ? '' : ' (inactif)'); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <label for="department_id">Département (employés)</label>
                <select id="department_id" name="department_id">
                    <option value="0">Tous les départements</option>
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($department->id); ?>" <?php echo e((int) ($f['department_id'] ?? 0) === (int) $department->id ? 'selected' : ''); ?>>
                            <?php echo e($department->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="actions">
                <button class="btn" type="submit">Appliquer</button>
                <a class="btn btn-secondary" href="<?php echo e(route('dashboard.index')); ?>">Réinitialiser</a>
            </div>
        </form>
    </section>

    <section class="kpi-grid">
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Repas servis (filtre)','value' => number_format((int) $kpis['meals_served_total']),'tone' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Repas servis (filtre)','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) $kpis['meals_served_total'])),'tone' => 'success']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Employés NFC','value' => number_format((int) $kpis['employee_meals']),'tone' => 'info']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Employés NFC','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) $kpis['employee_meals'])),'tone' => 'info']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'La Relève','value' => number_format((int) $kpis['la_releve_meals']),'tone' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'La Relève','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) $kpis['la_releve_meals'])),'tone' => 'primary']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Extra','value' => number_format((int) $kpis['extra_meals']),'tone' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Extra','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) $kpis['extra_meals'])),'tone' => 'primary']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Scans refusés','value' => number_format((int) $kpis['denied_scans_total']),'tone' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Scans refusés','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) $kpis['denied_scans_total'])),'tone' => 'danger']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Taux d\'autorisation','value' => number_format((float) $kpis['authorization_rate_today'], 1) . '%','tone' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Taux d\'autorisation','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((float) $kpis['authorization_rate_today'], 1) . '%'),'tone' => 'primary']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'CA théorique','value' => number_format((float) $kpis['finance_total'], 2) . ' DA','tone' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'CA théorique','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((float) $kpis['finance_total'], 2) . ' DA'),'tone' => 'success']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Ticket moyen','value' => number_format((float) $kpis['average_ticket'], 2) . ' DA','tone' => 'info']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Ticket moyen','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((float) $kpis['average_ticket'], 2) . ' DA'),'tone' => 'info']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Employés actifs','value' => $kpis['active_employees']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Employés actifs','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['active_employees'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Cartes bloquées','value' => $kpis['blocked_cards'],'tone' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Cartes bloquées','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['blocked_cards']),'tone' => 'danger']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
    </section>

    <section class="chart-grid">
        <article class="chart-card">
            <div class="chart-head">
              <div><h3>Repas servis par heure</h3><p class="chart-sub">Volume horaire global selon les filtres.</p></div>
              <div class="chart-tools">
                <select id="mealsMode" aria-label="Mode repas par heure"><option value="line">Ligne</option><option value="bar">Barre</option></select>
                <button type="button" data-export-chart="chartMealsByHour">Exporter PNG</button>
                <button type="button" class="chart-expand-btn" data-chart-expand="chartMealsByHour" aria-pressed="false">Agrandir</button>
                <button type="button" class="chart-close-btn" data-chart-close="chartMealsByHour">Fermer</button>
              </div>
            </div>
            <div class="chart-meta"><span>Interaction au survol</span><span>Animation progressive</span><span class="chart-expanded-hint">Échap pour fermer</span></div>
            <div class="chart-box"><canvas id="chartMealsByHour"></canvas></div>
            <p class="chart-explain">Ce graphe montre les pics horaires de consommation. Utilisez-le pour ajuster la capacité du service (personnel, volume cuisine, timing des préparations).</p>
        </article>

        <article class="chart-card">
            <div class="chart-head">
              <div><h3>Autorisé vs refusé</h3><p class="chart-sub">Comparaison quotidienne sur la période choisie.</p></div>
              <div class="chart-tools">
                <select id="authMode" aria-label="Mode autorisé refusé"><option value="grouped">Groupé</option><option value="stacked">Empilé</option></select>
                <button type="button" data-export-chart="chartAuthDenied">Exporter PNG</button>
                <button type="button" class="chart-expand-btn" data-chart-expand="chartAuthDenied" aria-pressed="false">Agrandir</button>
                <button type="button" class="chart-close-btn" data-chart-close="chartAuthDenied">Fermer</button>
              </div>
            </div>
            <div class="chart-meta"><span>Vue opérationnelle</span><span>Qualité des validations</span><span class="chart-expanded-hint">Échap pour fermer</span></div>
            <div class="chart-box"><canvas id="chartAuthDenied"></canvas></div>
            <p class="chart-explain">Ce graphe compare les validations et refus par jour. Une hausse des refus peut signaler des problèmes de carte, de règles repas ou de paramètres d’accès.</p>
        </article>

        <article class="chart-card">
            <div class="chart-head">
              <div><h3>Top plats les plus consommés</h3><p class="chart-sub">Classement des plats/règles les plus demandés.</p></div>
              <div class="chart-tools">
                <select id="topMealsLimit" aria-label="Nombre de plats"><option value="5">Top 5</option><option value="10" selected>Top 10</option><option value="20">Top 20</option></select>
                <button type="button" data-export-chart="chartTopMeals">Exporter PNG</button>
                <button type="button" class="chart-expand-btn" data-chart-expand="chartTopMeals" aria-pressed="false">Agrandir</button>
                <button type="button" class="chart-close-btn" data-chart-close="chartTopMeals">Fermer</button>
              </div>
            </div>
            <div class="chart-meta"><span>Pilotage offre repas</span><span>Aide à la planification</span><span class="chart-expanded-hint">Échap pour fermer</span></div>
            <div class="chart-box"><canvas id="chartTopMeals"></canvas></div>
            <p class="chart-explain">Ce classement identifie les plats les plus demandés. Il aide à prioriser les achats, anticiper les stocks et réduire les ruptures.</p>
        </article>

        <article class="chart-card">
            <div class="chart-head">
              <div><h3>Analyse financière par plat</h3><p class="chart-sub">Calcul théorique basé sur le coût de chaque règle.</p></div>
              <div class="chart-tools">
                <select id="financeMode" aria-label="Mode finance"><option value="bar">Barre</option><option value="line">Ligne</option></select>
                <button type="button" data-export-chart="chartFinanceByMeal">Exporter PNG</button>
                <button type="button" class="chart-expand-btn" data-chart-expand="chartFinanceByMeal" aria-pressed="false">Agrandir</button>
                <button type="button" class="chart-close-btn" data-chart-close="chartFinanceByMeal">Fermer</button>
              </div>
            </div>
            <div class="chart-meta"><span>CA par plat</span><span>Lecture budgétaire rapide</span><span class="chart-expanded-hint">Échap pour fermer</span></div>
            <div class="chart-box"><canvas id="chartFinanceByMeal"></canvas></div>
            <p class="chart-explain">Ce graphe estime le montant généré par plat selon les coûts configurés. Il permet d’évaluer rapidement les contributions financières par type de repas.</p>
        </article>

        <article class="chart-card">
            <div class="chart-head">
              <div><h3>Repas par département</h3><p class="chart-sub">Conso des employés par service.</p></div>
              <div class="chart-tools">
                <select id="departmentMode" aria-label="Mode graphique service"><option value="vertical">Vertical</option><option value="horizontal">Horizontal</option></select>
                <button type="button" data-export-chart="chartByDepartment">Exporter PNG</button>
                <button type="button" class="chart-expand-btn" data-chart-expand="chartByDepartment" aria-pressed="false">Agrandir</button>
                <button type="button" class="chart-close-btn" data-chart-close="chartByDepartment">Fermer</button>
              </div>
            </div>
            <div class="chart-meta"><span>Capacité service</span><span>Répartition interne</span><span class="chart-expanded-hint">Échap pour fermer</span></div>
            <div class="chart-box"><canvas id="chartByDepartment"></canvas></div>
            <p class="chart-explain">Ce graphe montre la consommation par département. Il facilite le suivi des usages internes et l’équilibrage des ressources entre services.</p>
        </article>

        <article class="chart-card">
            <div class="chart-head">
              <div><h3>Raisons de refus</h3><p class="chart-sub">Analyse détaillée des anomalies de scan.</p></div>
              <div class="chart-tools">
                <select id="denialMode" aria-label="Mode raisons de refus"><option value="doughnut">Donut</option><option value="polarArea">Zone polaire</option><option value="bar">Barre</option></select>
                <button type="button" data-export-chart="chartDenialReasons">Exporter PNG</button>
                <button type="button" class="chart-expand-btn" data-chart-expand="chartDenialReasons" aria-pressed="false">Agrandir</button>
                <button type="button" class="chart-close-btn" data-chart-close="chartDenialReasons">Fermer</button>
              </div>
            </div>
            <div class="chart-meta"><span>Tooltip avec pourcentage</span><span>Priorisation des actions</span><span class="chart-expanded-hint">Échap pour fermer</span></div>
            <div class="chart-box"><canvas id="chartDenialReasons"></canvas></div>
            <p class="chart-explain">Ce graphe détaille les causes principales de refus. Concentrez les actions correctives sur les motifs dominants pour améliorer le taux d’autorisation.</p>
        </article>
    </section>

      <div id="chartExpandOverlay" class="chart-expand-overlay" aria-hidden="true"></div>

    <section class="section-grid">
        <article class="section-card">
            <h3>Activité combinée récente</h3>
            <div class="section-table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Source</th>
                            <th>Personne</th>
                            <th>Plat</th>
                            <th>Statut</th>
                            <th>Montant</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $recentCombinedActivity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e(\Carbon\Carbon::parse($item['at'])->format('Y-m-d H:i')); ?></td>
                                <td><span class="pill pill-info"><?php echo e(strtoupper($item['source'])); ?></span></td>
                                <td><?php echo e($item['person'] !== '' ? $item['person'] : '-'); ?></td>
                                <td><?php echo e($item['meal']); ?></td>
                                <td><span class="pill <?php echo e(in_array($item['status'], ['approved', 'authorized'], true) ? 'pill-approved' : 'pill-denied'); ?>"><?php echo e($item['status']); ?></span></td>
                                <td><?php echo e(number_format((float) $item['amount'], 2)); ?> DA</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="6" class="empty-note">Aucune activité récente.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </article>

        <article class="section-card">
            <h3>Derniers scans refusés (NFC)</h3>
            <div class="section-table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>UID</th>
                            <th>Employé</th>
                            <th>Raison</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $latestDeniedScans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($log->logged_at?->format('Y-m-d H:i')); ?></td>
                                <td><?php echo e($log->card_uid ?: ($log->card?->uid ?? '-')); ?></td>
                                <td><?php echo e(trim(($log->employee?->first_name ?? '') . ' ' . ($log->employee?->last_name ?? '')) ?: '-'); ?></td>
                                <td><?php echo e($log->reason ?: '-'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="4" class="empty-note">Aucun refus récent.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </article>

        <article class="section-card">
            <h3>Derniers logs repas NFC</h3>
            <div class="section-table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>UID</th>
                            <th>Employé</th>
                            <th>Statut</th>
                            <th>Plat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $latestMealLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($log->logged_at?->format('Y-m-d H:i')); ?></td>
                                <td><?php echo e($log->card_uid ?: ($log->card?->uid ?? '-')); ?></td>
                                <td><?php echo e(trim(($log->employee?->first_name ?? '') . ' ' . ($log->employee?->last_name ?? '')) ?: '-'); ?></td>
                                <td><span class="pill <?php echo e(in_array($log->status, ['approved', 'authorized'], true) ? 'pill-approved' : 'pill-denied'); ?>"><?php echo e($log->status); ?></span></td>
                                <td><?php echo e($log->mealRule?->name ?? ($log->meal_type ?? '-')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="5" class="empty-note">Aucun log disponible.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </article>

        <article class="section-card">
            <h3>Alertes cartes bloquées</h3>
            <div class="section-table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>UID</th>
                            <th>Employé</th>
                            <th>État</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $blockedCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($card->uid); ?></td>
                                <td><?php echo e(trim(($card->employee?->first_name ?? '') . ' ' . ($card->employee?->last_name ?? '')) ?: 'Non assigné'); ?></td>
                                <td><span class="pill pill-denied">Bloquée</span></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="3" class="empty-note">Aucune carte bloquée.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </article>
    </section>
</div>

<div id="dashboard-datasets"
  data-meals-by-hour='<?php echo json_encode($chartMealsByHour, 15, 512) ?>'
  data-auth-denied='<?php echo json_encode($chartAuthorizedDenied7d, 15, 512) ?>'
  data-meals-by-department='<?php echo json_encode($chartMealsByDepartment, 15, 512) ?>'
  data-denial-reasons='<?php echo json_encode($chartDenialReasons, 15, 512) ?>'
  data-top-meals='<?php echo json_encode($chartTopMeals, 15, 512) ?>'
  data-finance-by-meal='<?php echo json_encode($chartFinanceByMeal, 15, 512) ?>'></div>

<script src="<?php echo e(asset('assets/chart.umd.min.js')); ?>"></script>
<script>
(function() {
  const modeSelect = document.getElementById('mode');
  const singleDateField = document.getElementById('singleDateField');
  const rangeDateFromField = document.getElementById('rangeDateFromField');
  const rangeDateToField = document.getElementById('rangeDateToField');
  const dateInput = document.getElementById('date');
  const dateFromInput = document.getElementById('date_from');
  const dateToInput = document.getElementById('date_to');

  const syncDateFilterMode = () => {
    if (!modeSelect) return;

    const isDayMode = modeSelect.value === 'day';

    if (singleDateField) {
      singleDateField.classList.toggle('field-hidden', !isDayMode);
    }

    if (rangeDateFromField) {
      rangeDateFromField.classList.toggle('field-hidden', isDayMode);
    }

    if (rangeDateToField) {
      rangeDateToField.classList.toggle('field-hidden', isDayMode);
    }

    if (dateInput) {
      dateInput.disabled = !isDayMode;
    }

    if (dateFromInput) {
      dateFromInput.disabled = isDayMode;
    }

    if (dateToInput) {
      dateToInput.disabled = isDayMode;
    }

    if (isDayMode) {
      if (dateInput && !dateInput.value) {
        dateInput.value = (dateFromInput && dateFromInput.value) ? dateFromInput.value : new Date().toISOString().slice(0, 10);
      }
    } else {
      if (dateFromInput && !dateFromInput.value && dateInput && dateInput.value) {
        dateFromInput.value = dateInput.value;
      }

      if (dateToInput && !dateToInput.value && dateInput && dateInput.value) {
        dateToInput.value = dateInput.value;
      }
    }
  };

  if (modeSelect) {
    syncDateFilterMode();
    modeSelect.addEventListener('change', syncDateFilterMode);
  }

  if (typeof window.Chart === 'undefined') {
    console.error('[CHART] Chart.js non charge');
    return;
  }

  const n = document.getElementById('dashboard-datasets');
  if (!n) return;

  const p = (r) => { try { return JSON.parse(r || '{}'); } catch (e) { return {}; } };
  const a = (v) => Array.isArray(v) ? v : (v && typeof v === 'object' ? Object.values(v) : []);
  const fmt = (v) => new Intl.NumberFormat('fr-FR').format(Number(v || 0));

  const d = {
    h: p(n.dataset.mealsByHour),
    ad: p(n.dataset.authDenied),
    md: p(n.dataset.mealsByDepartment),
    dr: p(n.dataset.denialReasons),
    tm: p(n.dataset.topMeals),
    fm: p(n.dataset.financeByMeal)
  };

  d.h.labels = a(d.h.labels || []);
  d.h.data = a(d.h.data || []).map(x => Number(x || 0));
  d.ad.labels = a(d.ad.labels || []);
  d.ad.authorized = a(d.ad.authorized || []).map(x => Number(x || 0));
  d.ad.denied = a(d.ad.denied || []).map(x => Number(x || 0));
  d.md.labels = a(d.md.labels || []);
  d.md.data = a(d.md.data || []).map(x => Number(x || 0));
  d.dr.labels = a(d.dr.labels || []);
  d.dr.data = a(d.dr.data || []).map(x => Number(x || 0));
  d.tm.labels = a(d.tm.labels || []);
  d.tm.data = a(d.tm.data || []).map(x => Number(x || 0));
  d.fm.labels = a(d.fm.labels || []);
  d.fm.data = a(d.fm.data || []).map(x => Number(x || 0));

  const st = { m: 'line', a: 'grouped', dm: 'vertical', dr: 'doughnut', fm: 'bar', top: 10 };
  const ch = {};
  const chartExpandOverlay = document.getElementById('chartExpandOverlay');
  let expandedChartId = null;
  let expandedTriggerButton = null;

  const updateExpandedViewportMetrics = () => {
    const viewportHeight = Math.max(
      320,
      Math.round((window.visualViewport && window.visualViewport.height) || window.innerHeight || document.documentElement.clientHeight || 0)
    );
    const isCompact = window.matchMedia('(max-width: 960px)').matches;
    const isShortScreen = viewportHeight < 700;
    const headerOffset = isCompact ? (isShortScreen ? 210 : 230) : (isShortScreen ? 230 : 250);

    document.documentElement.style.setProperty('--expanded-vh', `${viewportHeight}px`);
    document.documentElement.style.setProperty('--expanded-card-inset', '0rem');
    document.documentElement.style.setProperty('--expanded-header-offset', `${headerOffset}px`);
  };

  const resetExpandedUiState = () => {
    document.body.classList.remove('dashboard-chart-open');
    document.querySelectorAll('.chart-card.is-expanded').forEach((card) => {
      card.classList.remove('is-expanded');
      card.setAttribute('aria-expanded', 'false');
    });
    document.querySelectorAll('.chart-expand-btn[aria-pressed="true"]').forEach((button) => {
      button.setAttribute('aria-pressed', 'false');
      button.textContent = 'Agrandir';
    });

    if (chartExpandOverlay) {
      chartExpandOverlay.classList.remove('is-visible');
      chartExpandOverlay.setAttribute('aria-hidden', 'true');
    }

    expandedChartId = null;
    expandedTriggerButton = null;
  };

  const basePlugins = () => ({
    legend: { labels: { color: '#365377', boxWidth: 14, usePointStyle: true, pointStyle: 'circle' } },
    tooltip: {
      backgroundColor: 'rgba(15, 36, 64, 0.92)',
      titleColor: '#eff6ff',
      bodyColor: '#d8e8ff',
      borderColor: 'rgba(130, 170, 220, 0.35)',
      borderWidth: 1,
      padding: 10,
      cornerRadius: 10,
      displayColors: true
    }
  });

  const commonInteraction = { mode: 'nearest', intersect: false, axis: 'x' };
  const onHoverCursor = (event, activeEls) => {
    const target = event && event.native ? event.native.target : null;
    if (target) target.style.cursor = activeEls && activeEls.length ? 'pointer' : 'default';
  };

  const co = (stacked) => ({
    responsive: true,
    maintainAspectRatio: false,
    interaction: commonInteraction,
    plugins: basePlugins(),
    animation: { duration: 900, easing: 'easeOutCubic' },
    onHover: onHoverCursor,
    scales: {
      x: { stacked: stacked, ticks: { color: '#4a6789' }, grid: { color: '#e4edf8' } },
      y: { stacked: stacked, beginAtZero: true, ticks: { color: '#4a6789' }, grid: { color: '#e4edf8' } }
    }
  });

  const fe = (arr, len) => arr.length > 0 ? arr : Array(len || 1).fill(0);
  const de = (id) => { if (ch[id]) ch[id].destroy(); };

  const sliceTop = (labels, values, limit) => ({
    labels: labels.slice(0, limit),
    values: values.slice(0, limit)
  });

  const render = {
    h: () => {
      de('h');
      const labels = d.h.labels.length ? d.h.labels : ['--'];
      const values = fe(d.h.data, labels.length);
      ch.h = new Chart(document.getElementById('chartMealsByHour'), {
        type: st.m,
        data: {
          labels: labels,
          datasets: [{
            label: 'Repas servis',
            data: values,
            borderColor: '#2b7bd8',
            backgroundColor: st.m === 'line' ? 'rgba(43,123,216,0.2)' : 'rgba(43,123,216,0.72)',
            borderWidth: 2,
            pointRadius: st.m === 'line' ? 3 : 0,
            pointHoverRadius: st.m === 'line' ? 5 : 0,
            fill: st.m === 'line',
            tension: .34,
            borderRadius: 8
          }]
        },
        options: {
          ...co(false),
          plugins: {
            ...basePlugins(),
            tooltip: { ...basePlugins().tooltip, callbacks: { label: (ctx) => ` ${fmt(ctx.parsed.y)} repas` } }
          }
        }
      });
    },

    ad: () => {
      de('ad');
      const labels = d.ad.labels.length ? d.ad.labels : ['--'];
      ch.ad = new Chart(document.getElementById('chartAuthDenied'), {
        type: 'bar',
        data: {
          labels: labels,
          datasets: [
            { label: 'Autorisé', data: fe(d.ad.authorized, labels.length), backgroundColor: '#1f8f4e', borderRadius: 8 },
            { label: 'Refusé', data: fe(d.ad.denied, labels.length), backgroundColor: '#c53030', borderRadius: 8 }
          ]
        },
        options: {
          ...co(st.a === 'stacked'),
          plugins: {
            ...basePlugins(),
            tooltip: { ...basePlugins().tooltip, callbacks: { label: (ctx) => ` ${ctx.dataset.label}: ${fmt(ctx.parsed.y)}` } }
          }
        }
      });
    },

    tm: () => {
      de('tm');
      const top = sliceTop(d.tm.labels, d.tm.data, st.top);
      const labels = top.labels.length ? top.labels : ['--'];
      const useHorizontal = window.matchMedia('(max-width: 680px)').matches;
      ch.tm = new Chart(document.getElementById('chartTopMeals'), {
        type: 'bar',
        data: {
          labels: labels,
          datasets: [{ label: 'Nombre de repas', data: fe(top.values, labels.length), backgroundColor: '#12845b', borderRadius: 8 }]
        },
        options: {
          ...co(false),
          indexAxis: useHorizontal ? 'y' : 'x',
          scales: useHorizontal
            ? {
                x: { beginAtZero: true, ticks: { color: '#4a6789' }, grid: { color: '#e4edf8' } },
                y: {
                  ticks: { color: '#4a6789', autoSkip: false },
                  grid: { color: '#e4edf8' }
                }
              }
            : {
                x: {
                  ticks: {
                    color: '#4a6789',
                  minRotation: 0,
                  maxRotation: 40,
                  autoSkip: false
                  },
                  grid: { color: '#e4edf8' }
                },
                y: { beginAtZero: true, ticks: { color: '#4a6789' }, grid: { color: '#e4edf8' } }
              },
          plugins: {
            ...basePlugins(),
            tooltip: {
              ...basePlugins().tooltip,
              callbacks: {
                title: (items) => (items && items.length ? labels[items[0].dataIndex] : ''),
                label: (ctx) => ` ${fmt(ctx.parsed.y ?? ctx.parsed.x)} repas`
              }
            }
          }
        }
      });
    },

    fm: () => {
      de('fm');
      const labels = d.fm.labels.length ? d.fm.labels : ['--'];
      ch.fm = new Chart(document.getElementById('chartFinanceByMeal'), {
        type: st.fm,
        data: {
          labels: labels,
          datasets: [{
            label: 'Montant (DA)',
            data: fe(d.fm.data, labels.length),
            borderColor: '#1f5fbf',
            backgroundColor: st.fm === 'line' ? 'rgba(31,95,191,0.15)' : 'rgba(31,95,191,0.74)',
            fill: st.fm === 'line',
            tension: .3,
            borderWidth: 2,
            borderRadius: 8,
            pointRadius: st.fm === 'line' ? 3 : 0,
            pointHoverRadius: st.fm === 'line' ? 5 : 0
          }]
        },
        options: {
          ...co(false),
          plugins: {
            ...basePlugins(),
            tooltip: { ...basePlugins().tooltip, callbacks: { label: (ctx) => ` ${fmt(ctx.parsed.y)} DA` } }
          }
        }
      });
    },

    md: () => {
      de('md');
      const labels = d.md.labels.length ? d.md.labels : ['--'];
      ch.md = new Chart(document.getElementById('chartByDepartment'), {
        type: 'bar',
        data: { labels: labels, datasets: [{ label: 'Repas', data: fe(d.md.data, labels.length), backgroundColor: '#1f5fbf', borderRadius: 8 }] },
        options: {
          ...co(false),
          indexAxis: st.dm === 'horizontal' ? 'y' : 'x',
          plugins: {
            ...basePlugins(),
            tooltip: { ...basePlugins().tooltip, callbacks: { label: (ctx) => ` ${fmt(ctx.parsed.y ?? ctx.parsed.x)} repas` } }
          }
        }
      });
    },

    dr: () => {
      de('dr');
      const labels = d.dr.labels.length ? d.dr.labels : ['--'];
      const denialData = fe(d.dr.data, labels.length);
      const total = denialData.reduce((s, v) => s + Number(v || 0), 0);
      ch.dr = new Chart(document.getElementById('chartDenialReasons'), {
        type: st.dr,
        data: {
          labels: labels,
          datasets: [{
            label: 'Refus',
            data: denialData,
            backgroundColor: ['#c53030', '#d95b2a', '#d29c21', '#4f77bb', '#6f64be', '#3c8d6f', '#9f4550'],
            borderRadius: 8,
            hoverOffset: st.dr === 'bar' ? 0 : 10
          }]
        },
        options: st.dr === 'bar'
          ? {
              ...co(false),
              plugins: {
                ...basePlugins(),
                tooltip: { ...basePlugins().tooltip, callbacks: { label: (ctx) => ` ${fmt(ctx.parsed.y)} cas` } }
              }
            }
          : {
              responsive: true,
              maintainAspectRatio: false,
              interaction: { mode: 'nearest', intersect: true },
              onHover: onHoverCursor,
              animation: { duration: 950, easing: 'easeOutCubic' },
              plugins: {
                ...basePlugins(),
                legend: { position: 'bottom', labels: { color: '#365377', boxWidth: 12, usePointStyle: true, pointStyle: 'circle' } },
                tooltip: {
                  ...basePlugins().tooltip,
                  callbacks: {
                    label: (ctx) => {
                      const value = Number(ctx.raw || 0);
                      const pct = total > 0 ? ((value / total) * 100).toFixed(1) : '0.0';
                      return ` ${ctx.label}: ${fmt(value)} (${pct}%)`;
                    }
                  }
                }
              }
            }
      });
    }
  };

  const bind = (id, handler) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener('change', handler);
  };

  const resizeChartSafely = (chartId) => {
    const chart = ch[chartId];
    if (!chart) return;
    window.requestAnimationFrame(() => {
      chart.resize();
      chart.update('none');
    });
  };

  const closeExpandedChart = () => {
    if (!expandedChartId) return;

    if (document.fullscreenElement && typeof document.exitFullscreen === 'function') {
      document.exitFullscreen().catch(() => {});
    }

    const activeCard = document.querySelector(`.chart-card[data-chart-id="${expandedChartId}"]`);
    const activeButton = document.querySelector(`.chart-expand-btn[data-chart-expand="${expandedChartId}"]`);

    if (activeCard) {
      activeCard.classList.remove('is-expanded');
      activeCard.setAttribute('aria-expanded', 'false');
    }

    if (activeButton) {
      activeButton.setAttribute('aria-pressed', 'false');
      activeButton.textContent = 'Agrandir';
    }

    document.body.classList.remove('dashboard-chart-open');
    if (chartExpandOverlay) {
      chartExpandOverlay.classList.remove('is-visible');
      chartExpandOverlay.setAttribute('aria-hidden', 'true');
    }

    const previousExpandedId = expandedChartId;
    expandedChartId = null;
    resizeChartSafely(previousExpandedId);

    if (expandedTriggerButton) {
      expandedTriggerButton.focus({ preventScroll: true });
      expandedTriggerButton = null;
    }
  };

  const toggleExpandedChart = (chartId) => {
    if (!chartId) return;

    if (expandedChartId && expandedChartId !== chartId) {
      closeExpandedChart();
    }

    const card = document.querySelector(`.chart-card[data-chart-id="${chartId}"]`);
    const button = document.querySelector(`.chart-expand-btn[data-chart-expand="${chartId}"]`);
    if (!card || !button) return;

    const shouldExpand = !card.classList.contains('is-expanded');
    card.classList.toggle('is-expanded', shouldExpand);
    card.setAttribute('aria-expanded', shouldExpand ? 'true' : 'false');
    document.body.classList.toggle('dashboard-chart-open', shouldExpand);
    if (chartExpandOverlay) {
      chartExpandOverlay.classList.toggle('is-visible', shouldExpand);
      chartExpandOverlay.setAttribute('aria-hidden', shouldExpand ? 'false' : 'true');
    }
    button.setAttribute('aria-pressed', shouldExpand ? 'true' : 'false');
    button.textContent = shouldExpand ? 'Réduire' : 'Agrandir';
    expandedChartId = shouldExpand ? chartId : null;

    if (shouldExpand) {
      expandedTriggerButton = button;

      if (typeof card.requestFullscreen === 'function' && !document.fullscreenElement) {
        card.requestFullscreen({ navigationUI: 'hide' }).catch(() => {});
      }
    }

    updateExpandedViewportMetrics();
    resizeChartSafely(chartId);
  };

  const handleViewportResize = () => {
    updateExpandedViewportMetrics();
    if (expandedChartId) {
      resizeChartSafely(expandedChartId);
    }
  };

  document.querySelectorAll('.chart-card').forEach((card) => {
    const canvas = card.querySelector('canvas[id]');
    if (canvas) {
      card.dataset.chartId = canvas.id;
      card.setAttribute('aria-expanded', 'false');
    }

    const box = card.querySelector('.chart-box');
    if (box && canvas) {
      box.addEventListener('dblclick', () => {
        // Keep expanded chart stable: dblclick only opens, it does not close.
        if (!card.classList.contains('is-expanded')) {
          toggleExpandedChart(canvas.id);
        }
      });
    }
  });

  document.addEventListener('click', (event) => {
    const target = event.target instanceof Element ? event.target : null;
    if (!target) return;

    const expandButton = target.closest('[data-chart-expand]');
    if (expandButton) {
      event.preventDefault();
      event.stopPropagation();
      toggleExpandedChart(expandButton.getAttribute('data-chart-expand'));
      return;
    }

    const closeButton = target.closest('[data-chart-close]');
    if (closeButton) {
      event.preventDefault();
      event.stopPropagation();
      closeExpandedChart();
      return;
    }

    const exportButton = target.closest('[data-export-chart]');
    if (exportButton) {
      event.preventDefault();
      event.stopPropagation();
      const id = exportButton.getAttribute('data-export-chart');
      const map = {
        chartMealsByHour: 'h',
        chartAuthDenied: 'ad',
        chartTopMeals: 'tm',
        chartFinanceByMeal: 'fm',
        chartByDepartment: 'md',
        chartDenialReasons: 'dr'
      };
      const chart = ch[map[id] || ''];
      if (!chart) return;

      const runDownload = () => {
        const a = document.createElement('a');
        a.href = chart.toBase64Image('image/png', 1);
        a.download = id + '.png';
        a.click();
      };

      if (typeof window.adminConfirmModal === 'function') {
        window.adminConfirmModal({
          type: 'info',
          title: 'Confirmer téléchargement',
          message: 'Télécharger ce graphe au format PNG ?',
          approveLabel: 'Télécharger',
          cancelLabel: 'Annuler',
          onApprove: runDownload,
        });
        return;
      }

      runDownload();
    }
  });

  // Do not close on empty overlay click to avoid accidental reduction.

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      closeExpandedChart();
    }
  });

  window.addEventListener('resize', handleViewportResize);
  if (window.visualViewport) {
    window.visualViewport.addEventListener('resize', handleViewportResize);
  }

  document.addEventListener('fullscreenchange', () => {
    if (!document.fullscreenElement && expandedChartId) {
      closeExpandedChart();
    }
  });

  bind('mealsMode', (e) => { st.m = e.target.value; render.h(); });
  bind('authMode', (e) => { st.a = e.target.value; render.ad(); });
  bind('departmentMode', (e) => { st.dm = e.target.value; render.md(); });
  bind('denialMode', (e) => { st.dr = e.target.value; render.dr(); });
  bind('financeMode', (e) => { st.fm = e.target.value; render.fm(); });
  bind('topMealsLimit', (e) => { st.top = Number(e.target.value || 10); render.tm(); });

  render.h();
  render.ad();
  render.tm();
  render.fm();
  render.md();
  render.dr();

  // Safety reset on initial load and browser page restore (bfcache)
  updateExpandedViewportMetrics();
  resetExpandedUiState();
  window.addEventListener('pageshow', () => {
    updateExpandedViewportMetrics();
    resetExpandedUiState();
  });
})();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\TSP-Restaurant-pointage\resources\views\dashboard\index.blade.php ENDPATH**/ ?>