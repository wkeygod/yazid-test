<?php $__env->startSection('title', 'Connexion admin'); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        .login-shell {
            width: min(100%, 1160px);
            margin: .2rem auto;
            display: grid;
            grid-template-columns: minmax(0, 1.1fr) minmax(0, .9fr);
            gap: 1.15rem;
            align-items: stretch;
        }

        .login-showcase,
        .login-panel {
            border: 1px solid #d8e6f8;
            border-radius: 18px;
            background: linear-gradient(180deg, #ffffff, #f7fbff);
            box-shadow: 0 18px 40px rgba(14, 37, 64, 0.12);
        }

        .login-showcase {
            padding: 1.35rem;
            position: relative;
            overflow: hidden;
        }

        .login-showcase::before {
            content: "";
            position: absolute;
            inset: 0;
            background:
                radial-gradient(circle at 8% 0%, rgba(17, 102, 156, 0.16), transparent 34%),
                radial-gradient(circle at 85% 12%, rgba(26, 121, 184, 0.14), transparent 36%);
            pointer-events: none;
        }

        .login-brand {
            position: relative;
            z-index: 1;
            display: grid;
            gap: .8rem;
        }

        .login-logo-wrap {
            border: 1px solid #d4e4f7;
            border-radius: 14px;
            padding: .85rem;
            background: #fff;
            box-shadow: 0 12px 28px rgba(17, 102, 156, 0.12);
        }

        .login-logo {
            display: block;
            width: min(100%, 330px);
            margin: 0 auto;
            height: auto;
        }

        .login-kicker {
            margin: 0;
            color: #11669c;
            font-weight: 800;
            letter-spacing: .7px;
            text-transform: uppercase;
            font-size: .75rem;
        }

        .login-title {
            margin: 0;
            color: #163b6f;
            font-size: clamp(1.3rem, 2.6vw, 1.85rem);
            line-height: 1.2;
            font-weight: 800;
        }

        .login-subtitle {
            margin: .35rem 0 0;
            color: #4f6c8f;
            font-size: .92rem;
        }

        .login-points {
            margin: .25rem 0 0;
            padding: 0;
            list-style: none;
            display: grid;
            gap: .45rem;
        }

        .login-points li {
            display: flex;
            align-items: center;
            gap: .5rem;
            color: #234a79;
            font-size: .86rem;
            font-weight: 700;
        }

        .login-dot {
            width: .62rem;
            height: .62rem;
            border-radius: 999px;
            background: linear-gradient(180deg, #1a79b8, #11669c);
            box-shadow: 0 0 0 3px rgba(17, 102, 156, 0.16);
            flex: 0 0 auto;
        }

        .login-panel {
            padding: 1.35rem;
            display: grid;
            gap: .8rem;
            align-content: start;
        }

        .login-panel-title {
            margin: 0;
            color: #173c6e;
            font-size: 1.06rem;
            font-weight: 800;
        }

        .login-form {
            display: grid;
            gap: .64rem;
        }

        .login-label {
            margin-bottom: .2rem;
            font-weight: 800;
            color: #2c4f7d;
            font-size: .8rem;
        }

        .login-input-wrap {
            position: relative;
        }

        .login-input {
            margin: 0;
            border: 1px solid #c8daef;
            border-radius: 11px;
            min-height: 2.75rem;
            padding: .65rem .78rem;
            font-size: .92rem;
            color: #133258;
            background: #fff;
        }

        .login-input:focus {
            border-color: #7ea9df;
            box-shadow: 0 0 0 3px rgba(47, 111, 207, 0.14);
            outline: none;
        }

        .login-password-toggle {
            position: absolute;
            right: .4rem;
            top: 50%;
            transform: translateY(-50%);
            border: 1px solid #d4e3f6;
            border-radius: 8px;
            background: #f6faff;
            color: #28527f;
            font-size: .76rem;
            font-weight: 700;
            min-height: 1.95rem;
            padding: 0 .55rem;
            cursor: pointer;
        }

        .login-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: .6rem;
            margin-top: .1rem;
        }

        .login-remember {
            display: inline-flex;
            align-items: center;
            gap: .42rem;
            color: #3c5f8a;
            font-size: .84rem;
            font-weight: 700;
            margin: 0;
        }

        .login-remember input {
            margin: 0;
            width: 1rem;
            height: 1rem;
            accent-color: #11669c;
        }

        .login-submit {
            width: 100%;
            min-height: 2.75rem;
            border-radius: 11px;
            font-size: .92rem;
            font-weight: 800;
            letter-spacing: .25px;
            background: linear-gradient(140deg, #11669c, #1a79b8);
            box-shadow: 0 12px 20px rgba(17, 102, 156, 0.23);
        }

        .login-footer {
            color: #6380a2;
            font-size: .78rem;
            text-align: center;
            margin: .2rem 0 0;
        }

        @media (max-width: 920px) {
            .login-shell {
                grid-template-columns: 1fr;
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="login-shell">
        <section class="login-showcase" aria-label="Bienvenue">
            <div class="login-brand">
                <div class="login-logo-wrap">
                    <img
                        src="<?php echo e(asset('assets/logo-sca.JPG')); ?>"
                        alt="SCA"
                        class="login-logo"
                    >
                </div>

                <div>
                    <p class="login-kicker">SCA Pointage</p>
                    <h2 class="login-title">Bienvenue sur votre espace d'administration</h2>
                    <p class="login-subtitle">Accédez à la gestion des employés, des règles repas et des historiques avec une interface claire et sécurisée.</p>
                </div>

                <ul class="login-points" aria-label="Avantages">
                    <li><span class="login-dot"></span>Suivi en temps réel des opérations</li>
                    <li><span class="login-dot"></span>Contrôle d'accès par rôles et permissions</li>
                    <li><span class="login-dot"></span>Expérience fluide et professionnelle</li>
                </ul>
            </div>
        </section>

        <section class="login-panel" aria-label="Connexion">
            <h3 class="login-panel-title">Connexion administrateur</h3>

            <form method="POST" action="<?php echo e(route('login.attempt')); ?>" class="login-form">
                <?php echo csrf_field(); ?>

                <div>
                    <label class="login-label" for="email">Email</label>
                    <div class="login-input-wrap">
                        <input class="login-input" id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                    </div>
                </div>

                <div>
                    <label class="login-label" for="password">Mot de passe</label>
                    <div class="login-input-wrap">
                        <input class="login-input" id="password" type="password" name="password" required autocomplete="current-password" style="padding-right: 5.2rem;">
                        <button type="button" class="login-password-toggle" id="toggle-password-btn">Afficher</button>
                    </div>
                </div>

                <div class="login-row">
                    <label class="login-remember"><input type="checkbox" name="remember" value="1">Se souvenir de moi</label>
                </div>

                <button class="btn login-submit" type="submit">Se connecter</button>
            </form>

            <p class="login-footer">Sécurité SCA • Session chiffrée</p>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        (function () {
            var toggleBtn = document.getElementById('toggle-password-btn');
            var passwordInput = document.getElementById('password');

            if (!toggleBtn || !passwordInput) {
                return;
            }

            toggleBtn.addEventListener('click', function () {
                var isHidden = passwordInput.type === 'password';
                passwordInput.type = isHidden ? 'text' : 'password';
                toggleBtn.textContent = isHidden ? 'Masquer' : 'Afficher';
            });
        })();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\TSP-Restaurant-pointage\resources\views\auth\login.blade.php ENDPATH**/ ?>