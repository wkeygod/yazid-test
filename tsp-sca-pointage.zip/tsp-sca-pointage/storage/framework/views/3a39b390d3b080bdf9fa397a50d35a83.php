<?php $__env->startSection('title', 'Logs repas unifies'); ?>
<?php $__env->startSection('topbar_actions'); ?>
    <a class="btn btn-secondary" href="<?php echo e(route('meal-logs.index')); ?>"
       data-confirm-url="<?php echo e(route('meal-logs.index')); ?>"
       data-confirm-only-when-active="true"
       data-confirm-active-params="filter_mode,date,date_from,date_to,source,employee_id,card_uid,result,department_id,denial_reason,meal_type,rig_company,rig,q"
       data-confirm-type="warning"
       data-confirm-title="Réinitialiser les filtres"
       data-confirm-message="Réinitialiser tous les filtres et revenir à la vue par défaut ?"
       data-confirm-cancel-label="Annuler"
       data-confirm-approve-label="Réinitialiser">Réinitialiser les filtres</a>
    <a class="btn btn-ok" href="<?php echo e(route('kiosk.index')); ?>">Aller au kiosk</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        .logs-filter-summary {
            display: flex;
            gap: .4rem;
            flex-wrap: wrap;
            margin-top: .55rem;
        }

        .field-hidden {
            display: none !important;
        }

        .meal-logs-wide-table table {
            min-width: 1750px;
        }

        .meal-logs-wide-table th,
        .meal-logs-wide-table td {
            white-space: nowrap;
        }

        .meal-logs-wide-table th:last-child,
        .meal-logs-wide-table td:last-child {
            min-width: 260px;
            white-space: normal;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $filterMode = $filters['filter_mode'] ?? 'range';
        $selectedDate = $filters['date'] ?? '';
        $dateFrom = $filters['date_from'] ?? '';
        $dateTo = $filters['date_to'] ?? '';
        $sourceFilter = $filters['source'] ?? 'all';
        $employeeFilter = (int) ($filters['employee_id'] ?? 0);
        $cardUidFilter = $filters['card_uid'] ?? '';
        $resultFilter = $filters['result'] ?? '';
        $departmentFilter = (int) ($filters['department_id'] ?? 0);
        $denialReasonFilter = $filters['denial_reason'] ?? '';
        $mealTypeFilter = $filters['meal_type'] ?? '';
        $companyFilter = $filters['rig_company'] ?? '';
        $rigFilter = $filters['rig'] ?? '';
        $searchFilter = $filters['q'] ?? '';

        $activeFilters = collect([
            $filterMode !== '' ? 'Mode: ' . $filterMode : null,
            $selectedDate !== '' && $filterMode === 'day' ? 'Date: ' . $selectedDate : null,
            $dateFrom !== '' && $filterMode === 'range' ? 'Date debut: ' . $dateFrom : null,
            $dateTo !== '' && $filterMode === 'range' ? 'Date fin: ' . $dateTo : null,
            $sourceFilter !== 'all' ? 'Source: ' . ($sources[$sourceFilter] ?? $sourceFilter) : null,
            $employeeFilter > 0 ? 'Employe sélectionné' : null,
            $cardUidFilter !== '' ? 'UID: ' . $cardUidFilter : null,
            $resultFilter !== '' ? 'Resultat: ' . strtoupper($resultFilter) : null,
            $departmentFilter > 0 ? 'Departement sélectionné' : null,
            $denialReasonFilter !== '' ? 'Motif refus: ' . $denialReasonFilter : null,
            $mealTypeFilter !== '' ? 'Type repas: ' . $mealTypeFilter : null,
            $companyFilter !== '' ? 'Compagnie: ' . $companyFilter : null,
            $rigFilter !== '' ? 'Rig/Poste: ' . $rigFilter : null,
            $searchFilter !== '' ? 'Recherche: ' . $searchFilter : null,
        ])->filter()->values();
    ?>

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Journal des repas unifié','subtitle' => 'NFC + La Releve + Extra avec filtres intelligents']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Journal des repas unifié','subtitle' => 'NFC + La Releve + Extra avec filtres intelligents']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <?php if($scopedEmployee): ?>
        <div class="card" style="margin-bottom:1rem; border-left:4px solid #1f5fbf;">
            <div style="font-weight:700;">Historique filtré</div>
            <div class="muted"><?php echo e($scopedEmployee->employee_no); ?> - <?php echo e($scopedEmployee->first_name); ?> <?php echo e($scopedEmployee->last_name); ?></div>
            <div class="muted" style="font-size:.85rem; margin-top:.2rem;">Cette vue affiche uniquement les repas de cet employé.</div>
        </div>
    <?php endif; ?>

    <div class="grid grid-2" style="margin-bottom:1rem;">
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Total logs','value' => number_format((int) ($summary['total'] ?? 0))]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Total logs','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) ($summary['total'] ?? 0)))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Plats consommes','value' => number_format((int) ($summary['consumed_total'] ?? 0)),'tone' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Plats consommes','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) ($summary['consumed_total'] ?? 0))),'tone' => 'success']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Refuses','value' => number_format((int) ($summary['denied'] ?? 0)),'tone' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Refuses','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) ($summary['denied'] ?? 0))),'tone' => 'danger']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'NFC','value' => number_format((int) ($summary['source_employee'] ?? 0)),'tone' => 'info']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'NFC','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) ($summary['source_employee'] ?? 0))),'tone' => 'info']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'La Releve','value' => number_format((int) ($summary['source_la_releve'] ?? 0)),'tone' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'La Releve','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) ($summary['source_la_releve'] ?? 0))),'tone' => 'primary']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Extra','value' => number_format((int) ($summary['source_extra'] ?? 0)),'tone' => 'warning']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Extra','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) ($summary['source_extra'] ?? 0))),'tone' => 'warning']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Petit-dejeuner','value' => number_format((int) ($mealTypeSummary['breakfast'] ?? 0)),'tone' => 'info']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Petit-dejeuner','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) ($mealTypeSummary['breakfast'] ?? 0))),'tone' => 'info']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Dejeuner','value' => number_format((int) ($mealTypeSummary['lunch'] ?? 0)),'tone' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Dejeuner','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) ($mealTypeSummary['lunch'] ?? 0))),'tone' => 'primary']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Diner','value' => number_format((int) ($mealTypeSummary['dinner'] ?? 0)),'tone' => 'warning']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Diner','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) ($mealTypeSummary['dinner'] ?? 0))),'tone' => 'warning']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Montant total','value' => number_format((float) ($summary['amount_total'] ?? 0), 2),'tone' => 'info']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Montant total','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((float) ($summary['amount_total'] ?? 0), 2)),'tone' => 'info']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
    </div>

    <div class="card" style="margin-bottom:1rem;">
        <div class="panel-header">
            <h2>Filtres intelligents</h2>
        </div>

        <?php if (isset($component)) { $__componentOriginal3f97fad59f1d161af1828ef2108f500f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3f97fad59f1d161af1828ef2108f500f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.filter-bar','data' => ['action' => ''.e(route('meal-logs.index')).'','style' => 'grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.filter-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => ''.e(route('meal-logs.index')).'','style' => 'grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));']); ?>
            <div>
                <label>Mode de date</label>
                <select id="meal_logs_filter_mode" name="filter_mode">
                    <option value="day" <?php echo e($filterMode === 'day' ? 'selected' : ''); ?>>Date unique</option>
                    <option value="range" <?php echo e($filterMode === 'range' ? 'selected' : ''); ?>>Intervalle</option>
                </select>
            </div>

            <div id="meal_logs_day_wrap">
                <label>Date (jour)</label>
                <input type="date" name="date" value="<?php echo e($selectedDate); ?>">
            </div>

            <div id="meal_logs_from_wrap">
                <label>Date debut</label>
                <input type="date" name="date_from" value="<?php echo e($dateFrom); ?>">
            </div>

            <div id="meal_logs_to_wrap">
                <label>Date fin</label>
                <input type="date" name="date_to" value="<?php echo e($dateTo); ?>">
            </div>

            <div>
                <label>Source</label>
                <select name="source">
                    <?php $__currentLoopData = $sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sourceKey => $sourceLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sourceKey); ?>" <?php echo e($sourceFilter === $sourceKey ? 'selected' : ''); ?>><?php echo e($sourceLabel); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <label>Employe NFC</label>
                <select name="employee_id">
                    <option value="">Tous</option>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($employee->id); ?>" <?php echo e($employeeFilter === (int) $employee->id ? 'selected' : ''); ?>>
                            <?php echo e($employee->employee_no); ?> - <?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <label>Compagnie</label>
                <select name="rig_company">
                    <option value="">Toutes</option>
                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($company); ?>" <?php echo e($companyFilter === $company ? 'selected' : ''); ?>><?php echo e($company); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <label>Rig / Poste</label>
                <select name="rig">
                    <option value="">Tous</option>
                    <?php $__currentLoopData = $rigs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($rig); ?>" <?php echo e($rigFilter === $rig ? 'selected' : ''); ?>><?php echo e($rig); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <label>Type repas</label>
                <input type="text" name="meal_type" value="<?php echo e($mealTypeFilter); ?>" placeholder="Ex: breakfast, lunch, dinner">
            </div>

            <div>
                <label>UID carte</label>
                <input type="text" name="card_uid" value="<?php echo e($cardUidFilter); ?>" placeholder="Ex: TEST001">
            </div>

            <div>
                <label>Résultat</label>
                <select name="result">
                    <option value="">Tous</option>
                    <option value="approved" <?php echo e($resultFilter === 'approved' ? 'selected' : ''); ?>>Autorisé</option>
                    <option value="rejected" <?php echo e($resultFilter === 'rejected' ? 'selected' : ''); ?>>Refusé</option>
                </select>
            </div>

            <div>
                <label>Departement</label>
                <select name="department_id">
                    <option value="">Tous</option>
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($department->id); ?>" <?php echo e($departmentFilter === (int) $department->id ? 'selected' : ''); ?>>
                            <?php echo e($department->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <label>Motif refus</label>
                <select name="denial_reason">
                    <option value="">Tous</option>
                    <?php $__currentLoopData = $denialReasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reason): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($reason); ?>" <?php echo e($denialReasonFilter === $reason ? 'selected' : ''); ?>><?php echo e($reason); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <label>Recherche globale</label>
                <input type="text" name="q" value="<?php echo e($searchFilter); ?>" placeholder="Nom, matricule, compagnie, rig, repas...">
            </div>

            <div class="actions" style="align-self:end; display:flex; gap:.45rem; flex-wrap:wrap;">
                <button class="btn" type="submit">Filtrer</button>
                <a class="btn btn-secondary" href="<?php echo e(route('meal-logs.index')); ?>"
                   data-confirm-url="<?php echo e(route('meal-logs.index')); ?>"
                   data-confirm-only-when-active="true"
                   data-confirm-active-params="filter_mode,date,date_from,date_to,source,employee_id,card_uid,result,department_id,denial_reason,meal_type,rig_company,rig,q"
                   data-confirm-type="warning"
                   data-confirm-title="Réinitialiser les filtres"
                   data-confirm-message="Réinitialiser tous les filtres et revenir à la vue par défaut ?"
                   data-confirm-cancel-label="Annuler"
                   data-confirm-approve-label="Réinitialiser">Réinitialiser</a>
                <a class="btn export-link" style="background:#1f7a4f;" data-export-url="<?php echo e(route('meal-logs.export', array_merge(request()->query(), ['format' => 'excel']))); ?>" href="#">Exporter Excel Pro</a>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3f97fad59f1d161af1828ef2108f500f)): ?>
<?php $attributes = $__attributesOriginal3f97fad59f1d161af1828ef2108f500f; ?>
<?php unset($__attributesOriginal3f97fad59f1d161af1828ef2108f500f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f97fad59f1d161af1828ef2108f500f)): ?>
<?php $component = $__componentOriginal3f97fad59f1d161af1828ef2108f500f; ?>
<?php unset($__componentOriginal3f97fad59f1d161af1828ef2108f500f); ?>
<?php endif; ?>

        <?php if($activeFilters->isNotEmpty()): ?>
            <div class="logs-filter-summary">
                <?php $__currentLoopData = $activeFilters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.badge','data' => ['tone' => 'info']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'info']); ?><?php echo e($chip); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $attributes = $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $component = $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="card">
        <div class="panel-header">
            <h2 style="margin:0;">Journal unifié des repas</h2>
            <span class="muted"><?php echo e($mealLogs->total()); ?> lignes</span>
        </div>

        <?php if (isset($component)) { $__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.data-table','data' => ['class' => 'table-sticky table-compact meal-logs-wide-table']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'table-sticky table-compact meal-logs-wide-table']); ?>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Heure</th>
                    <th>Source</th>
                    <th>Statut</th>
                    <th>Type repas</th>
                    <th>Matricule / ID</th>
                    <th>Nom complet</th>
                    <th>Compagnie</th>
                    <th>Rig / Poste</th>
                    <th>Departement</th>
                    <th>UID carte</th>
                    <th>Montant</th>
                    <th>Motif</th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $mealLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($log['date'] ?: '-'); ?></td>
                    <td><?php echo e($log['time'] ?: '-'); ?></td>
                    <td><?php echo e($log['source_label'] ?: '-'); ?></td>
                    <td>
                        <?php if (isset($component)) { $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.badge','data' => ['tone' => $log['status'] === 'approved' ? 'approved' : 'rejected']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($log['status'] === 'approved' ? 'approved' : 'rejected')]); ?>
                            <?php echo e($log['status'] === 'approved' ? 'AUTORISE' : 'REFUSE'); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $attributes = $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $component = $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
                    </td>
                    <td><?php echo e($log['meal'] ?: '-'); ?></td>
                    <td><?php echo e($log['employee_no'] ?: '-'); ?></td>
                    <td><?php echo e($log['full_name'] ?: '-'); ?></td>
                    <td><?php echo e($log['company'] ?: '-'); ?></td>
                    <td><?php echo e($log['rig'] ?: '-'); ?></td>
                    <td><?php echo e($log['department'] ?: '-'); ?></td>
                    <td><?php echo e($log['card_uid'] ?: '-'); ?></td>
                    <td><?php echo e(number_format((float) ($log['amount'] ?? 0), 2)); ?></td>
                    <td><?php echo e($log['reason'] ?: '-'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="13">
                        <?php if (isset($component)) { $__componentOriginal99089f8e2ef4184d7d35db81d60c6521 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.empty-state','data' => ['title' => 'Aucun log trouve','message' => 'Aucun enregistrement ne correspond aux filtres sélectionnés.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Aucun log trouve','message' => 'Aucun enregistrement ne correspond aux filtres sélectionnés.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $attributes = $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $component = $__componentOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0)): ?>
<?php $attributes = $__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0; ?>
<?php unset($__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0)): ?>
<?php $component = $__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0; ?>
<?php unset($__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0); ?>
<?php endif; ?>

        <div class="pager"><?php echo e($mealLogs->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        (function () {
            var modeEl = document.getElementById('meal_logs_filter_mode');
            var dayWrap = document.getElementById('meal_logs_day_wrap');
            var fromWrap = document.getElementById('meal_logs_from_wrap');
            var toWrap = document.getElementById('meal_logs_to_wrap');

            if (!modeEl || !dayWrap || !fromWrap || !toWrap) {
                return;
            }

            function syncDateFields() {
                var isRange = (modeEl.value || 'range') === 'range';
                dayWrap.classList.toggle('field-hidden', isRange);
                fromWrap.classList.toggle('field-hidden', !isRange);
                toWrap.classList.toggle('field-hidden', !isRange);
            }

            modeEl.addEventListener('change', syncDateFields);
            syncDateFields();
        })();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\TSP-Restaurant-pointage\resources\views\meal-logs\index.blade.php ENDPATH**/ ?>