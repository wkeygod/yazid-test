<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4 py-6">
    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Gestion des utilisateurs','subtitle' => 'Modifier les rôles, mot de passe et accès des utilisateurs']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Gestion des utilisateurs','subtitle' => 'Modifier les rôles, mot de passe et accès des utilisateurs']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-header d-flex flex-wrap align-items-center justify-content-between gap-2 bg-light">
            <h6 class="mb-0 text-dark fw-bold">
                <i class="fas fa-users me-2"></i>Liste des employés (<?php echo e($users->total()); ?>)
            </h6>

            <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-success">
                <i class="fas fa-plus me-1"></i>Nouveau utilisateur
            </a>
        </div>

        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0 align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Nom</th>
                            <th>Email</th>
                            <th>Accès</th>
                            <th class="text-center" style="width: 230px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $permissionCount = $user->roles->flatMap(fn($role) => $role->permissions)->unique('id')->count();
                            ?>

                            <tr>
                                <td class="fw-semibold">
                                    <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>

                                    <?php if($user->is_admin): ?>
                                        <span class="badge bg-primary ms-2">Admin</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-muted"><?php echo e($user->email); ?></td>
                                <td>
                                    <?php if($user->is_admin): ?>
                                        <span class="badge bg-primary">Accès complet</span>
                                    <?php else: ?>
                                        <span class="badge bg-info"><?php echo e($permissionCount); ?> page(s)</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?php if(!$user->is_admin): ?>
                                        <a href="<?php echo e(route('roles.edit', $user)); ?>" class="btn btn-sm btn-outline-primary" title="Modifier utilisateur">
                                            <i class="fas fa-pen me-1"></i>Modifier
                                        </a>

                                        <form action="<?php echo e(route('roles.destroy', $user)); ?>" method="POST" class="d-inline"
                                              data-confirm="true"
                                              data-confirm-type="danger"
                                              data-confirm-title="Supprimer utilisateur"
                                              data-confirm-message="Supprimer l'utilisateur <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?> ? Cette action est irreversible."
                                              data-confirm-cancel-label="Annuler"
                                              data-confirm-approve-label="Supprimer">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger" title="Supprimer utilisateur">
                                                <i class="fas fa-trash me-1"></i>Supprimer
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Non modifiable</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center py-5 text-muted">
                                    <i class="fas fa-inbox fa-2x d-block mb-2 opacity-50"></i>
                                    Aucun utilisateur trouvé.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php if($users->hasPages()): ?>
            <div class="card-footer bg-light">
                <?php echo e($users->links('pagination::bootstrap-4')); ?>

            </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/madi/TSP-Restaurant-pointage/resources/views/roles/index.blade.php ENDPATH**/ ?>