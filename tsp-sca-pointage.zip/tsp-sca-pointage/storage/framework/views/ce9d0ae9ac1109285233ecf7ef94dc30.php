<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'label',
    'value',
    'tone' => 'primary',
    'meta' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'label',
    'value',
    'tone' => 'primary',
    'meta' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $toneClass = match($tone) {
        'success' => 'ds-kpi-success',
        'danger' => 'ds-kpi-danger',
        'info' => 'ds-kpi-info',
        default => 'ds-kpi-primary',
    };
?>

<div <?php echo e($attributes->class(['card', 'ds-kpi-card', $toneClass])); ?>>
    <div class="ds-kpi-label"><?php echo e($label); ?></div>
    <div class="ds-kpi-value"><?php echo e($value); ?></div>
    <?php if($meta): ?>
        <div class="muted ds-kpi-meta"><?php echo e($meta); ?></div>
    <?php endif; ?>
</div>
<?php /**PATH /var/www/html/resources/views/components/admin/kpi-card.blade.php ENDPATH**/ ?>