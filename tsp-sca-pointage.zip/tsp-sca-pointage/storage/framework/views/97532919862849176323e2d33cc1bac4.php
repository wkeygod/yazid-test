<?php $__env->startSection('title', 'La Releve'); ?>
<?php $__env->startSection('topbar_actions'); ?>
    <div style="display: flex; gap: 0.5rem;">
        <a class="btn" href="<?php echo e(route('la-releve.create', ['date' => $selectedDate])); ?>">Nouvelle entrée</a>
        <a class="btn releve-import-csv" href="<?php echo e(route('la-releve.import', ['date' => $selectedDate])); ?>">Importer des entrées</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        .releve-export-csv,
        .releve-import-csv {
            background: linear-gradient(180deg, #1f7a4f, #17613e) !important;
            color: white !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php ($mealTypeLabels = ['breakfast' => 'Petit-déjeuner', 'lunch' => 'Déjeuner', 'dinner' => 'Dîner']); ?>

    <?php if (isset($component)) { $__componentOriginalc54d3df993b2b7217886cf18c9828547 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc54d3df993b2b7217886cf18c9828547 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.panel','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.panel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'La Releve','subtitle' => 'Gestion des accès repas manuels sans carte NFC.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'La Releve','subtitle' => 'Gestion des accès repas manuels sans carte NFC.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

        <div class="grid grid-2" style="margin-bottom:.9rem;">
            <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Entrées du jour','value' => $summary['total_entries'],'tone' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Entrées du jour','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($summary['total_entries']),'tone' => 'primary']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Ont déjà mangé','value' => $summary['already_eaten'],'tone' => 'info']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Ont déjà mangé','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($summary['already_eaten']),'tone' => 'info']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Quota atteint','value' => $summary['quota_reached'],'tone' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Quota atteint','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($summary['quota_reached']),'tone' => 'danger']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Repas restants','value' => $summary['remaining_meals_total'],'tone' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Repas restants','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($summary['remaining_meals_total']),'tone' => 'success']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        </div>

        <div class="card" style="padding:.7rem .9rem; margin-bottom:.9rem;">
            <strong>Statistiques en temps réel (liste visible)</strong>
            <span class="muted" style="margin-left:.45rem;">
                Entrées: <strong id="live_total"><?php echo e($summary['total_entries']); ?></strong> |
                Ont déjà mangé: <strong id="live_already"><?php echo e($summary['already_eaten']); ?></strong> |
                Quota atteint: <strong id="live_quota"><?php echo e($summary['quota_reached']); ?></strong> |
                Repas restants: <strong id="live_remaining"><?php echo e($summary['remaining_meals_total']); ?></strong>
            </span>
        </div>

        <?php if (isset($component)) { $__componentOriginal3f97fad59f1d161af1828ef2108f500f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3f97fad59f1d161af1828ef2108f500f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.filter-bar','data' => ['action' => ''.e(route('la-releve.index')).'','style' => 'margin-bottom:.9rem;']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.filter-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => ''.e(route('la-releve.index')).'','style' => 'margin-bottom:.9rem;']); ?>
            <div>
                <label>Mode de date</label>
                <select name="filter_mode" id="filter_mode">
                    <option value="day" <?php echo e($filterMode === 'day' ? 'selected' : ''); ?>>Date unique</option>
                    <option value="range" <?php echo e($filterMode === 'range' ? 'selected' : ''); ?>>Intervalle</option>
                </select>
            </div>
            <div>
                <label>Date (jour)</label>
                <input type="date" id="date_day" name="date" value="<?php echo e($selectedDate); ?>">
            </div>
            <div>
                <label>Date début</label>
                <input type="date" id="date_from" name="date_from" value="<?php echo e($selectedDateFrom); ?>">
            </div>
            <div>
                <label>Date fin</label>
                <input type="date" id="date_to" name="date_to" value="<?php echo e($selectedDateTo); ?>">
            </div>
            <div>
                <label>Recherche (nom / poste / entreprise)</label>
                <input id="releve_realtime_search" type="text" name="q" value="<?php echo e($search); ?>" placeholder="Ex: Ahmed Ali ou Soudeur" autocomplete="off">
            </div>
            <div class="actions" style="align-self: end;">
                <button class="btn" type="submit">Filtrer</button>
                <a class="btn btn-secondary" href="<?php echo e(route('la-releve.index')); ?>">Réinitialiser</a>
                <a class="btn releve-export-csv export-link" data-export-url="<?php echo e(route('la-releve.export', array_merge(request()->query(), ['format' => 'excel']))); ?>" href="#">Exporter Excel Pro</a>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3f97fad59f1d161af1828ef2108f500f)): ?>
<?php $attributes = $__attributesOriginal3f97fad59f1d161af1828ef2108f500f; ?>
<?php unset($__attributesOriginal3f97fad59f1d161af1828ef2108f500f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f97fad59f1d161af1828ef2108f500f)): ?>
<?php $component = $__componentOriginal3f97fad59f1d161af1828ef2108f500f; ?>
<?php unset($__componentOriginal3f97fad59f1d161af1828ef2108f500f); ?>
<?php endif; ?>

        <div class="card" style="padding:.8rem; margin-bottom:.75rem;">
            <div class="panel-header" style="margin-bottom:.5rem;">
                <h3 style="margin:0;">Liste La Releve</h3>
                <span class="muted">Filtrée par la période sélectionnée</span>
            </div>

            <?php if (isset($component)) { $__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.data-table','data' => ['class' => 'table-sticky table-compact']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'table-sticky table-compact']); ?>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Nom complet</th>
                        <th>Poste</th>
                        <th>RiG (entreprise)</th>
                        <th>Plats autorisés</th>
                        <th>Repas consommés</th>
                        <th>Restant</th>
                        <th>Statut</th>
                        <th class="actions-col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php ($allowedTypes = collect($entry->allowed_meal_types ?? [])->filter(fn($type) => isset($mealTypeLabels[$type]))->values()); ?>
                        <?php ($allowedCount = $allowedTypes->count()); ?>
                        <?php ($consumedCount = (int) $entry->consumed_meals_count); ?>
                        <?php ($remaining = max(0, $allowedCount - $consumedCount)); ?>
                        <?php ($statusClass = $remaining > 0 ? 'status-approved' : 'status-rejected'); ?>
                        <?php ($statusLabel = $remaining > 0 ? 'Autorisé' : 'Quota atteint'); ?>
                        <tr
                            data-releve-row
                            data-search="<?php echo e(strtolower(($entry->entry_date?->format('Y-m-d') ?? '') . ($entry->end_date ? ' ' . $entry->end_date->format('Y-m-d') : '') . ' ' . $entry->full_name . ' ' . ($entry->position ?? '') . ' ' . ($entry->rig_company ?? '') . ' ' . $allowedTypes->map(fn($v) => $mealTypeLabels[$v])->implode(' '))); ?>"
                            data-consumed="<?php echo e($consumedCount); ?>"
                            data-remaining="<?php echo e($remaining); ?>"
                        >
                            <td>
                                <?php if($entry->end_date): ?>
                                    <span style="font-size:0.85rem;"><?php echo e($entry->entry_date->format('Y-m-d')); ?><br><small class="muted">au</small><br><?php echo e($entry->end_date->format('Y-m-d')); ?></span>
                                <?php else: ?>
                                    <?php echo e(optional($entry->entry_date)->format('Y-m-d') ?: '-'); ?>

                                <?php endif; ?>
                            </td>
                            <td><?php echo e($entry->full_name); ?></td>
                            <td><?php echo e($entry->position ?: '-'); ?></td>
                            <td><?php echo e($entry->rig_company ?: '-'); ?></td>
                            <td><?php echo e($allowedTypes->map(fn($v) => $mealTypeLabels[$v])->implode(', ') ?: '-'); ?></td>
                            <td><?php echo e($consumedCount); ?></td>
                            <td><?php echo e($remaining); ?></td>
                            <td><span class="status-badge <?php echo e($statusClass); ?>"><?php echo e($statusLabel); ?></span></td>
                            <td>
                                <?php if($consumedCount === 0): ?>
                                    <?php if (isset($component)) { $__componentOriginal2cf8d150d764feb90655ba7ed73d9171 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2cf8d150d764feb90655ba7ed73d9171 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.table-actions','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.table-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                        <a class="btn-action btn-action-info" href="<?php echo e(route('la-releve.edit', $entry)); ?>">Modifier</a>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2cf8d150d764feb90655ba7ed73d9171)): ?>
<?php $attributes = $__attributesOriginal2cf8d150d764feb90655ba7ed73d9171; ?>
<?php unset($__attributesOriginal2cf8d150d764feb90655ba7ed73d9171); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2cf8d150d764feb90655ba7ed73d9171)): ?>
<?php $component = $__componentOriginal2cf8d150d764feb90655ba7ed73d9171; ?>
<?php unset($__componentOriginal2cf8d150d764feb90655ba7ed73d9171); ?>
<?php endif; ?>
                                <?php else: ?>
                                    <span class="muted">Verrouillé</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9">
                                <?php if (isset($component)) { $__componentOriginal99089f8e2ef4184d7d35db81d60c6521 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.empty-state','data' => ['title' => 'Aucune entrée La Releve','description' => 'Créez une entrée pour autoriser un accès repas manuel.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Aucune entrée La Releve','description' => 'Créez une entrée pour autoriser un accès repas manuel.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $attributes = $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $component = $__componentOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                    <tr id="releve_no_results" hidden>
                        <td colspan="9">Aucun résultat trouvé pour la recherche en temps réel.</td>
                    </tr>
                </tbody>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0)): ?>
<?php $attributes = $__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0; ?>
<?php unset($__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0)): ?>
<?php $component = $__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0; ?>
<?php unset($__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0); ?>
<?php endif; ?>
        </div>

        <div class="pager"><?php echo e($entries->links()); ?></div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc54d3df993b2b7217886cf18c9828547)): ?>
<?php $attributes = $__attributesOriginalc54d3df993b2b7217886cf18c9828547; ?>
<?php unset($__attributesOriginalc54d3df993b2b7217886cf18c9828547); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc54d3df993b2b7217886cf18c9828547)): ?>
<?php $component = $__componentOriginalc54d3df993b2b7217886cf18c9828547; ?>
<?php unset($__componentOriginalc54d3df993b2b7217886cf18c9828547); ?>
<?php endif; ?>

    <script>
        (function () {
            var modeSelect = document.getElementById('filter_mode');
            var dayInput = document.getElementById('date_day');
            var fromInput = document.getElementById('date_from');
            var toInput = document.getElementById('date_to');
            var filterForm = modeSelect ? modeSelect.closest('form') : null;
            var searchInput = document.getElementById('releve_realtime_search');
            var rows = Array.prototype.slice.call(document.querySelectorAll('tr[data-releve-row]'));
            var noResultsBox = document.getElementById('releve_no_results');
            var liveTotal = document.getElementById('live_total');
            var liveAlready = document.getElementById('live_already');
            var liveQuota = document.getElementById('live_quota');
            var liveRemaining = document.getElementById('live_remaining');

            if (!modeSelect || !dayInput || !fromInput || !toInput) {
                return;
            }

            function applyDateMode() {
                var isRange = modeSelect.value === 'range';
                dayInput.disabled = isRange;
                fromInput.disabled = !isRange;
                toInput.disabled = !isRange;
            }

            modeSelect.addEventListener('change', function () {
                applyDateMode();
                if (filterForm) {
                    filterForm.submit();
                }
            });
            applyDateMode();

            [dayInput, fromInput, toInput].forEach(function (input) {
                if (!input) {
                    return;
                }
                input.addEventListener('change', function () {
                    if (filterForm) {
                        filterForm.submit();
                    }
                });
            });

            function updateLiveStats() {
                if (!liveTotal || !liveAlready || !liveQuota || !liveRemaining) {
                    return;
                }

                var visibleRows = rows.filter(function (row) {
                    return row.style.display !== 'none';
                });

                var total = visibleRows.length;
                var already = 0;
                var quota = 0;
                var remainingSum = 0;

                visibleRows.forEach(function (row) {
                    var consumed = Number(row.getAttribute('data-consumed') || '0');
                    var remaining = Number(row.getAttribute('data-remaining') || '0');
                    if (consumed > 0) {
                        already += 1;
                    }
                    if (remaining <= 0) {
                        quota += 1;
                    }
                    remainingSum += remaining;
                });

                liveTotal.textContent = String(total);
                liveAlready.textContent = String(already);
                liveQuota.textContent = String(quota);
                liveRemaining.textContent = String(remainingSum);
            }

            function applyRealtimeFilter() {
                if (!searchInput) {
                    return;
                }

                var term = (searchInput.value || '').toLowerCase().trim();
                rows.forEach(function (row) {
                    var haystack = (row.getAttribute('data-search') || '').toLowerCase();
                    var visible = term === '' || haystack.indexOf(term) !== -1;
                    row.style.display = visible ? '' : 'none';
                });

                updateLiveStats();

                var visibleRows = rows.filter(function (row) {
                    return row.style.display !== 'none';
                }).length;
                if (noResultsBox) {
                    noResultsBox.style.display = visibleRows === 0 ? '' : 'none';
                }
            }

            if (searchInput) {
                searchInput.addEventListener('input', applyRealtimeFilter);
            }

            applyRealtimeFilter();
        })();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\TSP-Restaurant-pointage\resources\views/la-releve/index.blade.php ENDPATH**/ ?>