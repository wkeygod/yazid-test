<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kiosk SCA - La Releve</title>
    <style>
        :root {
            --bg: #ecf3ff;
            --panel: #ffffff;
            --text: #12253f;
            --muted: #5a6f8d;
            --line: #d6e3f6;
            --primary: #11669c;
            --primary-2: #1a79b8;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: "Avenir Next", "Nunito Sans", "Segoe UI", sans-serif;
            color: var(--text);
            background:
                radial-gradient(circle at 2% 0%, #dce9ff 0%, transparent 32%),
                radial-gradient(circle at 92% 8%, #d7e7ff 0%, transparent 36%),
                linear-gradient(180deg, #f8fbff 0%, var(--bg) 100%);
            overflow-x: hidden;
        }

        .kiosk-shell {
            min-height: 100vh;
            display: grid;
            grid-template-rows: auto auto 1fr;
        }

        .kiosk-header {
            padding: 1rem 1.4rem;
            color: #fff;
            background: linear-gradient(120deg, var(--primary), var(--primary-2));
            box-shadow: 0 10px 26px rgba(31, 95, 191, 0.3);
            font-weight: 700;
            font-size: 1.15rem;
            letter-spacing: .2px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: .7rem;
            animation: headerSlide .45s ease;
        }

        .kiosk-header-right {
            display: inline-flex;
            align-items: center;
            gap: .5rem;
        }

        .logout-btn {
            border: 1px solid rgba(255, 255, 255, 0.45);
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.12);
            color: #fff;
            font-weight: 700;
            padding: .42rem .78rem;
            text-decoration: none;
            cursor: pointer;
        }

        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.2);
        }

        .kiosk-logo {
            height: 2rem;
            width: auto;
            display: block;
            background: rgba(255, 255, 255, 0.14);
            border-radius: .5rem;
            padding: .12rem;
        }

        /* ── Apple Segmented Control ── */

        .kiosk-brand {
            display: inline-flex;
            align-items: center;
            gap: .7rem;
            color: inherit;
            text-decoration: none;
        }

        .kiosk-nav {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: .45rem 1.2rem;
            background: rgba(255, 255, 255, 0.88);
            border-bottom: 1px solid rgba(190, 213, 242, 0.6);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            animation: navFade .5s ease;
        }

        .kiosk-nav-segment {
            position: relative;
            display: inline-flex;
            align-items: center;
            background: rgba(116, 150, 195, 0.14);
            border-radius: 999px;
            padding: 3px;
            gap: 0;
            box-shadow:
                inset 0 1px 3px rgba(20, 55, 105, 0.12),
                0 1px 2px rgba(255,255,255,0.9);
        }

        .kiosk-nav-link {
            position: relative;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            height: 2rem;
            line-height: 1;
            font-size: .875rem;
            font-weight: 600;
            text-decoration: none;
            color: rgba(30, 58, 100, 0.72);
            padding: 0 1.1rem;
            border-radius: 999px;
            white-space: nowrap;
            z-index: 1;
            transition:
                color .22s ease,
                transform .14s ease;
            -webkit-user-select: none;
            user-select: none;
            letter-spacing: .01em;
        }

        .kiosk-nav-link:hover:not(.active) {
            color: rgba(30, 58, 100, 0.95);
            transform: none;
        }

        .kiosk-nav-link.active {
            color: #fff;
        }

        .kiosk-nav-link.active::before {
            content: '';
            position: absolute;
            inset: 0;
            border-radius: 999px;
            background: linear-gradient(135deg, #2464b4 0%, #3481d1 50%, #1f5ca8 100%);
            box-shadow:
                0 2px 8px rgba(36, 100, 180, 0.40),
                0 1px 2px rgba(36, 100, 180, 0.22),
                inset 0 1px 0 rgba(255,255,255,0.25);
            z-index: -1;
            animation: segmentSlideIn .22s cubic-bezier(.34,1.56,.64,1);
        }

        @keyframes segmentSlideIn {
            from { opacity: .55; transform: scaleX(.85) scaleY(.85); }
            to   { opacity: 1;  transform: scaleX(1)   scaleY(1); }
        }

        .kiosk-main {
            display: grid;
            gap: .9rem;
            padding: 1rem;
            animation: pageRise .46s ease;
        }

        .panel {
            background: var(--panel);
            border: 1px solid var(--line);
            border-radius: 1rem;
            padding: 1rem;
            box-shadow: 0 10px 24px rgba(18, 37, 63, 0.1);
            position: relative;
            overflow: hidden;
            transition: transform .18s ease, box-shadow .18s ease;
        }

        .panel::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, rgba(17, 102, 156, 0.75), rgba(26, 121, 184, 0.6), rgba(24, 168, 112, 0.45));
            pointer-events: none;
        }

        .panel:hover {
            transform: translateY(-2px);
            box-shadow: 0 16px 30px rgba(18, 37, 63, 0.14);
        }

        .title {
            margin: 0 0 .25rem;
            font-size: 1.2rem;
        }

        .muted {
            color: var(--muted);
            margin: 0 0 .8rem;
        }

        .manual-search-row {
            display: grid;
            grid-template-columns: repeat(5, minmax(150px, 1fr));
            gap: .55rem;
            align-items: end;
        }

        label {
            display: block;
            font-size: .9rem;
            font-weight: 600;
            margin-bottom: .35rem;
        }

        input, select {
            width: 100%;
            border: 1px solid #c8d8ee;
            border-radius: .6rem;
            padding: .55rem .65rem;
            font-size: .95rem;
        }

        .btn {
            border: 0;
            border-radius: .65rem;
            background: linear-gradient(135deg, var(--primary), var(--primary-2));
            color: #fff;
            font-weight: 700;
            padding: .6rem .95rem;
            cursor: pointer;
            box-shadow: 0 8px 16px rgba(17, 102, 156, 0.24);
            transition: transform .15s ease, filter .15s ease;
        }

        .btn:hover {
            transform: translateY(-1px);
            filter: brightness(1.03);
        }

        .snackbar {
            animation: snackIn .3s ease;
        }

        @keyframes headerSlide {
            from { opacity: 0; transform: translateY(-12px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes navFade {
            from { opacity: 0; transform: translateY(-6px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes pageRise {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes snackIn {
            from { opacity: 0; transform: translateY(-8px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation: none !important;
                transition: none !important;
            }
        }

        .btn[disabled] {
            opacity: .5;
            cursor: not-allowed;
        }

        .manual-result {
            margin-top: .75rem;
            padding: .68rem .75rem;
            border-radius: .65rem;
            border: 1px solid #cfe0f4;
            background: #f4f9ff;
            font-weight: 700;
        }

        .manual-result-success {
            background: #e4f8ec;
            border-color: #b9e6cc;
            color: #125a32;
        }

        .manual-result-error {
            background: #fff2f2;
            border-color: #f0c9c9;
            color: #7f1d1d;
        }

        .snackbar {
            position: fixed;
            right: 1rem;
            top: 1rem;
            z-index: 1200;
            min-width: 280px;
            max-width: min(92vw, 420px);
            border-radius: .65rem;
            padding: .72rem .85rem;
            border: 1px solid #cfe0f4;
            background: #f4f9ff;
            box-shadow: 0 10px 28px rgba(16, 38, 63, 0.2);
            font-weight: 700;
            transition: opacity .2s ease, transform .2s ease;
        }

        .snackbar-success {
            background: #e4f8ec;
            border-color: #b9e6cc;
            color: #125a32;
        }

        .snackbar-error {
            background: #fff2f2;
            border-color: #f0c9c9;
            color: #7f1d1d;
        }

        .snackbar-hide {
            opacity: 0;
            transform: translateY(-8px);
            pointer-events: none;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: .9rem;
        }

        th, td {
            text-align: left;
            padding: .55rem;
            border-bottom: 1px solid var(--line);
        }

        .row-actions {
            display: grid;
            grid-template-columns: repeat(4, minmax(92px, 1fr));
            gap: .45rem;
            align-items: center;
        }

        .meal-btn {
            width: 100%;
            border: 1px solid transparent;
            border-radius: .58rem;
            padding: .52rem .45rem;
            font-size: .8rem;
            font-weight: 800;
            cursor: pointer;
            text-transform: uppercase;
            letter-spacing: .2px;
        }

        .meal-btn-open {
            background: #dff4e8;
            color: #0f5a32;
            border-color: #b8e4cb;
        }

        .meal-btn-eaten {
            background: #fde5e5;
            color: #7f1d1d;
            border-color: #efbbbb;
        }

        .hidden {
            display: none !important;
        }

        .pill {
            display: inline-block;
            border-radius: 999px;
            padding: .18rem .52rem;
            font-size: .75rem;
            font-weight: 700;
            text-transform: uppercase;
        }

        .pill-ok {
            background: #dff4e8;
            color: #0f5a32;
        }

        .pill-stop {
            background: #fde5e5;
            color: #7f1d1d;
        }

        .pager {
            margin-top: .7rem;
        }

        @media (max-width: 980px) {
            .manual-search-row {
                grid-template-columns: 1fr;
            }

            .row-actions {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
<?php
    $authUser = auth()->user();
    $kioskHideNav = $authUser && !$authUser->is_admin && count($authUser->getAccessiblePages()) === 1;
?>

<?php
    $laReleveResult = $laReleveResult ?? session('kiosk_la_releve_result');
    $mealRules = collect($mealRules ?? []);
?>

<?php if(is_array($laReleveResult)): ?>
    <?php ($snackOk = ($laReleveResult['status'] ?? '') === 'success'); ?>
    <div id="kioskSnackbar" class="snackbar <?php echo e($snackOk ? 'snackbar-success' : 'snackbar-error'); ?>">
        <?php echo e($laReleveResult['message'] ?? ''); ?>

    </div>
<?php endif; ?>

<div class="kiosk-shell">
    <header class="kiosk-header">
        <a class="kiosk-brand" href="<?php echo e(route('home')); ?>" aria-label="Retour à l'accueil">
            <img class="kiosk-logo" src="<?php echo e(asset('assets/logo-sca.JPG')); ?>" alt="SCA">
            <span>SCA • Pointage kiosque</span>
        </a>
        <div class="kiosk-header-right">
            <form method="POST" action="<?php echo e(route('logout')); ?>"
                  data-confirm="true"
                  data-confirm-type="warning"
                  data-confirm-title="Déconnexion"
                  data-confirm-message="Voulez-vous vraiment vous déconnecter ?"
                  data-confirm-approve-label="Oui, me déconnecter"
                  data-confirm-cancel-label="Annuler">
                <?php echo csrf_field(); ?>
                <button type="submit" class="logout-btn">Déconnexion</button>
            </form>
        </div>
    </header>

    <?php if(!$kioskHideNav): ?>
    <nav class="kiosk-nav" aria-label="Navigation kiosk">
        <div class="kiosk-nav-segment" role="tablist">
            <a class="kiosk-nav-link" href="<?php echo e(route('kiosk.index')); ?>" role="tab" aria-selected="false">Scan NFC</a>
            <a class="kiosk-nav-link active" href="<?php echo e(route('kiosk.la-releve.page')); ?>" role="tab" aria-selected="true">La Relève</a>
            <a class="kiosk-nav-link" href="<?php echo e(route('kiosk.extra.page')); ?>" role="tab" aria-selected="false">Extra</a>
        </div>
    </nav>
    <?php endif; ?>

    <main class="kiosk-main">
        <section class="panel">
            <h2 class="title">Liste La Releve (<?php echo e($filterMode === 'range' ? ($selectedDateFrom . ' au ' . $selectedDateTo) : $selectedDate); ?>)</h2>
            <p class="muted">Astuce UX: tapez dans la recherche pour filtrer en temps réel, puis cochez/décochez directement la ligne.</p>

            <form id="listFilterForm" method="GET" action="<?php echo e(route('kiosk.la-releve.page')); ?>" class="manual-search-row" style="margin-bottom:.7rem;">
                <div>
                    <label for="filter_mode">Mode de date</label>
                    <select id="filter_mode" name="filter_mode">
                        <option value="day" <?php echo e($filterMode === 'day' ? 'selected' : ''); ?>>Date unique</option>
                        <option value="range" <?php echo e($filterMode === 'range' ? 'selected' : ''); ?>>Intervalle</option>
                    </select>
                </div>
                <div>
                    <label for="q">Recherche temps réel</label>
                    <input id="q" type="text" name="q" value="<?php echo e($searchQuery); ?>" placeholder="Nom, poste, entreprise" autocomplete="off">
                </div>
                <div>
                    <label for="list_date">Date (jour)</label>
                    <input id="list_date" type="date" name="list_date" value="<?php echo e($selectedDate); ?>">
                </div>
                <div>
                    <label for="date_from">Date début</label>
                    <input id="date_from" type="date" name="date_from" value="<?php echo e($selectedDateFrom); ?>">
                </div>
                <div>
                    <label for="date_to">Date fin</label>
                    <input id="date_to" type="date" name="date_to" value="<?php echo e($selectedDateTo); ?>">
                </div>
            </form>

            <?php if($errors->any()): ?>
                <div class="manual-result manual-result-error" style="margin-bottom:.7rem;">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Nom</th>
                        <th>Poste</th>
                        <th>RiG</th>
                        <th>Consommés</th>
                        <th>Restants</th>
                        <th>Statut</th>
                        <th>Repas (vert: pas mangé / rouge: déjà mangé)</th>
                    </tr>
                </thead>
                <tbody id="releveRows">
                    <?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php ($entryDate = optional($entry->entry_date)->format('Y-m-d')); ?>
                        <?php ($allowedMealRuleIds = collect($entry->allowed_meal_types ?? [])->filter(fn($type) => $mealRules->contains('id', $type))->unique()->values()); ?>
                        <?php ($allowedCount = $allowedMealRuleIds->count() > 0 ? $allowedMealRuleIds->count() : $mealRules->count()); ?>
                        <?php ($consumedForDate = $entry->mealLogs->filter(fn($log) => optional($log->consumed_at)->format('Y-m-d') === $selectedDate)); ?>
                        <?php ($consumedFlags = $mealRules->mapWithKeys(function ($mealRule) use ($consumedForDate): array {
                            return [$mealRule->id => $consumedForDate->contains('meal_rule_id', $mealRule->id) || $consumedForDate->contains('meal_type', $mealRule->name) ? 1 : 0];
                        })->all()); ?>
                        <?php ($consumedCount = array_sum($consumedFlags)); ?>
                        <?php ($remaining = max(0, $allowedCount - $consumedCount)); ?>
                        <tr data-row-search="<?php echo e(strtolower($entry->full_name . ' ' . ($entry->position ?? '') . ' ' . ($entry->rig_company ?? ''))); ?>">
                            <td>
                                <?php if($entry->end_date): ?>
                                    <?php echo e($entry->entry_date->format('Y-m-d')); ?> <span style="font-size:0.75rem; color:var(--muted)">au</span> <?php echo e($entry->end_date->format('Y-m-d')); ?>

                                <?php else: ?>
                                    <?php echo e($entryDate ?: '-'); ?>

                                <?php endif; ?>
                            </td>
                            <td><?php echo e($entry->full_name); ?></td>
                            <td><?php echo e($entry->position ?: '-'); ?></td>
                            <td><?php echo e($entry->rig_company ?: '-'); ?></td>
                            <td><?php echo e($consumedCount); ?></td>
                            <td><?php echo e($remaining); ?></td>
                            <td>
                                <span class="pill <?php echo e($remaining > 0 ? 'pill-ok' : 'pill-stop'); ?>">
                                    <?php echo e($remaining > 0 ? 'Autorisé' : 'Quota atteint'); ?>

                                </span>
                            </td>
                            <td>
                                <div class="row-actions">
                                    <?php $__currentLoopData = $mealRules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mealRule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php ($alreadyEatenType = ($consumedFlags[$mealRule->id] ?? 0) === 1); ?>
                                        <form method="POST" action="<?php echo e(route('kiosk.la-releve.toggle')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="entry_id" value="<?php echo e($entry->id); ?>">
                                            <input type="hidden" name="selected_date" value="<?php echo e($selectedDate); ?>">
                                            <input type="hidden" name="meal_rule_id" value="<?php echo e($mealRule->id); ?>">
                                            <input type="hidden" name="is_checked" value="<?php echo e($alreadyEatenType ? '0' : '1'); ?>">
                                            <input type="hidden" name="notes" value="Action rapide bouton repas">
                                            <button
                                                type="submit"
                                                class="meal-btn <?php echo e($alreadyEatenType ? 'meal-btn-eaten' : 'meal-btn-open'); ?>"
                                                <?php if($alreadyEatenType): ?>
                                                    onclick="return confirm('Confirmer le changement vers NON mangé pour ce repas ?')"
                                                <?php endif; ?>
                                            >
                                                <?php echo e($mealRule->name); ?>

                                                <small style="display:block; font-size:.72rem; opacity:.85; margin-top:.15rem;"><?php echo e($alreadyEatenType ? '1' : '0'); ?></small>
                                            </button>
                                        </form>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div style="margin-top:.45rem; font-size:.8rem; color: var(--muted);">
                                    Comptage du jour: <?php echo e($mealRules->map(function ($mealRule) use ($consumedFlags): string {
                                        return $mealRule->name . '=' . ($consumedFlags[$mealRule->id] ?? 0);
                                    })->implode(', ')); ?>

                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8">Aucune entrée pour ce filtre de date.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <div class="pager"><?php echo e($entries->links()); ?></div>
        </section>
    </main>
</div>
<script>
    (function () {
        var searchInput = document.getElementById('q');
        var modeSelect = document.getElementById('filter_mode');
        var dateInput = document.getElementById('list_date');
        var dateFromInput = document.getElementById('date_from');
        var dateToInput = document.getElementById('date_to');
        var filterForm = document.getElementById('listFilterForm');
        var rowsContainer = document.getElementById('releveRows');

        if (!searchInput || !rowsContainer) {
            return;
        }

        var rows = Array.prototype.slice.call(rowsContainer.querySelectorAll('tr[data-row-search]'));
        searchInput.addEventListener('input', function () {
            var term = (searchInput.value || '').toLowerCase().trim();
            rows.forEach(function (row) {
                var haystack = row.getAttribute('data-row-search') || '';
                row.classList.toggle('hidden', term !== '' && haystack.indexOf(term) === -1);
            });
        });

        if (modeSelect && dateInput && dateFromInput && dateToInput && filterForm) {
            function applyDateMode() {
                var isRange = modeSelect.value === 'range';
                dateInput.disabled = isRange;
                dateFromInput.disabled = !isRange;
                dateToInput.disabled = !isRange;
            }

            modeSelect.addEventListener('change', function () {
                applyDateMode();
                filterForm.submit();
            });

            dateInput.addEventListener('change', function () {
                filterForm.submit();
            });

            dateFromInput.addEventListener('change', function () {
                filterForm.submit();
            });

            dateToInput.addEventListener('change', function () {
                filterForm.submit();
            });

            applyDateMode();
        }

        var snackbar = document.getElementById('kioskSnackbar');
        if (snackbar) {
            setTimeout(function () {
                snackbar.classList.add('snackbar-hide');
                setTimeout(function () {
                    if (snackbar && snackbar.parentNode) {
                        snackbar.parentNode.removeChild(snackbar);
                    }
                }, 250);
            }, 2000);
        }
    })();
</script>

<?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\TSP-Restaurant-pointage\resources\views/kiosk/la-releve.blade.php ENDPATH**/ ?>