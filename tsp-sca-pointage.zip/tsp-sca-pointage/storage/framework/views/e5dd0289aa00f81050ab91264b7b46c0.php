<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'action' => '',
    'method' => 'GET',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'action' => '',
    'method' => 'GET',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<form method="<?php echo e(strtoupper($method) === 'GET' ? 'GET' : 'POST'); ?>" action="<?php echo e($action); ?>" <?php echo e($attributes->class(['ds-filter-bar', 'grid'])); ?>>
    <?php if(strtoupper($method) !== 'GET'): ?>
        <?php echo csrf_field(); ?>
    <?php endif; ?>

    <?php echo e($slot); ?>

</form>
<?php /**PATH /var/www/html/madi/TSP-Restaurant-pointage/resources/views/components/admin/filter-bar.blade.php ENDPATH**/ ?>