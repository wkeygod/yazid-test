<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#11669c">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-title" content="SCA Pointage">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('favicon.png')); ?>?v=sca-pointage-v9">
    <link rel="icon" type="image/png" sizes="48x48" href="<?php echo e(asset('icons/icon-48.png')); ?>?v=sca-pointage-v9">
    <link rel="manifest" href="<?php echo e(asset('manifest.webmanifest')); ?>?v=sca-pointage-v9">
    <link rel="apple-touch-icon" href="<?php echo e(asset('icons/icon-192.png')); ?>?v=sca-pointage-v9">
    <title><?php echo $__env->yieldContent('title', 'SCA'); ?></title>
    <style>
        :root {
            --bg: #eef3fb;
            --bg-soft: #f7faff;
            --surface: #ffffff;
            --surface-alt: #f7faff;
            --text: #102640;
            --muted: #59708c;
            --primary: #11669c;
            --primary-2: #1a79b8;
            --primary-ink: #e8f2ff;
            --danger: #c93737;
            --danger-2: #a82424;
            --ok: #218a50;
            --ok-2: #1a6f40;
            --warning: #c97f1a;
            --info: #2f6fcf;
            --accent: #d6b16f;
            --accent-soft: rgba(214, 177, 111, 0.18);
            --border: #d8e4f3;
            --line-soft: #eaf0f9;
            --sidebar: #11669c;
            --sidebar-2: #1a79b8;
            --sidebar-muted: #9ab3d2;
            --sidebar-hover: rgba(255, 255, 255, 0.14);
            --topbar: rgba(255, 255, 255, 0.88);
            --shadow-sm: 0 10px 26px rgba(14, 37, 64, 0.1);
            --shadow-md: 0 18px 42px rgba(14, 37, 64, 0.16);
            --radius: 16px;
            --radius-sm: 12px;
            --radius-pill: 999px;

            /* Typography scale */
            --font-size-xs: .74rem;
            --font-size-sm: .86rem;
            --font-size-md: .95rem;
            --font-size-lg: 1.12rem;
            --font-size-xl: 1.3rem;

            /* Spacing scale */
            --space-1: .25rem;
            --space-2: .5rem;
            --space-3: .75rem;
            --space-4: 1rem;
            --space-5: 1.25rem;
            --space-6: 1.5rem;

            /* Responsive breakpoints reference */
            --bp-sm: 680px;
            --bp-md: 980px;
            --bp-lg: 1180px;
        }

        * {
            box-sizing: border-box;
        }

        html,
        body {
            min-height: 100%;
        }

        body {
            margin: 0;
            font-family: "Avenir Next", "Nunito Sans", "Segoe UI", sans-serif;
            -webkit-text-size-adjust: 100%;
            color: var(--text);
            background:
                radial-gradient(circle at 2% 0%, #dce9ff 0%, transparent 32%),
                radial-gradient(circle at 92% 8%, #d7e7ff 0%, transparent 36%),
                linear-gradient(180deg, #f8fbff 0%, var(--bg) 100%);
            position: relative;
            overflow-x: hidden;
        }

        body::before {
            content: "";
            position: fixed;
            inset: 0;
            pointer-events: none;
            z-index: 0;
            background:
                radial-gradient(circle at 12% 18%, rgba(17, 102, 156, 0.07), transparent 28%),
                radial-gradient(circle at 88% 82%, rgba(26, 121, 184, 0.06), transparent 32%);
            animation: ambientFloat 16s ease-in-out infinite alternate;
        }

            body.sidebar-open {
                overflow: hidden;
            }

        .admin-shell {
            min-height: 100vh;
            display: grid;
            grid-template-columns: 280px minmax(0, 1fr);
            gap: 0;
            position: relative;
            z-index: 1;
            transition: grid-template-columns .2s ease;
        }

        .admin-shell.sidebar-collapsed {
            grid-template-columns: 108px minmax(0, 1fr);
        }

        .admin-shell.sidebar-hover-expand {
            grid-template-columns: 280px minmax(0, 1fr);
        }

        .sidebar {
            background: linear-gradient(170deg, var(--sidebar), var(--sidebar-2));
            color: #fff;
            padding: 1rem .9rem;
            display: flex;
            flex-direction: column;
            gap: .9rem;
            border-right: 1px solid rgba(255, 255, 255, 0.08);
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            isolation: isolate;
        }

        .sidebar::before {
            content: "";
            position: absolute;
            inset: 0;
            pointer-events: none;
            background:
                radial-gradient(circle at 12% 0%, rgba(33, 138, 80, 0.22), transparent 34%),
                radial-gradient(circle at 88% 28%, rgba(255, 255, 255, 0.08), transparent 42%);
            z-index: -1;
        }

        .sidebar-close {
            display: none;
            width: 100%;
            border: 1px solid rgba(255, 255, 255, 0.28);
            border-radius: var(--radius-sm);
            background: rgba(255, 255, 255, 0.12);
            color: #fff;
            font-weight: 700;
            padding: .5rem .65rem;
            cursor: pointer;
        }

        .sidebar-overlay {
            display: none;
        }

        .sidebar-brand {
            display: flex;
            align-items: center;
            gap: .46rem;
            font-weight: 800;
            font-size: 1.03rem;
            letter-spacing: .2px;
            padding: .58rem .62rem .58rem .72rem;
            color: #fff;
            text-decoration: none;
            border-radius: var(--radius-sm);
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.12);
            box-shadow: inset 0 0 0 1px rgba(33, 138, 80, 0.42);
        }

        .sidebar-brand-main {
            min-width: 0;
            display: inline-flex;
            align-items: center;
            gap: .55rem;
            flex: 1 1 auto;
            color: #fff;
            text-decoration: none;
        }

        .sidebar-brand-main:hover {
            color: #fff;
        }

        .sidebar-install-btn {
            width: 1.9rem;
            height: 1.9rem;
            flex: 0 0 auto;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border: 1px solid rgba(220, 255, 236, 0.36);
            border-radius: 9px;
            background: rgba(32, 168, 107, 0.22);
            color: #dcffec;
            box-shadow: inset 0 0 0 1px rgba(32, 168, 107, 0.2), 0 8px 18px rgba(9, 25, 44, 0.16);
            cursor: pointer;
            transition: transform .16s ease, background .16s ease, border-color .16s ease, box-shadow .16s ease;
        }

        .sidebar-install-btn[hidden] {
            display: none !important;
        }

        .sidebar-install-btn:hover {
            background: linear-gradient(135deg, #20a86b, #107f4e);
            border-color: rgba(255, 255, 255, 0.42);
            color: #fff;
            transform: translateY(-1px);
            box-shadow: 0 12px 22px rgba(16, 127, 78, 0.3);
        }

        .sidebar-install-btn:focus-visible {
            outline: 3px solid rgba(255, 255, 255, 0.24);
            outline-offset: 2px;
        }

        .sidebar-install-btn svg {
            width: 1rem;
            height: 1rem;
            stroke-width: 2.45;
        }

        .sidebar-desktop-toggle {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            border: 1px solid rgba(255, 255, 255, 0.24);
            border-radius: var(--radius-sm);
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
            font-weight: 700;
            padding: .45rem .65rem;
            cursor: pointer;
            transition: background .15s ease, border-color .15s ease;
        }

        .sidebar-desktop-toggle:hover {
            background: rgba(255, 255, 255, 0.18);
            border-color: rgba(255, 255, 255, 0.38);
        }

        .sidebar-brand-logo {
            height: 2rem;
            width: auto;
            display: block;
            filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.18));
        }

        .sidebar-brand-text {
            font-size: .92rem;
            letter-spacing: .2px;
        }

        .admin-shell.sidebar-collapsed .sidebar-brand {
            justify-content: center;
            padding: .5rem;
        }

        .admin-shell.sidebar-collapsed .sidebar-brand-main {
            flex: 0 0 auto;
        }

        .admin-shell.sidebar-collapsed .sidebar-brand-text,
        .admin-shell.sidebar-collapsed .sidebar-muted,
        .admin-shell.sidebar-collapsed .sidebar-btn,
        .admin-shell.sidebar-collapsed .sidebar-desktop-toggle {
            display: none;
        }

        .admin-shell.sidebar-collapsed .sidebar-brand-logo {
            height: 1.8rem;
        }

        .admin-shell.sidebar-collapsed .sidebar-link {
            padding: .58rem .5rem;
            font-size: .72rem;
            text-align: center;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .admin-shell.sidebar-collapsed .sidebar-link::after {
            left: .45rem;
            right: .45rem;
        }

        .admin-shell.sidebar-hover-expand .sidebar-brand-text {
            display: inline;
        }

        .admin-shell.sidebar-hover-expand .sidebar-muted {
            display: block;
        }

        .admin-shell.sidebar-hover-expand .sidebar-btn,
        .admin-shell.sidebar-hover-expand .sidebar-desktop-toggle {
            display: inline-flex;
        }

        .admin-shell.sidebar-hover-expand .sidebar-brand {
            justify-content: flex-start;
            padding: .65rem .72rem;
        }

        .admin-shell.sidebar-hover-expand .sidebar-brand-main {
            flex: 1 1 auto;
        }

        .admin-shell.sidebar-hover-expand .sidebar-link {
            font-size: .88rem;
            text-align: left;
            padding: .62rem .72rem;
        }

        .sidebar-nav {
            display: grid;
            gap: .24rem;
        }

        .sidebar-link {
            color: #edf4ff;
            text-decoration: none;
            font-weight: 700;
            padding: .62rem .72rem;
            border-radius: var(--radius-sm);
            display: block;
            transition: background .18s ease, transform .18s ease, box-shadow .18s ease;
            position: relative;
            overflow: hidden;
        }

        .sidebar-link::after {
            content: "";
            position: absolute;
            left: .72rem;
            right: .72rem;
            bottom: .34rem;
            height: 2px;
            border-radius: 999px;
            background: linear-gradient(90deg, rgba(220, 255, 236, 0.85), rgba(33, 138, 80, 0.9));
            transform: scaleX(0);
            transform-origin: left center;
            transition: transform .2s ease;
        }

        .sidebar-link:hover {
            background: var(--sidebar-hover);
            transform: translateX(1px);
            box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.12);
        }

        .sidebar-link:hover::after {
            transform: scaleX(1);
        }

        .sidebar-link.active {
            background: #f2f7ff;
            color: #163d70;
            box-shadow: inset 0 0 0 1px #d8e5fb;
        }

        .sidebar-muted {
            color: var(--sidebar-muted);
            font-size: .74rem;
            padding: .48rem .7rem .28rem;
            text-transform: uppercase;
            letter-spacing: .7px;
            font-weight: 800;
        }

        .sidebar-foot {
            margin-top: auto;
            display: grid;
            gap: .45rem;
        }

        .sidebar-foot form {
            margin: 0;
        }

        .sidebar-btn {
            width: 100%;
            border: 1px solid rgba(255, 255, 255, 0.2);
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
            font-weight: 700;
            border-radius: var(--radius-sm);
            padding: .58rem .72rem;
            cursor: pointer;
            text-align: left;
            transition: background .15s ease;
        }

        .sidebar-btn:hover {
            background: rgba(255, 255, 255, 0.2);
        }

        .main-area {
            min-width: 0;
            display: grid;
            grid-template-rows: auto 1fr;
        }

        .topbar {
            background: var(--topbar);
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: .9rem;
            padding: .92rem 1.22rem;
            position: sticky;
            top: 0;
            z-index: 20;
            backdrop-filter: blur(8px);
            box-shadow: 0 8px 22px rgba(15, 40, 70, 0.08);
            position: sticky;
        }

        .topbar::after {
            content: "";
            position: absolute;
            left: 0;
            right: 0;
            bottom: -1px;
            height: 2px;
            background: linear-gradient(90deg, rgba(17, 102, 156, 0.2), rgba(26, 121, 184, 0.52), rgba(24, 168, 112, 0.2));
            opacity: .75;
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: .72rem;
            min-width: 0;
        }

        .topbar-heading {
            min-width: 0;
            display: grid;
            gap: .2rem;
        }

        .topbar-title {
            margin: 0;
            font-size: 1.18rem;
            font-weight: 800;
            letter-spacing: .1px;
            color: #17355c;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .sidebar-toggle {
            display: none;
            align-items: center;
            justify-content: center;
            border: 1px solid #cfe0f5;
            border-radius: 10px;
            width: 2.2rem;
            height: 2.2rem;
            background: #fff;
            color: #204267;
            font-size: 1rem;
            cursor: pointer;
            box-shadow: var(--shadow-sm);
        }

        .sidebar-toggle:hover {
            background: #f4f8ff;
        }

        .breadcrumbs {
            display: flex;
            flex-wrap: wrap;
            gap: .22rem .34rem;
            align-items: center;
            color: #567294;
            font-size: .78rem;
            font-weight: 700;
            min-width: 0;
        }

        .breadcrumbs a {
            color: #2f5d9d;
            text-decoration: none;
        }

        .breadcrumbs a:hover {
            text-decoration: underline;
        }

        .breadcrumbs-separator {
            opacity: .55;
            padding: 0 .08rem;
        }

        .topbar-actions {
            display: flex;
            align-items: center;
            gap: .5rem;
            flex-wrap: wrap;
        }

        .single-page-shell {
            min-height: 100vh;
            display: grid;
            grid-template-rows: auto 1fr;
            position: relative;
            z-index: 1;
        }

        .single-page-topbar {
            background: var(--topbar);
            border-bottom: 1px solid var(--border);
            padding: .85rem 1.1rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: .7rem;
            backdrop-filter: blur(8px);
            box-shadow: 0 8px 22px rgba(15, 40, 70, 0.08);
            position: sticky;
            top: 0;
            z-index: 20;
        }

        .single-page-title {
            margin: 0;
            font-size: 1.05rem;
            font-weight: 800;
            color: #17355c;
        }

        .single-page-content {
            padding: .9rem 1.1rem 1.3rem;
            min-width: 0;
        }

        .guest-shell {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .guest-main {
            flex: 1 0 auto;
            width: min(1280px, 100%);
            margin: 0 auto;
            padding: 1rem 1rem 1.1rem;
        }

        .guest-content-wrap {
            width: 100%;
        }

        .content {
            padding: 1.1rem 1.2rem 1.4rem;
            min-width: 0;
        }

        .content-container {
            width: min(1320px, 100%);
            margin: 0 auto;
            display: grid;
            gap: 1rem;
        }

        .content-container > * {
            animation: riseIn .42s ease both;
        }

        .content-container > *:nth-child(2) { animation-delay: .04s; }
        .content-container > *:nth-child(3) { animation-delay: .08s; }
        .content-container > *:nth-child(4) { animation-delay: .12s; }
        .content-container > *:nth-child(5) { animation-delay: .16s; }

        .alert-stack {
            display: grid;
            gap: .65rem;
            margin-bottom: .9rem;
        }

        .card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 1.05rem;
            box-shadow: var(--shadow-sm);
            margin-bottom: 1rem;
            position: relative;
            transition: transform .2s ease, box-shadow .2s ease;
        }

        .card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            border-radius: var(--radius) var(--radius) 0 0;
            background: linear-gradient(90deg, rgba(17, 102, 156, 0.75), rgba(26, 121, 184, 0.62), rgba(24, 168, 112, 0.42));
            pointer-events: none;
        }

        .card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }

        .ds-card-soft {
            background: linear-gradient(180deg, #ffffff, #f8fbff);
        }

        .ds-card-tight {
            padding: .72rem;
        }

        .panel-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: .6rem;
            margin-bottom: .75rem;
        }

        .panel-header h2,
        .panel-header h3 {
            margin: 0;
            color: #163b6c;
            font-size: 1rem;
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            font-size: .88rem;
            background: #fff;
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            overflow: hidden;
        }

        .ds-table-wrap {
            width: 100%;
            overflow: auto;
            border-radius: var(--radius-sm);
            -webkit-overflow-scrolling: touch;
            touch-action: pan-x;
            border: 1px solid var(--border);
            background: #fff;
            box-shadow: 0 8px 20px rgba(14, 37, 64, 0.05);
        }

        .ds-table-wrap table {
            border: 0;
            border-radius: 0;
        }

        th {
            background: linear-gradient(180deg, #f7fbff, #f1f7ff);
            color: #2e4f78;
            font-size: .76rem;
            text-transform: uppercase;
            letter-spacing: .55px;
            font-weight: 800;
            padding: .72rem .7rem;
            border-bottom: 1px solid var(--border);
        }

        th,
        td {
            padding: .58rem .7rem;
            border-bottom: 1px solid var(--line-soft);
            text-align: left;
            vertical-align: middle;
        }

        .ds-table-wrap.table-sticky thead th {
            position: sticky;
            top: 0;
            z-index: 3;
        }

        .ds-table-wrap.table-sticky thead th::after {
            content: "";
            position: absolute;
            left: 0;
            right: 0;
            bottom: -1px;
            height: 1px;
            background: #d5e4f6;
        }

        .ds-table-wrap.table-compact td {
            font-size: .86rem;
            line-height: 1.35;
        }

        .status-col {
            width: 140px;
        }

        .actions-col {
            min-width: 230px;
            width: 1%;
        }

        tbody tr:last-child td {
            border-bottom: 0;
        }

        tbody tr:hover {
            background: #f5f9ff;
            transform: translateX(1px);
        }

        tbody tr {
            transition: background .15s ease, transform .15s ease;
        }

        .table-actions {
            display: flex;
            align-items: center;
            gap: .42rem;
            flex-wrap: wrap;
        }

        .btn,
        .btn-action {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border: 0;
            border-radius: 12px;
            padding: .52rem .82rem;
            font-size: .82rem;
            line-height: 1;
            min-height: 2.3rem;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none;
            white-space: nowrap;
            color: #fff;
            background: linear-gradient(135deg, var(--primary), var(--primary-2));
            box-shadow: 0 8px 18px rgba(17, 102, 156, 0.25);
            transition: transform .14s ease, filter .14s ease, box-shadow .14s ease;
            position: relative;
            overflow: hidden;
        }

        .btn::before,
        .btn-action::before {
            content: "";
            position: absolute;
            inset: -140% auto -140% -32%;
            width: 40%;
            transform: rotate(24deg);
            background: linear-gradient(90deg, rgba(255, 255, 255, 0), rgba(255, 255, 255, .34), rgba(255, 255, 255, 0));
            opacity: 0;
            transition: opacity .16s ease;
        }

        .btn-sm {
            padding: .4rem .62rem;
            font-size: .76rem;
        }

        .btn-lg {
            padding: .65rem .98rem;
            font-size: .9rem;
        }

        .btn:hover,
        .btn-action:hover {
            filter: brightness(1.04);
            transform: translateY(-1px);
            box-shadow: 0 12px 22px rgba(17, 102, 156, 0.3);
        }

        .btn:hover::before,
        .btn-action:hover::before {
            opacity: 1;
            animation: btnSweep .65s ease;
        }

        .btn:focus-visible,
        .btn-action:focus-visible,
        .sidebar-link:focus-visible,
        .sidebar-btn:focus-visible,
        .sidebar-toggle:focus-visible {
            outline: 3px solid rgba(46, 119, 219, 0.28);
            outline-offset: 2px;
        }

        .btn:active,
        .btn-action:active {
            transform: translateY(0);
        }

        .btn-action-danger,
        .btn-danger {
            background: linear-gradient(180deg, var(--danger), var(--danger-2));
        }

        .btn-action-info {
            background: linear-gradient(180deg, #3f6bb5, #305694);
        }

        .btn-action-success {
            background: linear-gradient(180deg, #1f8f4e, #16703d);
        }

        .btn-action-muted {
            background: linear-gradient(180deg, #6f7f94, #5b6c82);
        }

        .btn-ok {
            background: linear-gradient(180deg, var(--ok), var(--ok-2));
        }

        .btn-secondary {
            background: linear-gradient(180deg, #6b7f98, #596e88);
        }

        label {
            display: inline-block;
            color: #2e4f77;
            font-size: .8rem;
            font-weight: 700;
            margin-bottom: .2rem;
        }

        .ds-form-grid {
            display: grid;
            gap: .72rem;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        }

        .ds-form-actions {
            display: flex;
            gap: .5rem;
            align-items: center;
            flex-wrap: wrap;
        }

        .ds-form {
            display: grid;
            gap: .95rem;
        }

        .ds-form-section {
            border: 1px solid #dbe8f8;
            border-radius: var(--radius-sm);
            padding: .85rem;
            background: linear-gradient(180deg, #ffffff, #f8fbff);
        }

        .ds-form-section-title {
            margin: 0 0 .2rem;
            color: #1a3f6d;
            font-size: .96rem;
            font-weight: 800;
        }

        .ds-form-section-subtitle {
            margin: 0 0 .7rem;
            color: var(--muted);
            font-size: .83rem;
        }

        .ds-field {
            display: grid;
            gap: .2rem;
        }

        .ds-field-error {
            margin-top: -.34rem;
            margin-bottom: .45rem;
            color: #9c2f2f;
            font-size: .8rem;
            font-weight: 700;
        }

        .ds-field-hint {
            margin-top: -.28rem;
            margin-bottom: .45rem;
            color: #6b8098;
            font-size: .78rem;
        }

        input.input-error,
        select.input-error,
        textarea.input-error {
            border-color: #d56e6e;
            box-shadow: 0 0 0 3px rgba(201, 55, 55, 0.12);
        }

        .ds-checkbox-group {
            display: grid;
            gap: .4rem;
            grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
            margin: .15rem 0 .5rem;
        }

        .ds-checkbox {
            display: inline-flex;
            align-items: center;
            gap: .45rem;
            font-size: .88rem;
            font-weight: 700;
            color: #2b496d;
            margin: 0;
            cursor: pointer;
        }

        .ds-checkbox input[type="checkbox"] {
            width: 1rem;
            height: 1rem;
            margin: 0;
            accent-color: var(--primary);
        }

        input,
        select,
        textarea {
            width: 100%;
            padding: .58rem .62rem;
            border: 1px solid #c8d8ec;
            border-radius: 10px;
            margin-top: .14rem;
            margin-bottom: .56rem;
            background: #fff;
            color: #123053;
            font-size: .9rem;
            transition: border-color .15s ease, box-shadow .15s ease;
        }

        input::placeholder,
        textarea::placeholder {
            color: #8da1ba;
        }

        input:focus,
        select:focus,
        textarea:focus {
            outline: none;
            border-color: #8eb5ec;
            box-shadow: 0 0 0 3px rgba(44, 111, 207, 0.14);
        }

        .grid {
            display: grid;
            gap: .92rem;
        }

        .grid-2 {
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        }

        .alert {
            border-radius: 10px;
            padding: .74rem .82rem;
            margin: 0;
            font-weight: 700;
            font-size: .9rem;
        }

        .alert-success {
            background: #e5f8ed;
            color: #155c33;
            border: 1px solid #bae7cb;
        }

        .alert-error {
            background: #feeaea;
            color: #7e1f1f;
            border: 1px solid #f5c0c0;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: var(--radius-pill);
            padding: .24rem .62rem;
            min-height: 1.42rem;
            font-size: .69rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: .52px;
            white-space: nowrap;
        }

        .status-active,
        .status-approved {
            background: #e0f7ea;
            color: #11552f;
        }

        .status-inactive,
        .status-rejected {
            background: #fbeaec;
            color: #842b33;
        }

        .pager {
            margin-top: .9rem;
            display: flex;
            justify-content: flex-end;
        }

        .pager nav {
            display: inline-flex;
            gap: .3rem;
            flex-wrap: wrap;
        }

        .pager a,
        .pager span {
            border: 1px solid var(--border);
            border-radius: 9px;
            padding: .18rem .42rem;
            min-height: 1.85rem;
            min-width: 1.85rem;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            line-height: 1.05;
            font-size: .78rem;
            font-weight: 700;
            text-decoration: none;
            color: #204267;
            background: #fff;
            transition: background .14s ease, color .14s ease, border-color .14s ease;
        }

        .pager svg {
            width: .85rem;
            height: .85rem;
        }

        .pager a:hover {
            background: #f0f6ff;
            border-color: #c9daf2;
        }

        .pager .active span {
            color: #fff;
            background: var(--primary);
            border-color: var(--primary);
        }

        .muted {
            color: var(--muted);
        }

        .actions {
            display: flex;
            gap: .4rem;
            align-items: center;
            flex-wrap: wrap;
        }

        .ds-page-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: .8rem;
            margin-bottom: .9rem;
            padding-bottom: .65rem;
            border-bottom: 1px dashed #d9e7f8;
        }

        .ds-page-title {
            margin: 0;
            font-size: 1.12rem;
            color: #1a3f6d;
            letter-spacing: .1px;
        }

        .ds-page-subtitle {
            margin: .3rem 0 0;
            font-size: .9rem;
            max-width: 920px;
        }

        .ds-page-actions {
            display: flex;
            gap: .45rem;
            align-items: center;
            flex-wrap: wrap;
            justify-content: flex-end;
        }

        .ds-kpi-card {
            margin-bottom: 0;
            border: 1px solid #dbe7f7;
            border-left-width: 4px;
            padding: .85rem;
            box-shadow: 0 10px 24px rgba(14, 37, 64, 0.08);
        }

        .ds-kpi-primary { border-left-color: var(--primary); }
        .ds-kpi-success { border-left-color: var(--ok); }
        .ds-kpi-danger { border-left-color: var(--danger); }
        .ds-kpi-info { border-left-color: var(--info); }

        .ds-kpi-label {
            color: var(--muted);
            font-size: .75rem;
            text-transform: uppercase;
            letter-spacing: .62px;
            font-weight: 800;
        }

        .ds-kpi-value {
            font-size: 1.5rem;
            font-weight: 800;
            margin-top: .24rem;
            color: #15365f;
        }

        .ds-kpi-meta {
            margin-top: .2rem;
            font-size: .82rem;
        }

        .ds-filter-bar {
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            align-items: end;
            gap: .75rem;
            padding: .82rem;
            border: 1px solid #dbe8f8;
            border-radius: var(--radius-sm);
            background: linear-gradient(180deg, #fbfdff, #f5f9ff);
        }

        .ds-filter-bar > * {
            min-width: 0;
        }

        .ds-table-actions {
            min-width: 250px;
        }

        .ds-badge-neutral {
            background: #eaf1fb;
            color: #27476a;
        }

        .ds-badge-warning {
            background: #fff3de;
            color: #7d5614;
        }

        .ds-badge-info {
            background: #e5efff;
            color: #1e4f90;
        }

        .ds-alert-info {
            background: #ebf4ff;
            border: 1px solid #cadffd;
            color: #1c4881;
        }

        .ds-empty {
            border: 1px dashed #c8d8ec;
            background: linear-gradient(180deg, #fbfdff, #f5f9ff);
            border-radius: var(--radius-sm);
            padding: 1rem;
            text-align: center;
        }

        .ds-empty-title {
            margin: 0;
            color: #24486f;
            font-size: 1rem;
            font-weight: 800;
        }

        .ds-empty-text {
            margin: .3rem 0 0;
            color: var(--muted);
            font-size: .88rem;
        }

        .ds-empty-actions {
            margin-top: .75rem;
            display: flex;
            justify-content: center;
            gap: .45rem;
            flex-wrap: wrap;
        }

        .confirm-modal {
            position: fixed;
            inset: 0;
            z-index: 1000;
            display: grid;
            place-items: center;
            padding: 1rem;
        }

        .confirm-modal[hidden] {
            display: none;
        }

        .confirm-modal-backdrop {
            position: absolute;
            inset: 0;
            background: rgba(9, 25, 44, 0.52);
            backdrop-filter: blur(2px);
        }

        .confirm-modal-dialog {
            position: relative;
            width: min(100%, 500px);
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 14px;
            box-shadow: var(--shadow-md);
            padding: 1rem;
        }

        .confirm-modal-title {
            margin: 0;
            font-size: 1.12rem;
            color: #183e6d;
        }

        .confirm-modal-message {
            margin: .6rem 0 1rem;
            color: var(--muted);
            line-height: 1.5;
        }

        .confirm-modal-actions {
            display: flex;
            justify-content: flex-end;
            gap: .55rem;
            flex-wrap: wrap;
        }

        .confirm-approve-danger { background: linear-gradient(180deg, var(--danger), var(--danger-2)); }
        .confirm-approve-warning { background: linear-gradient(180deg, #d58a23, #ba7419); }
        .confirm-approve-info { background: linear-gradient(180deg, #2f6fcf, #245eb2); }

        .toast-stack {
            position: fixed;
            top: 1rem;
            right: 1rem;
            z-index: 1100;
            display: grid;
            gap: .55rem;
            width: min(92vw, 380px);
            pointer-events: none;
        }

        .toast {
            pointer-events: auto;
            border-radius: 11px;
            border: 1px solid transparent;
            box-shadow: var(--shadow-md);
            background: #fff;
            color: var(--text);
            overflow: hidden;
            transform: translateY(0);
            opacity: 1;
            transition: opacity .2s ease, transform .2s ease;
            animation: toastIn .28s ease;
        }

        @keyframes riseIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes toastIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes ambientFloat {
            from {
                transform: translateY(0) scale(1);
            }
            to {
                transform: translateY(-8px) scale(1.02);
            }
        }

        @keyframes btnSweep {
            from {
                left: -36%;
            }
            to {
                left: 128%;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            .content-container > *,
            .toast,
            .btn,
            .btn-action,
            .card,
            tbody tr,
            body::before {
                animation: none !important;
                transition: none !important;
            }
        }

        .toast.is-closing {
            opacity: 0;
            transform: translateY(-8px);
        }

        .toast-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: .55rem;
            padding: .56rem .72rem .46rem;
            font-size: .74rem;
            text-transform: uppercase;
            letter-spacing: .62px;
            font-weight: 800;
        }

        .toast-title {
            margin: 0;
        }

        .toast-close {
            border: 0;
            background: transparent;
            color: inherit;
            font-size: 1rem;
            line-height: 1;
            cursor: pointer;
            padding: .1rem .2rem;
            border-radius: .3rem;
        }

        .toast-close:hover {
            background: rgba(0, 0, 0, 0.08);
        }

        .toast-body {
            padding: .1rem .72rem .72rem;
            font-size: .9rem;
            font-weight: 700;
            line-height: 1.4;
        }

        .toast-success {
            border-color: #bde7cc;
        }

        .toast-success .toast-head {
            background: #e2f7eb;
            color: #175e35;
        }

        .toast-error {
            border-color: #f4c2c2;
        }

        .toast-error .toast-head {
            background: #feecec;
            color: #842626;
        }

        form.inline {
            display: inline;
        }

        @media (max-width: 1180px) {
            .admin-shell {
                grid-template-columns: 240px minmax(0, 1fr);
            }
        }

        @media (max-width: 980px) {
            .admin-shell {
                grid-template-columns: 1fr;
            }

            .admin-shell.sidebar-collapsed,
            .admin-shell.sidebar-hover-expand {
                grid-template-columns: 1fr;
            }

            .sidebar {
                position: fixed;
                top: 0;
                bottom: 0;
                left: 0;
                z-index: 60;
                width: min(86vw, 320px);
                height: 100vh;
                border-right: 1px solid rgba(255, 255, 255, 0.18);
                border-bottom: 0;
                transform: translateX(-104%);
                transition: transform .2s ease;
                box-shadow: 0 18px 34px rgba(9, 25, 44, 0.35);
            }

            .admin-shell.sidebar-open .sidebar {
                transform: translateX(0);
            }

            .sidebar-close {
                display: inline-flex;
                align-items: center;
                justify-content: center;
            }

            .sidebar-desktop-toggle {
                display: none;
            }

            .sidebar-overlay {
                display: block;
                position: fixed;
                inset: 0;
                z-index: 50;
                border: 0;
                background: rgba(10, 24, 42, 0.42);
                opacity: 0;
                pointer-events: none;
                transition: opacity .2s ease;
                cursor: pointer;
            }

            .admin-shell.sidebar-open .sidebar-overlay {
                opacity: 1;
                pointer-events: auto;
            }

            .sidebar-nav {
                grid-template-columns: repeat(auto-fill, minmax(170px, 1fr));
            }

            .topbar {
                padding: .82rem .95rem;
            }

            .sidebar-toggle {
                display: inline-flex;
            }

            .content {
                padding: .82rem .86rem 1.1rem;
            }

            .btn,
            .btn-action {
                min-height: 2.5rem;
                padding: .62rem .9rem;
            }

            .ds-filter-bar {
                grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            }

            .ds-filter-bar .actions,
            .ds-filter-bar .ds-form-actions,
            .ds-filter-bar div[style*="display:flex"] {
                width: 100%;
                justify-content: flex-start;
                flex-wrap: wrap;
            }

            .ds-table-wrap table {
                min-width: 760px;
            }

            .status-col {
                width: 120px;
            }

            .actions-col {
                min-width: 260px;
            }
        }

        @media (max-width: 680px) {
            .sidebar-nav {
                grid-template-columns: 1fr 1fr;
            }

            .topbar {
                align-items: flex-start;
                flex-direction: column;
            }

            .topbar-left {
                width: 100%;
            }

            .topbar-actions {
                width: 100%;
            }

            .topbar-actions .btn {
                flex: 1 1 auto;
            }

            .card {
                padding: .78rem;
            }

            table {
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }

            .ds-table-wrap table {
                min-width: 680px;
            }

            .ds-table-wrap.table-compact table {
                min-width: 700px;
            }

            .table-actions {
                gap: .35rem;
            }

            .table-actions .btn-action,
            .table-actions .btn,
            .table-actions button {
                min-height: 2.45rem;
                padding: .55rem .72rem;
            }

            .ds-form-grid,
            .grid-2 {
                grid-template-columns: 1fr;
            }

            input,
            select,
            textarea {
                font-size: 16px;
            }

            .ds-page-header {
                flex-direction: column;
                align-items: flex-start;
            }

            .toast-stack {
                left: .68rem;
                right: .68rem;
                width: auto;
            }

        }
    </style>
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
    <?php
        $authUser = auth()->user();
        $accessiblePages = $authUser ? $authUser->getAccessiblePages() : [];
        $hasSinglePageAccess = $authUser && !$authUser->is_admin && count($accessiblePages) === 1;
        $shouldShowAdminNavigation = !$hasSinglePageAccess;
        $showGlobalBackButton = $authUser && !request()->routeIs('dashboard.index');
        $globalBackFallbackUrl = $authUser ? route('dashboard.index') : route('login');
        $canSeePage = function (string $pageSlug) use ($authUser, $accessiblePages): bool {
            return $authUser?->is_admin || in_array($pageSlug, $accessiblePages, true);
        };

        $navSections = [
            [
                'label' => 'Employes',
                'items' => [
                    ['slug' => 'employees.index', 'label' => 'Gestion employes (NFC)', 'route' => 'employees.index', 'pattern' => 'employees.*'],
                    ['slug' => 'employee-history.index', 'label' => 'Historique employes', 'route' => 'employee-history.index', 'pattern' => 'employee-history.*'],
                ],
            ],
            [
                'label' => 'Repas',
                'items' => [
                    ['slug' => 'meal-logs.index', 'label' => 'Historique global repas', 'route' => 'meal-logs.index', 'pattern' => 'meal-logs.*'],
                    ['slug' => 'la-releve.index', 'label' => 'Historique La Releve', 'route' => 'la-releve.index', 'pattern' => 'la-releve.*'],
                    ['slug' => 'extra.index', 'label' => 'Historique Extra', 'route' => 'extra.index', 'pattern' => 'extra.*'],
                    ['slug' => 'meal-rules.index', 'label' => 'Regles de repas', 'route' => 'meal-rules.index', 'pattern' => 'meal-rules.*'],
                ],
            ],
            [
                'label' => 'Analyse',
                'items' => [
                    ['slug' => 'reports.index', 'label' => 'Rapports & tendances', 'route' => 'reports.index', 'pattern' => 'reports.*'],
                ],
            ],
            [
                'label' => 'Systeme',
                'items' => [
                    ['slug' => 'system-catalog.index', 'label' => 'Catalogue Système', 'route' => 'system-catalog.index', 'pattern' => 'system-catalog.*'],
                    ['slug' => 'roles.index', 'label' => 'Gestion des rôles', 'route' => 'roles.index', 'pattern' => 'roles.*'],
                ],
            ],
            [
                'label' => 'Exploitation',
                'items' => [
                    ['slug' => 'kiosk.index', 'label' => 'Kiosk (production)', 'route' => 'kiosk.index', 'pattern' => 'kiosk.*'],
                ],
            ],
        ];
    ?>

    <?php if(auth()->guard()->check()): ?>
        <?php if($shouldShowAdminNavigation): ?>
        <div class="admin-shell" id="admin-shell">
            <aside class="sidebar" id="admin-sidebar" aria-label="Navigation admin">
                <button type="button" class="sidebar-close" id="sidebar-close" aria-label="Fermer le menu">Fermer le menu</button>
                <div class="sidebar-brand">
                    <a class="sidebar-brand-main" href="<?php echo e(route('home')); ?>" aria-label="Retour à l'accueil">
                        <img class="sidebar-brand-logo" src="<?php echo e(asset('assets/logo-sca.JPG')); ?>" alt="SCA">
                        <span class="sidebar-brand-text">SCA Admin</span>
                    </a>
                    <button type="button" class="sidebar-install-btn" data-pwa-install hidden aria-label="Installer SCA Pointage" title="Installer SCA Pointage">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true">
                            <path d="M12 3v11"></path>
                            <path d="m7 9 5 5 5-5"></path>
                            <path d="M5 19h14"></path>
                        </svg>
                    </button>
                </div>
                <button type="button" class="sidebar-desktop-toggle" id="sidebar-desktop-toggle" aria-label="Minimiser la barre latérale" aria-pressed="false">Minimiser menu</button>

                <nav class="sidebar-nav">
                    <a class="sidebar-link <?php echo e(request()->routeIs('dashboard.*') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard.index')); ?>">Tableau de bord</a>

                    <?php $__currentLoopData = $navSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $visibleItems = collect($section['items'])->filter(fn ($item) => $canSeePage($item['slug']));
                        ?>

                        <?php if($visibleItems->isNotEmpty()): ?>
                            <div class="sidebar-muted"><?php echo e($section['label']); ?></div>

                            <?php $__currentLoopData = $visibleItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="sidebar-link <?php echo e(request()->routeIs($item['pattern']) ? 'active' : ''); ?>" href="<?php echo e(route($item['route'])); ?>"><?php echo e($item['label']); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </nav>

                <div class="sidebar-foot">
                    <form
                        method="POST"
                        action="<?php echo e(route('logout')); ?>"
                        data-confirm="true"
                        data-confirm-type="warning"
                        data-confirm-title="Déconnexion"
                        data-confirm-message="Voulez-vous vraiment vous déconnecter ?"
                        data-confirm-approve-label="Oui, me déconnecter"
                        data-confirm-cancel-label="Annuler"
                    >
                        <?php echo csrf_field(); ?>
                        <button class="sidebar-btn" type="submit">Deconnexion</button>
                    </form>
                </div>
            </aside>

            <button type="button" class="sidebar-overlay" id="sidebar-overlay" aria-label="Fermer le menu"></button>

            <div class="main-area">
                <header class="topbar">
                    <div class="topbar-left">
                        <button type="button" class="sidebar-toggle" id="sidebar-toggle" aria-label="Ouvrir le menu" aria-controls="admin-sidebar" aria-expanded="false">☰</button>
                        <div class="topbar-heading">
                            <h1 class="topbar-title"><?php echo $__env->yieldContent('title', 'Administration'); ?></h1>
                            <?php if (! empty(trim($__env->yieldContent('breadcrumbs')))): ?>
                                <nav class="breadcrumbs" aria-label="Fil d'ariane">
                                    <?php echo $__env->yieldContent('breadcrumbs'); ?>
                                </nav>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="topbar-actions">
                        <?php if($showGlobalBackButton): ?>
                            <button
                                type="button"
                                class="btn btn-secondary"
                                data-global-back-btn
                                data-fallback-url="<?php echo e($globalBackFallbackUrl); ?>"
                            >
                                Retour
                            </button>
                        <?php endif; ?>
                        <?php echo $__env->yieldContent('topbar_actions'); ?>
                    </div>
                </header>

                <main class="content">
                    <div class="content-container">
                        <div class="alert-stack">
                            <?php if(isset($errors) && $errors->any()): ?>
                                <?php if (isset($component)) { $__componentOriginald888329b8246e32afd68d2decbd25cf1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald888329b8246e32afd68d2decbd25cf1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.alert','data' => ['type' => 'error']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'error']); ?>
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $attributes = $__attributesOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__attributesOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $component = $__componentOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__componentOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
                            <?php endif; ?>
                        </div>

                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </main>
            </div>
        </div>
        <?php else: ?>
        <div class="single-page-shell">
            <header class="single-page-topbar">
                <h1 class="single-page-title"><?php echo $__env->yieldContent('title', 'Application'); ?></h1>
                <div class="topbar-actions">
                    <?php if($showGlobalBackButton): ?>
                        <button
                            type="button"
                            class="btn btn-secondary"
                            data-global-back-btn
                            data-fallback-url="<?php echo e($globalBackFallbackUrl); ?>"
                        >
                            Retour
                        </button>
                    <?php endif; ?>
                    <form
                        method="POST"
                        action="<?php echo e(route('logout')); ?>"
                        data-confirm="true"
                        data-confirm-type="warning"
                        data-confirm-title="Déconnexion"
                        data-confirm-message="Voulez-vous vraiment vous déconnecter ?"
                        data-confirm-approve-label="Oui, me déconnecter"
                        data-confirm-cancel-label="Annuler"
                    >
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-danger" type="submit">Déconnexion</button>
                    </form>
                </div>
            </header>

            <main class="single-page-content">
                <div class="content-container">
                    <div class="alert-stack">
                        <?php if(isset($errors) && $errors->any()): ?>
                            <?php if (isset($component)) { $__componentOriginald888329b8246e32afd68d2decbd25cf1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald888329b8246e32afd68d2decbd25cf1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.alert','data' => ['type' => 'error']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'error']); ?>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $attributes = $__attributesOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__attributesOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $component = $__componentOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__componentOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
                        <?php endif; ?>
                    </div>

                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </main>
        </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="guest-shell">
            <main class="guest-main">
                <div class="guest-content-wrap">
                    <?php if(session('success')): ?>
                        <?php if (isset($component)) { $__componentOriginald888329b8246e32afd68d2decbd25cf1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald888329b8246e32afd68d2decbd25cf1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.alert','data' => ['type' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'success']); ?><?php echo e(session('success')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $attributes = $__attributesOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__attributesOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $component = $__componentOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__componentOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <?php if (isset($component)) { $__componentOriginald888329b8246e32afd68d2decbd25cf1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald888329b8246e32afd68d2decbd25cf1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.alert','data' => ['type' => 'error']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'error']); ?><?php echo e(session('error')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $attributes = $__attributesOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__attributesOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $component = $__componentOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__componentOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
                    <?php endif; ?>

                    <?php if(isset($errors) && $errors->any()): ?>
                        <?php if (isset($component)) { $__componentOriginald888329b8246e32afd68d2decbd25cf1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald888329b8246e32afd68d2decbd25cf1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.alert','data' => ['type' => 'error']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'error']); ?>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $attributes = $__attributesOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__attributesOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $component = $__componentOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__componentOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
                    <?php endif; ?>

                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </main>
        </div>
    <?php endif; ?>

    <?php if(session('success') || session('error')): ?>
        <div class="toast-stack" id="admin-toast-stack" aria-live="polite" aria-atomic="true">
            <?php if(session('success')): ?>
                <article class="toast toast-success" data-toast>
                    <div class="toast-head">
                        <p class="toast-title">Success</p>
                        <button type="button" class="toast-close" aria-label="Fermer" data-toast-close>&times;</button>
                    </div>
                    <div class="toast-body"><?php echo e(session('success')); ?></div>
                </article>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <article class="toast toast-error" data-toast>
                    <div class="toast-head">
                        <p class="toast-title">Error</p>
                        <button type="button" class="toast-close" aria-label="Fermer" data-toast-close>&times;</button>
                    </div>
                    <div class="toast-body"><?php echo e(session('error')); ?></div>
                </article>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal198527e2b6c4fdc504e2b537e7367e9a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal198527e2b6c4fdc504e2b537e7367e9a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.confirm-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.confirm-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal198527e2b6c4fdc504e2b537e7367e9a)): ?>
<?php $attributes = $__attributesOriginal198527e2b6c4fdc504e2b537e7367e9a; ?>
<?php unset($__attributesOriginal198527e2b6c4fdc504e2b537e7367e9a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal198527e2b6c4fdc504e2b537e7367e9a)): ?>
<?php $component = $__componentOriginal198527e2b6c4fdc504e2b537e7367e9a; ?>
<?php unset($__componentOriginal198527e2b6c4fdc504e2b537e7367e9a); ?>
<?php endif; ?>

    <script>
        (function () {
            var deferredInstallPrompt = null;
            var installButtons = Array.prototype.slice.call(document.querySelectorAll('[data-pwa-install]'));
            var PWA_CONFIRMED_INSTALLED_KEY = 'sca.pwa.confirmedInstalled';
            var OLD_PWA_INSTALLED_KEY_V2 = 'sca.pwa.installed.v2';
            var OLD_PWA_INSTALLED_KEY = 'sca.pwa.installed';

            function updateInstallLabel(label) {
                installButtons.forEach(function (button) {
                    button.setAttribute('aria-label', label);
                    button.setAttribute('title', label);
                });
            }

            function isStandaloneMode() {
                return window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
            }

            function clearOldInstallFlag() {
                try {
                    window.localStorage.removeItem(OLD_PWA_INSTALLED_KEY_V2);
                    window.localStorage.removeItem(OLD_PWA_INSTALLED_KEY);
                } catch (error) {}
            }

            function isConfirmedInstalled() {
                try {
                    return window.localStorage.getItem(PWA_CONFIRMED_INSTALLED_KEY) === '1';
                } catch (error) {
                    return false;
                }
            }

            function markConfirmedInstalled() {
                try {
                    window.localStorage.setItem(PWA_CONFIRMED_INSTALLED_KEY, '1');
                } catch (error) {}
            }

            function hideInstallButtons() {
                installButtons.forEach(function (button) {
                    button.hidden = true;
                });
            }

            function showInstallButtons() {
                if (isStandaloneMode() || isConfirmedInstalled()) {
                    hideInstallButtons();
                    return;
                }

                installButtons.forEach(function (button) {
                    button.hidden = false;
                });
            }

            if ('serviceWorker' in navigator) {
                window.addEventListener('load', function () {
                    clearOldInstallFlag();
                    navigator.serviceWorker.register('/service-worker.js').then(function (registration) {
                        registration.update().catch(function () {});
                    }).catch(function () {});
                });
            }

            window.addEventListener('load', function () {
                window.setTimeout(function () {
                    if (!deferredInstallPrompt && !isStandaloneMode() && !isConfirmedInstalled()) {
                        updateInstallLabel('Installer l\'app');
                        showInstallButtons();
                    }
                }, 1600);
            });

            window.addEventListener('beforeinstallprompt', function (event) {
                event.preventDefault();
                deferredInstallPrompt = event;
                updateInstallLabel('Installer l\'app');
                showInstallButtons();
            });

            window.addEventListener('appinstalled', function () {
                deferredInstallPrompt = null;
                markConfirmedInstalled();
                updateInstallLabel('Application installee');
                hideInstallButtons();
            });

            function showManualInstallHelp() {
                if (typeof window.adminConfirmModal === 'function') {
                    window.adminConfirmModal({
                        type: 'info',
                        title: 'Installation manuelle',
                        message: 'Le navigateur Windows ne propose pas toujours le prompt automatique. Dans Chrome utilisez le menu ... puis Enregistrer et partager ou Installer la page comme application. Dans Edge utilisez le menu ... puis Applications > Installer ce site en tant qu application.',
                        approveLabel: 'OK',
                        cancelLabel: null,
                        onApprove: function () {}
                    });
                } else {
                    window.alert('Dans Chrome/Edge, ouvrez le menu du navigateur puis choisissez Installer cette page comme application.');
                }
            }

            function runPwaInstall() {
                if (!deferredInstallPrompt) {
                    showManualInstallHelp();
                    return;
                }

                deferredInstallPrompt.prompt();
                deferredInstallPrompt.userChoice.then(function (choice) {
                    if (choice.outcome === 'accepted') {
                        updateInstallLabel('Verifier l\'installation');
                        if (typeof window.adminConfirmModal === 'function') {
                            window.adminConfirmModal({
                                type: 'info',
                                title: 'Installation demandee',
                                message: 'Si Windows ne met pas automatiquement un raccourci sur le Bureau, cherchez SCA Pointage dans le menu Demarrer. Dans Edge ou Chrome, vous pouvez aussi verifier la liste des applications installees du navigateur.',
                                approveLabel: 'OK',
                                cancelLabel: null,
                                onApprove: function () {}
                            });
                        }
                    } else {
                        updateInstallLabel('Actualiser pour reessayer');
                    }
                }).finally(function () {
                    deferredInstallPrompt = null;
                    if (!isStandaloneMode()) {
                        showInstallButtons();
                    }
                });
            }

            function confirmPwaInstall() {
                if (typeof window.adminConfirmModal !== 'function') {
                    runPwaInstall();
                    return;
                }

                window.adminConfirmModal({
                    type: 'info',
                    title: 'Installer SCA Pointage',
                    message: 'Voulez-vous installer SCA Pointage sur ce poste ? Le navigateur peut placer l application dans le menu Demarrer; le raccourci Bureau depend de Windows et du navigateur.',
                    approveLabel: 'Installer',
                    cancelLabel: 'Annuler',
                    onApprove: runPwaInstall
                });
            }

            installButtons.forEach(function (button) {
                button.addEventListener('click', function () {
                    confirmPwaInstall();
                });
            });

            var shell = document.getElementById('admin-shell');
            var sidebar = document.getElementById('admin-sidebar');
            var sidebarToggle = document.getElementById('sidebar-toggle');
            var sidebarClose = document.getElementById('sidebar-close');
            var sidebarOverlay = document.getElementById('sidebar-overlay');
            var sidebarDesktopToggle = document.getElementById('sidebar-desktop-toggle');
            var SIDEBAR_COLLAPSED_KEY = 'sca.sidebar.collapsed';

            function isDesktopViewport() {
                return window.innerWidth > 980;
            }

            function setDesktopCollapsedState(collapsed) {
                if (!shell || !isDesktopViewport()) {
                    return;
                }

                shell.classList.toggle('sidebar-collapsed', collapsed);
                shell.classList.remove('sidebar-hover-expand');

                if (sidebarDesktopToggle) {
                    sidebarDesktopToggle.setAttribute('aria-pressed', collapsed ? 'true' : 'false');
                    sidebarDesktopToggle.textContent = collapsed ? 'Agrandir menu' : 'Minimiser menu';
                }
            }

            function readDesktopCollapsedPreference() {
                try {
                    return window.localStorage.getItem(SIDEBAR_COLLAPSED_KEY) === '1';
                } catch (error) {
                    return false;
                }
            }

            function writeDesktopCollapsedPreference(collapsed) {
                try {
                    window.localStorage.setItem(SIDEBAR_COLLAPSED_KEY, collapsed ? '1' : '0');
                } catch (error) {
                    // Ignore storage write failures.
                }
            }

            function closeSidebar() {
                if (!shell) {
                    return;
                }

                shell.classList.remove('sidebar-open');
                document.body.classList.remove('sidebar-open');
                if (sidebarToggle) {
                    sidebarToggle.setAttribute('aria-expanded', 'false');
                }
            }

            function openSidebar() {
                if (!shell) {
                    return;
                }

                shell.classList.add('sidebar-open');
                document.body.classList.add('sidebar-open');
                if (sidebarToggle) {
                    sidebarToggle.setAttribute('aria-expanded', 'true');
                }
            }

            if (sidebarToggle) {
                sidebarToggle.addEventListener('click', function () {
                    if (shell && shell.classList.contains('sidebar-open')) {
                        closeSidebar();
                    } else {
                        openSidebar();
                    }
                });
            }

            if (sidebarClose) {
                sidebarClose.addEventListener('click', closeSidebar);
            }

            if (sidebarOverlay) {
                sidebarOverlay.addEventListener('click', closeSidebar);
            }

            if (sidebarDesktopToggle) {
                sidebarDesktopToggle.addEventListener('click', function () {
                    if (!shell || !isDesktopViewport()) {
                        return;
                    }

                    var nextCollapsed = !shell.classList.contains('sidebar-collapsed');
                    setDesktopCollapsedState(nextCollapsed);
                    writeDesktopCollapsedPreference(nextCollapsed);
                });
            }

            if (sidebar) {
                sidebar.addEventListener('mouseenter', function () {
                    if (!shell || !isDesktopViewport() || !shell.classList.contains('sidebar-collapsed')) {
                        return;
                    }

                    shell.classList.add('sidebar-hover-expand');
                });

                sidebar.addEventListener('mouseleave', function () {
                    if (!shell || !isDesktopViewport()) {
                        return;
                    }

                    shell.classList.remove('sidebar-hover-expand');
                });

                sidebar.addEventListener('click', function (event) {
                    var link = event.target.closest('.sidebar-link');
                    if (!link || !shell || !isDesktopViewport()) {
                        return;
                    }

                    setDesktopCollapsedState(true);
                    writeDesktopCollapsedPreference(true);
                });
            }

            document.addEventListener('keydown', function (event) {
                if (event.key === 'Escape') {
                    closeSidebar();
                }
            });

            window.addEventListener('resize', function () {
                if (window.innerWidth > 980) {
                    closeSidebar();
                    setDesktopCollapsedState(readDesktopCollapsedPreference());
                } else if (shell) {
                    shell.classList.remove('sidebar-collapsed', 'sidebar-hover-expand');
                }
            });

            if (isDesktopViewport()) {
                setDesktopCollapsedState(readDesktopCollapsedPreference());
            }

            var toastStack = document.getElementById('admin-toast-stack');
            if (toastStack) {
                function closeToast(toast) {
                    if (!toast) {
                        return;
                    }

                    toast.classList.add('is-closing');
                    window.setTimeout(function () {
                        toast.remove();
                    }, 200);
                }

                toastStack.querySelectorAll('[data-toast]').forEach(function (toast) {
                    var closeButton = toast.querySelector('[data-toast-close]');
                    if (closeButton) {
                        closeButton.addEventListener('click', function () {
                            closeToast(toast);
                        });
                    }

                    window.setTimeout(function () {
                        closeToast(toast);
                    }, 4500);
                });
            }

            var modal = document.getElementById('admin-confirm-modal');
            if (!modal) {
                return;
            }

            var titleNode = document.getElementById('admin-confirm-modal-title');
            var messageNode = document.getElementById('admin-confirm-modal-message');
            var approveButton = modal.querySelector('[data-confirm-approve]');
            var cancelButton = modal.querySelector('[data-confirm-cancel]');
            var closeOverlay = modal.querySelector('[data-confirm-close]');
            var defaultApproveLabel = approveButton.textContent.trim() || 'Confirmer';
            var defaultCancelLabel = cancelButton.textContent.trim() || 'Annuler';

            var activeElementBeforeOpen = null;
            var onApprove = null;

            function trapFocus(event) {
                if (event.key !== 'Tab') {
                    return;
                }

                var focusable = modal.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
                if (!focusable.length) {
                    event.preventDefault();
                    return;
                }

                var first = focusable[0];
                var last = focusable[focusable.length - 1];

                if (event.shiftKey && document.activeElement === first) {
                    event.preventDefault();
                    last.focus();
                } else if (!event.shiftKey && document.activeElement === last) {
                    event.preventDefault();
                    first.focus();
                }
            }

            function closeModal() {
                modal.hidden = true;
                document.body.style.overflow = '';
                document.removeEventListener('keydown', handleKeyDown);

                if (activeElementBeforeOpen && typeof activeElementBeforeOpen.focus === 'function') {
                    activeElementBeforeOpen.focus();
                }

                onApprove = null;
            }

            function handleKeyDown(event) {
                if (event.key === 'Escape') {
                    event.preventDefault();
                    closeModal();
                    return;
                }

                trapFocus(event);
            }

            function openModal(config) {
                titleNode.textContent = config.title || 'Confirmation';
                messageNode.textContent = config.message || 'Veuillez confirmer cette action.';
                approveButton.textContent = config.approveLabel || defaultApproveLabel;
                cancelButton.textContent = config.cancelLabel || defaultCancelLabel;

                approveButton.classList.remove('confirm-approve-danger', 'confirm-approve-warning', 'confirm-approve-info');
                if (config.type === 'warning') {
                    approveButton.classList.add('confirm-approve-warning');
                } else if (config.type === 'info') {
                    approveButton.classList.add('confirm-approve-info');
                } else {
                    approveButton.classList.add('confirm-approve-danger');
                }

                activeElementBeforeOpen = document.activeElement;
                onApprove = config.onApprove || null;

                modal.hidden = false;
                document.body.style.overflow = 'hidden';
                document.addEventListener('keydown', handleKeyDown);
                approveButton.focus();
            }

            // Expose shared confirm modal API for page-specific actions.
            window.adminConfirmModal = function (config) {
                openModal(config || {});
            };

            function hasActiveFilterParams(paramList) {
                var searchParams = new URLSearchParams(window.location.search || '');
                var paramsToCheck = [];

                if (typeof paramList === 'string' && paramList.trim() !== '') {
                    paramsToCheck = paramList
                        .split(',')
                        .map(function (item) { return item.trim(); })
                        .filter(Boolean);
                } else {
                    searchParams.forEach(function (_, key) {
                        if (key !== 'page') {
                            paramsToCheck.push(key);
                        }
                    });
                }

                for (var i = 0; i < paramsToCheck.length; i += 1) {
                    var key = paramsToCheck[i];
                    if (!searchParams.has(key)) {
                        continue;
                    }

                    var value = searchParams.get(key);
                    if (typeof value === 'string' && value.trim() !== '') {
                        return true;
                    }
                }

                return false;
            }

            approveButton.addEventListener('click', function () {
                if (typeof onApprove === 'function') {
                    onApprove();
                }
                closeModal();
            });

            cancelButton.addEventListener('click', closeModal);
            closeOverlay.addEventListener('click', closeModal);

            document.addEventListener('submit', function (event) {
                var form = event.target;
                if (!(form instanceof HTMLFormElement)) {
                    return;
                }

                if (form.dataset.confirmAccepted === '1') {
                    form.dataset.confirmAccepted = '0';
                    return;
                }

                if (form.dataset.confirm !== 'true') {
                    return;
                }

                event.preventDefault();

                openModal({
                    type: form.dataset.confirmType || 'danger',
                    title: form.dataset.confirmTitle || 'Confirmation',
                    message: form.dataset.confirmMessage || 'Veuillez confirmer cette action.',
                    approveLabel: form.dataset.confirmApproveLabel || defaultApproveLabel,
                    cancelLabel: form.dataset.confirmCancelLabel || defaultCancelLabel,
                    onApprove: function () {
                        form.dataset.confirmAccepted = '1';
                        form.requestSubmit();
                    }
                });
            }, true);

            document.addEventListener('click', function (event) {
                var trigger = event.target.closest('[data-confirm-url]');
                if (!trigger) {
                    return;
                }

                event.preventDefault();

                if (trigger.dataset.confirmOnlyWhenActive === 'true' && !hasActiveFilterParams(trigger.dataset.confirmActiveParams)) {
                    window.location.href = trigger.dataset.confirmUrl;
                    return;
                }

                openModal({
                    type: trigger.dataset.confirmType || 'info',
                    title: trigger.dataset.confirmTitle || 'Confirmation',
                    message: trigger.dataset.confirmMessage || 'Veuillez confirmer cette action.',
                    approveLabel: trigger.dataset.confirmApproveLabel || defaultApproveLabel,
                    cancelLabel: trigger.dataset.confirmCancelLabel || defaultCancelLabel,
                    onApprove: function () {
                        window.location.href = trigger.dataset.confirmUrl;
                    }
                });
            });

            document.addEventListener('click', function (event) {
                var backTrigger = event.target.closest('[data-global-back-btn]');
                if (!backTrigger) {
                    return;
                }

                event.preventDefault();

                var fallbackUrl = backTrigger.dataset.fallbackUrl || '/dashboard';
                var referrer = document.referrer || '';
                var canUseHistoryBack = false;

                try {
                    if (referrer !== '') {
                        var currentUrl = new URL(window.location.href);
                        var previousUrl = new URL(referrer);
                        canUseHistoryBack = previousUrl.origin === currentUrl.origin && previousUrl.href !== currentUrl.href;
                    }
                } catch (error) {
                    canUseHistoryBack = false;
                }

                if (canUseHistoryBack && window.history.length > 1) {
                    window.history.back();
                    return;
                }

                window.location.href = fallbackUrl;
            });

            // Handle export links with empty data validation
            document.addEventListener('click', function (event) {
                var trigger = event.target.closest('.export-link');
                if (!trigger) {
                    return;
                }

                event.preventDefault();

                function runExport() {
                    var exportUrl = trigger.dataset.exportUrl;
                    if (!exportUrl) {
                        return;
                    }

                    // Build URL from current form state so export always follows live filters.
                    var form = trigger.closest('form');
                    if (form) {
                        var url = new URL(exportUrl, window.location.origin);
                        var formData = new FormData(form);

                        formData.forEach(function (value, key) {
                            if (typeof value !== 'string') {
                                return;
                            }

                            var normalizedValue = value.trim();

                            if (normalizedValue === '') {
                                url.searchParams.delete(key);
                                return;
                            }

                            url.searchParams.set(key, normalizedValue);
                        });

                        // Pagination should not affect exported data.
                        url.searchParams.delete('page');
                        exportUrl = url.toString();
                    }

                    // Fetch the export endpoint to check for empty data
                    fetch(exportUrl)
                        .then(function(response) {
                            if (response.status === 422) {
                                return response.json().then(function(data) {
                                    openModal({
                                        type: 'warning',
                                        title: 'Impossible d\'exporter',
                                        message: data.error || 'Aucune donnée disponible avec ces filtres.',
                                        approveLabel: 'OK',
                                        cancelLabel: null,
                                        onApprove: function () {}
                                    });
                                });
                            } else if (response.ok) {
                                // Successful export - trigger download
                                window.location.href = exportUrl;
                            } else {
                                openModal({
                                    type: 'danger',
                                    title: 'Erreur',
                                    message: 'Une erreur est survenue lors de l\'export.',
                                    approveLabel: 'OK',
                                    cancelLabel: null,
                                    onApprove: function () {}
                                });
                            }
                        })
                        .catch(function() {
                            openModal({
                                type: 'danger',
                                title: 'Erreur',
                                message: 'Une erreur est survenue lors de la vérification de l\'export.',
                                approveLabel: 'OK',
                                cancelLabel: null,
                                onApprove: function () {}
                            });
                        });
                }

                openModal({
                    type: 'info',
                    title: trigger.dataset.confirmTitle || 'Confirmer export',
                    message: trigger.dataset.confirmMessage || 'Voulez-vous confirmer l\'export avec les filtres actuels ?',
                    approveLabel: trigger.dataset.confirmApproveLabel || 'Exporter',
                    cancelLabel: trigger.dataset.confirmCancelLabel || 'Annuler',
                    onApprove: runExport,
                });
            });
        })();
    </script>

    <?php echo $__env->yieldContent('scripts'); ?>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/layouts/app.blade.php ENDPATH**/ ?>