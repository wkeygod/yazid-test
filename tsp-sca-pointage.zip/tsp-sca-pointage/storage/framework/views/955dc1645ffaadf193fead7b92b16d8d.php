<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kiosk SCA</title>
    <style>
        :root {
            --bg: #ecf3ff;
            --panel: #ffffff;
            --text: #12253f;
            --muted: #5a6f8d;
            --line: #d6e3f6;
            --primary: #11669c;
            --primary-2: #1a79b8;
            --ok-bg: #dff4e8;
            --ok-text: #0f5a32;
            --denied-bg: #fde5e5;
            --denied-text: #7f1d1d;
            --idle-bg: #e8f0fd;
            --idle-text: #19407a;
            --scan-dark-1: #09192b;
            --scan-dark-2: #0f2d49;
            --scan-dark-3: #134061;
            --scan-accent-cyan: #43c4ff;
            --scan-accent-green: #1fd08e;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: "Avenir Next", "Nunito Sans", "Segoe UI", sans-serif;
            color: var(--text);
            background:
                radial-gradient(circle at 2% 0%, #dce9ff 0%, transparent 32%),
                radial-gradient(circle at 92% 8%, #d7e7ff 0%, transparent 36%),
                linear-gradient(180deg, #f8fbff 0%, var(--bg) 100%);
            overflow-x: hidden;
        }

        .kiosk-shell {
            min-height: 100vh;
            display: grid;
            grid-template-rows: auto auto auto 1fr;
        }

        .kiosk-header {
            padding: 0.25rem 1.6rem;
            color: #fff;
            background: linear-gradient(120deg, var(--primary), var(--primary-2));
            box-shadow: 0 10px 26px rgba(31, 95, 191, 0.3);
            font-weight: 700;
            font-size: 1.15rem;
            letter-spacing: .2px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: .7rem;
            animation: headerSlide .45s ease;
        }

        .kiosk-header-right {
            display: inline-flex;
            align-items: center;
            gap: .5rem;
        }

        .logout-btn {
            border: 1px solid rgba(255, 255, 255, 0.45);
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.12);
            color: #fff;
            font-weight: 700;
            padding: .42rem .78rem;
            text-decoration: none;
            cursor: pointer;
        }

        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.2);
        }

        .kiosk-logo {
            height: 2rem;
            width: auto;
            display: block;
            background: rgba(255, 255, 255, 0.14);
            border-radius: .5rem;
            padding: .12rem;
        }

        .kiosk-brand {
            display: inline-flex;
            align-items: center;
            gap: .7rem;
            color: inherit;
            text-decoration: none;
        }

        .kiosk-main {
            display: grid;
            grid-template-columns: minmax(340px, 1fr) minmax(460px, 1.35fr);
            gap: 0.85rem;
            padding: 0.4rem;
            animation: pageRise .46s ease;
        }

        /* ── Apple Segmented Control ── */
        .kiosk-nav {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: .45rem 1.2rem;
            background: rgba(255, 255, 255, 0.88);
            border-bottom: 1px solid rgba(190, 213, 242, 0.6);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            animation: navFade .5s ease;
        }

        .kiosk-nav-segment {
            position: relative;
            display: inline-flex;
            align-items: center;
            background: rgba(116, 150, 195, 0.14);
            border-radius: 999px;
            padding: 3px;
            gap: 0;
            box-shadow:
                inset 0 1px 3px rgba(20, 55, 105, 0.12),
                0 1px 2px rgba(255,255,255,0.9);
        }

        .kiosk-nav-link {
            position: relative;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            height: 2rem;
            line-height: 1;
            font-size: .875rem;
            font-weight: 600;
            text-decoration: none;
            color: rgba(30, 58, 100, 0.72);
            padding: 0 1.1rem;
            border-radius: 999px;
            white-space: nowrap;
            z-index: 1;
            transition:
                color .22s ease,
                transform .14s ease;
            -webkit-user-select: none;
            user-select: none;
            letter-spacing: .01em;
        }

        .kiosk-nav-link:hover:not(.active) {
            color: rgba(30, 58, 100, 0.95);
            transform: none;
        }

        .kiosk-nav-link.active {
            color: #fff;
        }

        .kiosk-nav-link.active::before {
            content: '';
            position: absolute;
            inset: 0;
            border-radius: 999px;
            background: linear-gradient(135deg, #2464b4 0%, #3481d1 50%, #1f5ca8 100%);
            box-shadow:
                0 2px 8px rgba(36, 100, 180, 0.40),
                0 1px 2px rgba(36, 100, 180, 0.22),
                inset 0 1px 0 rgba(255,255,255,0.25);
            z-index: -1;
            animation: segmentSlideIn .22s cubic-bezier(.34,1.56,.64,1);
        }

        @keyframes segmentSlideIn {
            from { opacity: .55; transform: scaleX(.85) scaleY(.85); }
            to   { opacity: 1;  transform: scaleX(1)   scaleY(1); }
        }

        .panel {
            background: var(--panel);
            border: 1px solid var(--line);
            border-radius: 1rem;
            padding: 1rem;
            box-shadow: 0 10px 24px rgba(18, 37, 63, 0.1);
            position: relative;
            overflow: hidden;
            transition: transform .18s ease, box-shadow .18s ease;
        }

        .panel::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, rgba(17, 102, 156, 0.75), rgba(26, 121, 184, 0.6), rgba(24, 168, 112, 0.45));
            pointer-events: none;
        }

        .panel:hover {
            transform: translateY(-2px);
            box-shadow: 0 16px 30px rgba(18, 37, 63, 0.14);
        }

        .title {
            margin: 0 0 .25rem;
            font-size: 1.4rem;
        }

        .muted {
            color: var(--muted);
            margin: 0 0 1rem;
        }

        label {
            display: block;
            font-size: .95rem;
            font-weight: 600;
            margin-bottom: .4rem;
        }

        .uid-input {
            width: 100%;
            height: 64px;
            border: 2px solid #c8d8ee;
            border-radius: .8rem;
            padding: 0 1rem;
            font-size: 1.35rem;
            font-weight: 700;
            letter-spacing: .6px;
            text-transform: uppercase;
            margin-bottom: .85rem;
        }

        .submit-btn {
            width: 100%;
            height: 56px;
            border: 0;
            border-radius: .8rem;
            background: linear-gradient(135deg, var(--primary), var(--primary-2));
            color: #fff;
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 10px 18px rgba(17, 102, 156, 0.24);
            transition: transform .15s ease, filter .15s ease;
        }

        .submit-btn:hover {
            transform: translateY(-1px);
            filter: brightness(1.03);
        }

        .scan-panel {
            display: grid;
            gap: .9rem;
            justify-items: center;
            text-align: center;
        }

        .scan-launch-btn {
            width: 100%;
            min-height: 168px;
            border: 1px solid #b7cdeb;
            border-radius: 1.4rem;
            background:
                radial-gradient(circle at 50% 20%, rgba(255,255,255,.28), transparent 40%),
                linear-gradient(135deg, #0f5f91 0%, #1475b1 38%, #0f8eb3 62%, #18a870 100%);
            background-size: 100% 100%, 300% 300%;
            background-position: center, 0% 50%;
            color: #fff;
            box-shadow: 0 18px 34px rgba(17, 102, 156, 0.28);
            cursor: pointer;
            display: grid;
            place-items: center;
            gap: .5rem;
            padding: 1rem;
            transition: transform .16s ease, filter .16s ease, box-shadow .16s ease;
            position: relative;
            overflow: hidden;
        }

        .scan-launch-btn::after {
            content: "";
            position: absolute;
            inset: 12px;
            border-radius: 1.1rem;
            border: 1px solid rgba(255, 255, 255, 0.22);
            opacity: 0;
            transform: scale(0.94);
            pointer-events: none;
        }

        .scan-launch-btn.scan-ready::after,
        .scan-launch-btn.scan-active::after {
            opacity: 1;
            animation: scanPulse 1.2s ease-in-out infinite;
        }

        .scan-launch-btn:hover {
            transform: translateY(-2px);
            filter: brightness(1.03);
            box-shadow: 0 22px 40px rgba(17, 102, 156, 0.32);
        }

        .scan-launch-btn:active {
            transform: translateY(0) scale(0.99);
        }

        .scan-launch-btn.scan-active {
            animation: scanColorShift 2.8s ease-in-out infinite, scanButtonGlow 1.35s ease-in-out infinite;
            border-color: rgba(165, 220, 255, 0.88);
            box-shadow: 0 24px 46px rgba(17, 102, 156, 0.36), 0 0 0 5px rgba(24, 168, 112, 0.18);
        }

        .scan-launch-icon {
            width: 88px;
            height: 88px;
            border-radius: 50%;
            border: 2px solid rgba(255,255,255,.45);
            display: grid;
            place-items: center;
            background: rgba(255,255,255,.12);
            box-shadow: inset 0 0 0 10px rgba(255,255,255,.05);
            color: #ffffff;
        }

        .scan-launch-icon svg {
            width: 58px;
            height: 58px;
            display: block;
        }

        .scan-launch-btn.scan-active .scan-launch-icon {
            animation: scanIconPulse 1.2s ease-in-out infinite, scanIconColor 2.8s ease-in-out infinite;
        }

        .scan-launch-title {
            font-size: 1.25rem;
            font-weight: 800;
            letter-spacing: .2px;
        }

        .scan-launch-subtitle {
            font-size: .95rem;
            font-weight: 600;
            opacity: .92;
        }

        .scan-capture {
            position: absolute;
            left: -9999px;
            top: auto;
            width: 1px;
            height: 1px;
            opacity: 0;
        }

        .scan-capture:focus {
            outline: none;
        }

        .scan-ready {
            border-color: #18a870;
            box-shadow: 0 0 0 4px rgba(24, 168, 112, 0.16), 0 18px 34px rgba(17, 102, 156, 0.28);
        }

        .scan-active-card {
            animation: scanCardGlow 1.2s ease-in-out infinite, scanCardTint 2.8s ease-in-out infinite;
        }

        .scan-actions {
            width: 100%;
            display: grid;
            gap: .65rem;
        }

        .scan-submit-btn {
            height: 52px;
            font-size: 1rem;
        }

        .status-box {
            animation: pageRise .48s ease;
        }

        .status-authorized {
            animation: pulseSoft 2.2s ease-in-out infinite;
        }

        @keyframes headerSlide {
            from { opacity: 0; transform: translateY(-12px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes navFade {
            from { opacity: 0; transform: translateY(-6px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes pageRise {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes pulseSoft {
            0%, 100% { box-shadow: 0 0 0 0 rgba(18, 168, 112, 0.18); }
            50% { box-shadow: 0 0 0 7px rgba(18, 168, 112, 0); }
        }

        @keyframes scanPulse {
            0% { transform: scale(0.94); opacity: 0.35; }
            50% { transform: scale(1); opacity: 0.95; }
            100% { transform: scale(1.04); opacity: 0.35; }
        }

        @keyframes scanColorShift {
            0% { background-position: center, 0% 50%; }
            33% { background-position: center, 50% 50%; }
            66% { background-position: center, 100% 50%; }
            100% { background-position: center, 0% 50%; }
        }

        @keyframes scanButtonGlow {
            0%, 100% { filter: saturate(1.02) brightness(1); }
            50% { filter: saturate(1.2) brightness(1.06); }
        }

        @keyframes scanIconPulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.08); }
        }

        @keyframes scanIconColor {
            0% { background: rgba(255,255,255,.12); color: #ffffff; }
            33% { background: rgba(167, 223, 255, .16); color: #eef9ff; }
            66% { background: rgba(24, 168, 112, .18); color: #ffffff; }
            100% { background: rgba(255,255,255,.12); color: #ffffff; }
        }

        @keyframes scanCardGlow {
            0%, 100% { box-shadow: 0 18px 34px rgba(17, 102, 156, 0.28), 0 0 0 0 rgba(24, 168, 112, 0.12); }
            50% { box-shadow: 0 24px 42px rgba(17, 102, 156, 0.34), 0 0 0 8px rgba(24, 168, 112, 0.16); }
        }

        @keyframes scanCardTint {
            0% { border-color: #b9cff0; background-color: rgba(232, 240, 253, 0.98); }
            33% { border-color: #7dcdf1; background-color: rgba(228, 245, 255, 0.98); }
            66% { border-color: #8ed4ac; background-color: rgba(227, 249, 236, 0.98); }
            100% { border-color: #b9cff0; background-color: rgba(232, 240, 253, 0.98); }
        }

        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation: none !important;
                transition: none !important;
            }
        }

        .status-box {
            min-height: 220px;
            border-radius: 1rem;
            display: grid;
            align-content: center;
            gap: .5rem;
            padding: 1.25rem;
            border: 2px solid transparent;
        }

        .status-box h2 {
            margin: 0;
            font-size: 2rem;
            line-height: 1.1;
        }

        .status-box .employee {
            font-size: 1.25rem;
            font-weight: 700;
        }

        .status-box .message {
            font-size: 1.05rem;
            font-weight: 600;
        }

        .status-authorized {
            background: var(--ok-bg);
            color: var(--ok-text);
            border-color: #8ed4ac;
        }

        .status-denied {
            background: var(--denied-bg);
            color: var(--denied-text);
            border-color: #efabab;
        }

        .status-idle {
            background: var(--idle-bg);
            color: var(--idle-text);
            border-color: #b9cff0;
        }

        .error-list {
            margin: .9rem 0 0;
            padding: .75rem .9rem;
            border-radius: .7rem;
            border: 1px solid #f0b7b7;
            background: #fde5e5;
            color: #7f1d1d;
            font-weight: 600;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: .94rem;
        }

        th, td {
            text-align: left;
            padding: .62rem;
            border-bottom: 1px solid var(--line);
        }

        .pill {
            display: inline-block;
            border-radius: 999px;
            padding: .2rem .55rem;
            font-size: .78rem;
            font-weight: 700;
            text-transform: uppercase;
        }

        .pill-approved {
            background: #dff4e8;
            color: #0f5a32;
        }

        .pill-rejected {
            background: #fde5e5;
            color: #7f1d1d;
        }

        .meal-selector-container {
            background: linear-gradient(180deg, rgba(255, 255, 255, 0.92), rgba(249, 252, 255, 0.75));
            backdrop-filter: blur(10px);
            padding: 0.85rem 1rem;
            border-bottom: 1px solid #d6e3f6;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 0.55rem;
            box-shadow: 0 2px 6px rgba(31, 95, 191, 0.06);
        }

        .meal-selector-label {
            font-size: 0.82rem;
            font-weight: 700;
            color: #12253f;
            letter-spacing: 0.3px;
            flex-shrink: 0;
        }

        .meal-selector-group {
            display: flex;
            gap: 0.35rem;
            border-radius: 1.2rem;
            overflow: visible;
            border: 1px solid #c8d8ee;
            background: #f4f9ff;
            box-shadow: 0 3px 10px rgba(31, 95, 191, 0.1), inset 0 1px 2px rgba(255, 255, 255, 0.8);
            padding: 0.28rem;
            max-width: 800px;
            margin: 0 50px;
            padding-left: 50px;
            padding-right: 50px;
        }

        .meal-selector-btn {
            flex: 1;
            min-width: 72px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 0.35rem 0.75rem;
            background: transparent;
            color: #5a6f8d;
            cursor: pointer;
            transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
            border: none;
            font-size: 0.85rem;
            font-weight: 600;
            position: relative;
            user-select: none;
            border-radius: 1rem;
        }

        .meal-selector-btn:last-child {
            border-right: none;
        }

        .meal-selector-btn:hover {
            background: rgba(31, 95, 191, 0.08);
            color: #1f5fbf;
        }

        .meal-selector-btn.active {
            background: linear-gradient(135deg, #12845b 0%, #18a870 100%);
            color: #ffffff;
            box-shadow: 0 4px 12px rgba(18, 168, 112, 0.3);
            font-weight: 700;
        }

        .meal-selector-icon {
            font-size: 1.2rem;
            margin-bottom: 0.08rem;
        }

        .meal-selector-text {
            font-size: 0.8rem;
            font-weight: 700;
            letter-spacing: 0.15px;
        }

        .logs-panel {
            display: flex;
            flex-direction: column;
            gap: .75rem;
        }

        .logs-panel-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: .75rem;
        }

        .logs-scroll {
            max-height: 520px;
            overflow-y: auto;
            padding-right: .35rem;
        }

        .logs-scroll::-webkit-scrollbar {
            width: 10px;
        }

        .logs-scroll::-webkit-scrollbar-thumb {
            background: #bfd3ef;
            border-radius: 999px;
        }

        .logs-scroll::-webkit-scrollbar-track {
            background: #edf4fd;
            border-radius: 999px;
        }

        .logs-filter-chip {
            display: inline-flex;
            align-items: center;
            gap: .4rem;
            border-radius: 999px;
            padding: .35rem .7rem;
            background: #e8f0fd;
            color: #19407a;
            font-weight: 700;
            font-size: .85rem;
            white-space: nowrap;
        }

        .logs-empty {
            padding: 1rem;
            border-radius: .8rem;
            background: #f4f9ff;
            color: #5a6f8d;
            border: 1px dashed #cdddf2;
            font-weight: 600;
        }

        /* UX kiosk refresh: dark elegant scan card + animated signal + status bars */
        .scan-launch-btn {
            min-height: 186px;
            border: 1px solid #2d4f72;
            background:
                radial-gradient(circle at 12% 18%, rgba(67, 196, 255, .22), transparent 40%),
                radial-gradient(circle at 88% 82%, rgba(31, 208, 142, .14), transparent 45%),
                linear-gradient(145deg, var(--scan-dark-1) 0%, var(--scan-dark-2) 44%, var(--scan-dark-3) 100%);
            background-size: 100% 100%, 100% 100%, 170% 170%;
            box-shadow: 0 20px 40px rgba(7, 19, 34, 0.5), inset 0 1px 0 rgba(255, 255, 255, 0.06);
            padding: 1rem 1rem .9rem;
            gap: .62rem;
        }

        .scan-launch-btn::before {
            content: "";
            position: absolute;
            width: 180px;
            height: 180px;
            right: -70px;
            top: -70px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(67, 196, 255, 0.2) 0%, rgba(67, 196, 255, 0.02) 62%, transparent 72%);
            pointer-events: none;
        }

        .scan-launch-btn::after {
            border: 1px solid rgba(126, 184, 233, 0.25);
        }

        .scan-launch-btn:hover {
            box-shadow: 0 26px 48px rgba(6, 18, 34, 0.55), inset 0 1px 0 rgba(255, 255, 255, 0.08);
        }

        .scan-launch-btn.scan-active {
            border-color: rgba(114, 203, 255, 0.88);
            box-shadow: 0 28px 52px rgba(6, 18, 34, 0.58), 0 0 0 4px rgba(67, 196, 255, 0.2), 0 0 0 9px rgba(31, 208, 142, 0.12);
        }

        .scan-launch-icon {
            border: 2px solid rgba(168, 220, 255, .55);
            background: rgba(20, 54, 84, .66);
            box-shadow: inset 0 0 0 10px rgba(130, 197, 242, .07), 0 0 0 1px rgba(255, 255, 255, .06);
        }

        .scan-launch-title {
            text-shadow: 0 1px 2px rgba(0,0,0,.34);
        }

        .scan-launch-subtitle {
            color: #d7ecff;
        }

        .scan-launch-state {
            width: 100%;
            display: grid;
            gap: .35rem;
            margin-top: .25rem;
        }

        .scan-launch-state-label {
            font-size: .78rem;
            font-weight: 700;
            letter-spacing: .2px;
            color: #d6e8fa;
            text-transform: uppercase;
        }

        .scan-launch-state-track {
            width: 100%;
            height: 7px;
            border-radius: 999px;
            background: rgba(160, 197, 227, 0.24);
            overflow: hidden;
            border: 1px solid rgba(170, 206, 234, .18);
        }

        .scan-launch-state-fill {
            width: 36%;
            height: 100%;
            border-radius: inherit;
            background: linear-gradient(90deg, var(--scan-accent-cyan) 0%, #67d6ff 45%, var(--scan-accent-green) 100%);
            transition: width .3s ease;
        }

        .scan-launch-btn.scan-active .scan-launch-state-fill {
            width: 100%;
            animation: scanMeterPulse 1.1s ease-in-out infinite;
        }

        .scan-launch-btn.scan-ready .scan-launch-state-fill {
            width: 72%;
        }

        .status-box {
            position: relative;
            overflow: hidden;
        }

        .status-progress {
            margin-top: .2rem;
            height: 8px;
            width: 100%;
            border-radius: 999px;
            background: rgba(18, 47, 90, .16);
            border: 1px solid rgba(84, 127, 188, .24);
            overflow: hidden;
        }

        .status-progress-fill {
            width: 100%;
            height: 100%;
            border-radius: inherit;
            background: linear-gradient(90deg, #2f6fcf 0%, #4aa0ff 60%, #20be86 100%);
            transform-origin: left center;
        }

        @keyframes scanMeterPulse {
            0%, 100% { filter: brightness(1); }
            50% { filter: brightness(1.18); }
        }

        @keyframes statusCountdown {
            from { transform: scaleX(1); opacity: 1; }
            to { transform: scaleX(0); opacity: .65; }
        }

        @keyframes statusPingPong {
            0% { transform: translateX(-65%); opacity: .82; }
            100% { transform: translateX(65%); opacity: 1; }
        }


        @media (max-width: 980px) {
            .kiosk-main {
                grid-template-columns: 1fr;
            }

            .scan-launch-btn {
                min-height: 150px;
            }

            .scan-launch-icon {
                width: 76px;
                height: 76px;
                font-size: 2.25rem;
            }

            .status-box {
                min-height: 180px;
            }

            .meal-selector-container {
                gap: 0.5rem;
                padding: 0.5rem 0.8rem;
            }

            .meal-selector-group {
                margin: 0 30px;
                padding-left: 30px;
                padding-right: 30px;
            }

            .meal-selector-btn {
                padding: 0.32rem 0.65rem;
                font-size: 0.8rem;
                min-width: 75px;
            }

            .meal-selector-icon {
                font-size: 1.2rem;
                margin-bottom: 0.15rem;
            }

        }
    </style>
</head>
<body>
<?php
    $result = session('kiosk_result');
    $statusClass = 'status-idle';
    $statusTitle = 'En attente de scan';
    $statusMessage = 'Scannez une carte pour verifier l\'acces repas.';
    $employeeName = null;
    $allowedMealTypes = [];
    $cardUid = null;
    $mealTypeSelected = false;
    // $selectedMealType est deja calcule par KioskController::index() (selection
    // automatique par heure a partir des reglages de repas, ou choix manuel en session).

    if (is_array($result)) {
        $allowedMealTypes = $result['allowed_meal_types'] ?? [];
        $cardUid = $result['card_uid'] ?? null;

        if (($result['status'] ?? null) === 'success') {
            $statusClass = 'status-authorized';
            $statusTitle = 'Autorise';
            $mealTypeSelected = true;
        } elseif (($result['status'] ?? null) === 'pending_meal_selection') {
            $statusClass = 'status-idle';
            $statusTitle = 'Selectionnez le repas';
            $mealTypeSelected = false;
        } else {
            $statusClass = 'status-denied';
            $statusTitle = 'Refuse';
            $mealTypeSelected = true;
        }

        $statusMessage = $result['message'] ?? $statusMessage;
        $employeeName = $result['employee_name'] ?? null;
    }

    $mealTypeLabels = [
        'breakfast' => 'Petit-dejeuner',
        'lunch' => 'Dejeuner',
        'dinner' => 'Diner',
    ];

    $selectedMealRuleForLabel = $mealRules->first(fn ($rule) => (string) $rule->id === (string) $selectedMealType);
    $selectedMealTypeLabel = $selectedMealRuleForLabel?->name
        ?? ($mealTypeLabels[$selectedMealType] ?? ucfirst((string) $selectedMealType));
?>

<?php
    $authUser = auth()->user();
    $kioskHideNav = $authUser && !$authUser->is_admin && count($authUser->getAccessiblePages()) === 1;
?>

<div class="kiosk-shell">
    <header class="kiosk-header">
        <a class="kiosk-brand" href="<?php echo e(route('home')); ?>" aria-label="Retour à l'accueil">
            <img class="kiosk-logo" src="<?php echo e(asset('assets/logo-sca.JPG')); ?>" alt="SCA">
            <span>SCA • Pointage kiosque</span>
        </a>
        <div class="kiosk-header-right">
            <form method="POST" action="<?php echo e(route('logout')); ?>"
                  data-confirm="true"
                  data-confirm-type="warning"
                  data-confirm-title="Déconnexion"
                  data-confirm-message="Voulez-vous vraiment vous déconnecter ?"
                  data-confirm-approve-label="Oui, me déconnecter"
                  data-confirm-cancel-label="Annuler">
                <?php echo csrf_field(); ?>
                <button type="submit" class="logout-btn">Déconnexion</button>
            </form>
        </div>
    </header>

    <?php if(!$kioskHideNav): ?>
    <nav class="kiosk-nav" aria-label="Navigation kiosk">
        <div class="kiosk-nav-segment" role="tablist">
            <a class="kiosk-nav-link active" href="<?php echo e(route('kiosk.index')); ?>" role="tab" aria-selected="true">Scan NFC</a>
            <a class="kiosk-nav-link" href="<?php echo e(route('kiosk.la-releve.page')); ?>" role="tab" aria-selected="false">La Relève</a>
            <a class="kiosk-nav-link" href="<?php echo e(route('kiosk.extra.page')); ?>" role="tab" aria-selected="false">Extra</a>
        </div>
    </nav>
    <?php endif; ?>


    <div class="meal-selector-container">
        <span class="meal-selector-label">Type de repas :</span>
        <div class="meal-selector-group">
            <?php $__empty_1 = true; $__currentLoopData = $mealRules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <button type="button" class="meal-selector-btn <?php echo e((string) $selectedMealType === (string) $rule->id ? 'active' : ''); ?>" data-meal-type="<?php echo e($rule->id); ?>" onclick="selectMealType('<?php echo e($rule->id); ?>')">
                    <span class="meal-selector-icon"><?php echo e($rule->icon ?? '🍽️'); ?></span>
                    <span class="meal-selector-text"><?php echo e(substr($rule->name, 0, 10)); ?></span>
                </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p style="padding: 1rem; color: #d32f2f;">Aucune regle de repas active. Veuillez creer au moins une regle.</p>
            <?php endif; ?>
        </div>
    </div>

    <main class="kiosk-main">
        <section class="panel">
            <h1 class="title">Pointage repas</h1>
            <p class="muted">Appuyez sur le bouton NFC, présentez la carte, puis le scan se lance automatiquement.</p>

            <form method="POST" action="<?php echo e(route('kiosk.scan')); ?>" id="scanForm" class="scan-panel">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="meal_type_field" name="meal_type" value="<?php echo e($selectedMealType); ?>">
                <input
                    id="card_uid"
                    class="scan-capture"
                    type="text"
                    name="card_uid"
                    value="<?php echo e(old('card_uid', $cardUid)); ?>"
                    autocomplete="off"
                    autocapitalize="characters"
                    spellcheck="false"
                    inputmode="text"
                    required
                    aria-label="UID carte NFC"
                >

                <button type="button" id="launchScanBtn" class="scan-launch-btn">
                    <span class="scan-launch-icon" aria-hidden="true">
                        <svg viewBox="0 0 64 64" focusable="false" aria-hidden="true">
                            <path d="M18 20c-5 5-5 19 0 24" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M46 20c5 5 5 19 0 24" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M24 26c-2 3-2 9 0 12" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M40 26c2 3 2 9 0 12" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
                            <circle cx="32" cy="32" r="3.5" fill="currentColor"/>
                            <path d="M16 46c4-4 8-6 16-6s12 2 16 6" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </span>
                    <span class="scan-launch-title">Lancer le scan NFC</span>
                    <span class="scan-launch-subtitle">Présentez la carte, puis appuyez sur OK du lecteur</span>
                    <div class="scan-launch-state" aria-hidden="true">
                        <span class="scan-launch-state-label" id="scanStateLabel">Lecteur prêt</span>
                        <span class="scan-launch-state-track">
                            <span class="scan-launch-state-fill"></span>
                        </span>
                    </div>
                </button>
            </form>

            <?php if($errors->any()): ?>
                <div class="error-list">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <div class="status-box <?php echo e($statusClass); ?>" id="scanStatusBox" style="margin-top: 1rem;" data-default-title="En attente de scan" data-default-employee="Employe: -" data-default-message="Scannez une carte pour verifier l'acces repas." data-current-status="<?php echo e($statusClass); ?>">
                <h2><?php echo e($statusTitle); ?></h2>
                <div class="employee"><?php echo e($employeeName ?: 'Employe: -'); ?></div>
                <div class="message"><?php echo e($statusMessage); ?></div>
                <div class="status-progress" id="scanStatusProgress" aria-hidden="true">
                    <div class="status-progress-fill" id="scanStatusProgressFill"></div>
                </div>
            </div>
        </section>

        <section class="panel logs-panel">
            <div class="logs-panel-header">
                <h2 class="title" style="font-size: 1.2rem; margin-bottom: 0;">Derniers 10 logs repas</h2>
                <span class="logs-filter-chip">Filtre: <span id="logsFilterLabel"><?php echo e($selectedMealTypeLabel); ?></span></span>
            </div>

            <div class="logs-scroll">
                <table>
                    <thead>
                        <tr>
                            <th>Heure</th>
                            <th>UID</th>
                            <th>Employe</th>
                            <th>Repas</th>
                            <th>Statut</th>
                            <th>Message</th>
                        </tr>
                    </thead>
                    <tbody id="logsTableBody">
                        <?php $__empty_1 = true; $__currentLoopData = $lastLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr data-meal-type="<?php echo e($log->meal_type ?? ''); ?>">
                                <td><?php echo e($log->logged_at?->format('Y-m-d H:i:s')); ?></td>
                                <td><?php echo e($log->card_uid ?: ($log->card?->uid ?? '-')); ?></td>
                                <td><?php echo e(trim(($log->employee?->first_name ?? '') . ' ' . ($log->employee?->last_name ?? '')) ?: '-'); ?></td>
                                <td><?php echo e($mealTypeLabels[$log->meal_type ?? ''] ?? ucfirst((string) $log->meal_type)); ?></td>
                                <td>
                                    <span class="pill <?php echo e($log->status === 'approved' ? 'pill-approved' : 'pill-rejected'); ?>">
                                        <?php echo e($log->status); ?>

                                    </span>
                                </td>
                                <td><?php echo e($log->reason ?: '-'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6">
                                    <div id="logsEmptyState" class="logs-empty">Aucun log pour <?php echo e($selectedMealTypeLabel); ?>.</div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>
</div>

<script>
    let currentMealType = document.getElementById('meal_type_field')?.value || document.querySelector('.meal-selector-btn')?.dataset.mealType;
    const scanForm = document.getElementById('scanForm');
    const launchScanBtn = document.getElementById('launchScanBtn');
    const scanCapture = document.getElementById('card_uid');
    const scanStatusBox = document.getElementById('scanStatusBox');
    const scanStatusProgress = document.getElementById('scanStatusProgress');
    const scanStatusProgressFill = document.getElementById('scanStatusProgressFill');
    const scanStateLabel = document.getElementById('scanStateLabel');
    let statusResetTimer = null;
    let isScanActiveByClick = false;

    document.addEventListener('DOMContentLoaded', function() {
        setSelectedMealType(currentMealType, false);
        if (scanCapture) {
            scanCapture.focus({ preventScroll: true });
        }

        const currentStatus = scanStatusBox?.dataset.currentStatus || 'status-idle';
        if (currentStatus === 'status-authorized' || currentStatus === 'status-denied') {
            scheduleStatusAutoReset(3000);
        } else {
            startStatusLoop();
        }
    });

    function setScanState(isActive) {
        if (launchScanBtn) {
            launchScanBtn.classList.toggle('scan-active', isActive);
            launchScanBtn.classList.toggle('scan-ready', isActive);
        }

        if (scanStateLabel) {
            scanStateLabel.textContent = isActive ? 'Scan en cours' : 'Lecteur prêt';
        }

        if (scanCapture?.closest('.panel')) {
            scanCapture.closest('.panel').classList.toggle('scan-active-card', isActive);
        }

        if (isActive && isScanActiveByClick) {
            startStatusLoop();
        } else {
            stopStatusLoop();
        }
    }

    function clearStatusResetTimer() {
        if (statusResetTimer) {
            clearTimeout(statusResetTimer);
            statusResetTimer = null;
        }
    }

    function startStatusLoop() {
        if (!scanStatusProgress || !scanStatusProgressFill) {
            return;
        }

        if (!isScanActiveByClick) {
            stopStatusLoop();
            return;
        }

        scanStatusProgressFill.style.animation = 'none';
        void scanStatusProgressFill.offsetWidth;
        scanStatusProgressFill.style.animation = 'statusPingPong 1.65s ease-in-out infinite alternate';
    }

    function stopStatusLoop() {
        if (scanStatusProgressFill) {
            scanStatusProgressFill.style.animation = 'none';
        }
    }

    function triggerStatusCountdown(durationMs = 3000) {
        if (!scanStatusProgress || !scanStatusProgressFill) {
            return;
        }

        scanStatusProgressFill.style.animation = 'none';
        void scanStatusProgressFill.offsetWidth;
        scanStatusProgressFill.style.animation = `statusCountdown ${durationMs}ms linear forwards`;
    }

    function scheduleStatusAutoReset(durationMs = 3000) {
        clearStatusResetTimer();
        triggerStatusCountdown(durationMs);
        statusResetTimer = window.setTimeout(function () {
            resetStatusToIdle();
        }, durationMs);
    }

    function resetStatusToIdle() {
        if (!scanStatusBox) {
            return;
        }

        clearStatusResetTimer();

        scanStatusBox.classList.remove('status-authorized', 'status-denied');
        scanStatusBox.classList.add('status-idle');
        scanStatusBox.dataset.currentStatus = 'status-idle';

        const titleNode = scanStatusBox.querySelector('h2');
        const employeeNode = scanStatusBox.querySelector('.employee');
        const messageNode = scanStatusBox.querySelector('.message');

        if (titleNode) {
            titleNode.textContent = scanStatusBox.dataset.defaultTitle || 'En attente de scan';
        }

        if (employeeNode) {
            employeeNode.textContent = scanStatusBox.dataset.defaultEmployee || 'Employe: -';
        }

        if (messageNode) {
            messageNode.textContent = scanStatusBox.dataset.defaultMessage || "Scannez une carte pour verifier l'acces repas.";
        }

        startStatusLoop();
    }

    if (launchScanBtn && scanCapture) {
        launchScanBtn.addEventListener('click', function () {
            scanCapture.value = '';
            scanCapture.focus({ preventScroll: true });
            isScanActiveByClick = true;
            setScanState(true);
        });
    }

    if (scanCapture && scanForm) {
        scanCapture.addEventListener('focus', function () {
            setScanState(true);
        });

        scanCapture.addEventListener('keydown', function (event) {
            if (event.key === 'Enter') {
                event.preventDefault();
                scanForm.requestSubmit();
            }
        });

        scanCapture.addEventListener('input', function () {
            if (this.value.trim() !== '') {
                setScanState(true);
            }
        });

        scanCapture.addEventListener('blur', function () {
            if (this.value.trim() === '') {
                isScanActiveByClick = false;
                setScanState(false);
            }
        });
    }

    function selectMealType(type) {
        setSelectedMealType(type, true);

        let hiddenField = document.getElementById('meal_type_field');
        if (hiddenField) {
            hiddenField.value = type;
        }

        if (scanCapture) {
            scanCapture.value = '';
            scanCapture.focus({ preventScroll: true });
        }

        isScanActiveByClick = false;
        setScanState(true);
        resetStatusToIdle();
    }

    function setSelectedMealType(type, updateHiddenField = true) {
        document.querySelectorAll('.meal-selector-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.mealType === type);
        });

        currentMealType = type;
        filterMealLogs(type);

        if (updateHiddenField) {
            let hiddenField = document.getElementById('meal_type_field');
            if (hiddenField) {
                hiddenField.value = type;
            }
        } else {
            let hiddenField = document.getElementById('meal_type_field');
            if (hiddenField && !hiddenField.value) {
                hiddenField.value = type;
            }
        }
    }

    function filterMealLogs(type) {
        // Trouver le nom de la règle du bouton actif
        const activeBtn = document.querySelector(`.meal-selector-btn[data-meal-type="${type}"]`);
        const mealName = activeBtn ? activeBtn.textContent.trim() : `Repas #${type}`;

        const logsLabel = document.getElementById('logsFilterLabel');
        if (logsLabel) {
            logsLabel.textContent = mealName;
        }

        const rows = document.querySelectorAll('#logsTableBody tr[data-meal-type]');
        let visibleCount = 0;

        rows.forEach(row => {
            const shouldShow = row.dataset.mealType === String(type);
            row.style.display = shouldShow ? '' : 'none';
            if (shouldShow) {
                visibleCount += 1;
            }
        });

        const emptyState = document.getElementById('logsEmptyState');
        if (emptyState) {
            emptyState.textContent = `Aucun log pour ${mealName}.`;
            emptyState.parentElement.parentElement.style.display = visibleCount === 0 ? '' : 'none';
        }
    }

    // Ajouter des styles smooth et transitions
    const style = document.createElement('style');
    style.innerHTML = `
        .meal-selector-btn {
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
        }

        .meal-selector-btn:active {
            transform: scale(0.95) !important;
        }
    `;
    document.head.appendChild(style);
</script>

<?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\TSP-Restaurant-pointage\resources\views\kiosk\index.blade.php ENDPATH**/ ?>