<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4 py-6">
    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Nouvel utilisateur','subtitle' => 'Créer un utilisateur avec accès limité']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Nouvel utilisateur','subtitle' => 'Créer un utilisateur avec accès limité']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <div class="row justify-content-center">
        <div class="col-xl-8 col-lg-10">
            <div class="card shadow-sm">
                <div class="card-header d-flex justify-content-between align-items-center bg-light">
                    <h6 class="mb-0 fw-bold text-dark">
                        <i class="fas fa-user-plus me-2"></i>Formulaire d'ajout
                    </h6>
                    <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-outline-secondary btn-sm">
                        <i class="fas fa-arrow-left me-1"></i>Retour à la liste
                    </a>
                </div>

                <form method="POST" action="<?php echo e(route('roles.store')); ?>" class="card-body">
                    <?php echo csrf_field(); ?>

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="first_name" class="form-label fw-bold">Prénom <span class="text-danger">*</span></label>
                            <input
                                type="text"
                                class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="first_name"
                                name="first_name"
                                value="<?php echo e(old('first_name')); ?>"
                                required
                            >
                            <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-6">
                            <label for="last_name" class="form-label fw-bold">Nom <span class="text-danger">*</span></label>
                            <input
                                type="text"
                                class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="last_name"
                                name="last_name"
                                value="<?php echo e(old('last_name')); ?>"
                                required
                            >
                            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-12">
                            <label for="email" class="form-label fw-bold">Email <span class="text-danger">*</span></label>
                            <input
                                type="email"
                                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="email"
                                name="email"
                                value="<?php echo e(old('email')); ?>"
                                required
                            >
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-12">
                            <label for="password" class="form-label fw-bold">Mot de passe <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <input
                                    type="password"
                                    class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="password"
                                    name="password"
                                    required
                                >
                                <button type="button" class="btn btn-outline-secondary password-toggle-btn" id="togglePasswordBtn">
                                    <i class="fas fa-eye me-1"></i>
                                    <span id="togglePasswordLabel">Afficher</span>
                                </button>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <small class="text-muted">Minimum 8 caractères.</small>
                        </div>

                        <div class="col-12">
                            <hr class="my-2">
                            <label class="form-label fw-bold">Pages autorisées</label>
                            <small class="d-block text-muted mb-2">Cochez les pages accessibles pour cet utilisateur.</small>

                            <div class="permissions-grid">
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="permission-item">
                                        <input
                                            type="checkbox"
                                            class="form-check-input me-2"
                                            name="permissions[]"
                                            value="<?php echo e($permission->id); ?>"
                                            <?php echo e(in_array($permission->id, old('permissions', [])) ? 'checked' : ''); ?>

                                        >
                                        <span class="fw-500"><?php echo e($permission->name); ?></span>
                                        <small class="d-block text-muted"><?php echo e($permission->description); ?></small>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php $__errorArgs = ['permissions.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger small mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="d-flex gap-2 mt-4 pt-3 border-top">
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-save me-1"></i>Créer l'utilisateur
                        </button>
                        <a href="<?php echo e(route('roles.index')); ?>" id="cancelBtn" data-cancel-url="<?php echo e(route('roles.index')); ?>" class="btn btn-outline-secondary">
                            <i class="fas fa-times me-1"></i>Annuler
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .permissions-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 0.75rem;
    }

    .permission-item {
        border: 1px solid #dee2e6;
        border-radius: 0.375rem;
        padding: 0.75rem;
        background: #f8f9fa;
        cursor: pointer;
    }

    .permission-item:hover {
        border-color: #0d6efd;
        background: #fff;
    }

    .fw-500 {
        font-weight: 500;
    }

    .password-toggle-btn {
        min-width: 120px;
        font-weight: 500;
    }

    @media (max-width: 767px) {
        .permissions-grid {
            grid-template-columns: 1fr;
        }
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    const togglePasswordBtn = document.getElementById('togglePasswordBtn');
    const passwordInput = document.getElementById('password');
    const togglePasswordLabel = document.getElementById('togglePasswordLabel');
    const form = document.querySelector("form[action='<?php echo e(route('roles.store')); ?>']");
    const cancelBtn = document.getElementById('cancelBtn');
    const initialFormState = new URLSearchParams(new FormData(form)).toString();

    function hasFormChanges() {
        const currentFormState = new URLSearchParams(new FormData(form)).toString();
        return currentFormState !== initialFormState;
    }

    function updateCancelButtonState() {
        const isDirty = hasFormChanges();
        cancelBtn.classList.toggle('btn-danger', isDirty);
        cancelBtn.classList.toggle('btn-outline-secondary', !isDirty);
    }

    togglePasswordBtn.addEventListener('click', function () {
        const isHidden = passwordInput.type === 'password';
        passwordInput.type = isHidden ? 'text' : 'password';
        togglePasswordBtn.querySelector('i').className = isHidden
            ? 'fas fa-eye-slash me-1'
            : 'fas fa-eye me-1';
        togglePasswordLabel.textContent = isHidden ? 'Masquer' : 'Afficher';
    });

    form.addEventListener('input', updateCancelButtonState);
    form.addEventListener('change', updateCancelButtonState);

    cancelBtn.addEventListener('click', function (event) {
        event.preventDefault();

        const cancelUrl = cancelBtn.dataset.cancelUrl;

        if (!hasFormChanges()) {
            window.location.href = cancelUrl;
            return;
        }

        const confirmLink = document.createElement('a');
        confirmLink.href = cancelUrl;
        confirmLink.dataset.confirmUrl = cancelUrl;
        confirmLink.dataset.confirmType = 'warning';
        confirmLink.dataset.confirmTitle = 'Annuler la création';
        confirmLink.dataset.confirmMessage = 'Des champs sont remplis. Voulez-vous vraiment annuler ?';
        confirmLink.dataset.confirmCancelLabel = 'Rester';
        confirmLink.dataset.confirmApproveLabel = 'Quitter';
        confirmLink.style.display = 'none';
        document.body.appendChild(confirmLink);
        confirmLink.click();
        confirmLink.remove();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\TSP-Restaurant-pointage\resources\views\roles\create.blade.php ENDPATH**/ ?>