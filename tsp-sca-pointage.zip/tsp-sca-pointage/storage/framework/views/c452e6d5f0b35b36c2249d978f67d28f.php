<?php $__env->startSection('title', 'Detail carte'); ?>
<?php $__env->startSection('topbar_actions'); ?>
    <a class="btn" href="<?php echo e(route('cards.edit', $card)); ?>">Modifier</a>
    <a class="btn btn-secondary" href="<?php echo e(route('cards.index')); ?>">Retour liste</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $statusTone = match($card->status) {
            \App\Models\Card::STATUS_ACTIVE => 'active',
            \App\Models\Card::STATUS_BLOCKED, \App\Models\Card::STATUS_LOST => 'warning',
            \App\Models\Card::STATUS_REPLACED => 'info',
            default => 'inactive',
        };

        $cardHolderName = $card->employee
            ? trim(($card->employee->first_name ?? '') . ' ' . ($card->employee->last_name ?? ''))
            : 'Unassigned employee';

        $currentAssignment = $card->assignments
            ->sortByDesc(fn ($item) => optional($item->assigned_at)?->timestamp ?? 0)
            ->first(fn ($item) => is_null($item->unassigned_at));
    ?>

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Fiche carte','subtitle' => 'UID: ' . $card->uid]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Fiche carte','subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('UID: ' . $card->uid)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <div class="grid" style="grid-template-columns: minmax(0, 1fr) 360px; align-items:start; gap:1rem;">
        <div style="min-width:0;">
            <div class="card" style="background:linear-gradient(120deg, #e6f0ff, #f7fbff); border-color:#c9dbf3;">
                <div style="display:flex; align-items:flex-start; justify-content:space-between; gap:1rem; flex-wrap:wrap;">
                    <div>
                        <div style="font-size:.8rem; letter-spacing:.6px; color:#48607d; text-transform:uppercase; font-weight:700;">UID Carte</div>
                        <div style="font-size:1.85rem; font-weight:800; color:#14345c; line-height:1.25; margin-top:.2rem;"><?php echo e($card->uid); ?></div>
                    </div>
                    <div>
                        <?php if (isset($component)) { $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.badge','data' => ['tone' => $statusTone]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($statusTone)]); ?><?php echo e(strtoupper(str_replace('_', ' ', $card->status))); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $attributes = $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $component = $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="card">
                <h2 style="margin-top:0;">Informations actuelles</h2>
                <?php if (isset($component)) { $__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.data-table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <tbody>
                    <tr>
                        <th style="width:220px;">Employe assigne</th>
                        <td>
                            <?php if($card->employee): ?>
                                <?php echo e($card->employee->employee_no); ?> - <?php echo e($card->employee->first_name); ?> <?php echo e($card->employee->last_name); ?>

                            <?php else: ?>
                                Non assignee
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Date d'assignation</th>
                        <td><?php echo e(optional($currentAssignment?->assigned_at)->format('Y-m-d H:i') ?: '-'); ?></td>
                    </tr>
                    <tr>
                        <th>Date d'emission</th>
                        <td><?php echo e(optional($card->issued_at)->format('Y-m-d') ?: '-'); ?></td>
                    </tr>
                    <?php if($card->status === \App\Models\Card::STATUS_BLOCKED): ?>
                        <tr>
                            <th>Date blocage</th>
                            <td><?php echo e(optional($card->blocked_at)->format('Y-m-d H:i') ?: '-'); ?></td>
                        </tr>
                        <tr>
                            <th>Motif blocage</th>
                            <td><?php echo e($card->block_reason ?: '-'); ?></td>
                        </tr>
                    <?php endif; ?>
                    <?php if($card->status === \App\Models\Card::STATUS_REPLACED && $card->replacedByCard): ?>
                        <tr>
                            <th>Carte de remplacement</th>
                            <td>
                                <a href="<?php echo e(route('cards.show', $card->replacedByCard)); ?>" style="font-weight:700; color:#1e5bb9; text-decoration:none;">
                                    <?php echo e($card->replacedByCard->uid); ?>

                                </a>
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0)): ?>
<?php $attributes = $__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0; ?>
<?php unset($__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0)): ?>
<?php $component = $__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0; ?>
<?php unset($__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0); ?>
<?php endif; ?>
            </div>

            <div class="card">
                <h2 style="margin-top:0;">Derniers logs repas de cette carte</h2>
                <?php
                    $latestLogs = $card->mealLogs->take(10);
                ?>
                <?php if($latestLogs->isEmpty()): ?>
                    <?php if (isset($component)) { $__componentOriginal99089f8e2ef4184d7d35db81d60c6521 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.empty-state','data' => ['title' => 'Aucun log disponible','message' => 'Cette carte n\'a pas encore d\'historique de passage.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Aucun log disponible','message' => 'Cette carte n\'a pas encore d\'historique de passage.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $attributes = $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $component = $__componentOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
                <?php else: ?>
                    <?php if (isset($component)) { $__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.data-table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <thead>
                        <tr>
                            <th>Date</th>
                            <th>Statut</th>
                            <th>Employe</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $latestLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(optional($log->logged_at)->format('Y-m-d H:i') ?: '-'); ?></td>
                                <td><?php echo e(strtoupper($log->status ?? '-')); ?></td>
                                <td><?php echo e($log->employee ? ($log->employee->employee_no . ' - ' . $log->employee->first_name . ' ' . $log->employee->last_name) : '-'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0)): ?>
<?php $attributes = $__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0; ?>
<?php unset($__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0)): ?>
<?php $component = $__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0; ?>
<?php unset($__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0); ?>
<?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

        <aside class="card" style="position:sticky; top:82px;">
            <h2 style="margin-top:0;">Actions admin</h2>

            <?php if($card->status !== \App\Models\Card::STATUS_BLOCKED): ?>
                <form method="POST" action="<?php echo e(route('cards.block', $card)); ?>" style="margin-bottom:1rem;"
                      data-confirm="true"
                      data-confirm-type="danger"
                                            data-confirm-title="Block card: <?php echo e($card->uid); ?> - <?php echo e($cardHolderName); ?>"
                                            data-confirm-message="Are you sure you want to block this card? The employee will not be able to access the restaurant.">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <label>Bloquer la carte</label>
                                        <input type="text" name="block_reason" placeholder="Motif de blocage (optionnel)">
                    <button class="btn" type="submit" style="width:100%; background:#d9480f;">Bloquer</button>
                </form>
            <?php endif; ?>

            <?php if($card->status === \App\Models\Card::STATUS_BLOCKED): ?>
                <form method="POST" action="<?php echo e(route('cards.unblock', $card)); ?>" style="margin-bottom:1rem;"
                      data-confirm="true"
                      data-confirm-type="warning"
                      data-confirm-title="Debloquer carte"
                      data-confirm-message="Confirmer le debloquage de cette carte ?">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <button class="btn" type="submit" style="width:100%; background:#2b8a3e;">Debloquer</button>
                </form>
            <?php endif; ?>

            <?php if($card->status !== \App\Models\Card::STATUS_LOST): ?>
                <form method="POST" action="<?php echo e(route('cards.mark-lost', $card)); ?>" style="margin-bottom:1rem;"
                      data-confirm="true"
                      data-confirm-type="danger"
                      data-confirm-title="Marquer carte perdue"
                      data-confirm-message="Confirmer le passage de cette carte au statut perdue ?">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <label>Marquer perdue</label>
                    <input type="text" name="block_reason" placeholder="Motif de perte" required>
                    <button class="btn" type="submit" style="width:100%; background:#c53030;">Marquer perdue</button>
                </form>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('cards.replace', $card)); ?>" style="margin-bottom:1rem;"
                  data-confirm="true"
                  data-confirm-type="warning"
                data-confirm-title="Replace card: <?php echo e($card->uid); ?>"
                data-confirm-message="Replace this card with a new one?"
                data-confirm-cancel-label="Cancel"
                data-confirm-approve-label="Confirm">
                <?php echo csrf_field(); ?>
                <label>Remplacer la carte</label>
                <input type="text" name="new_uid" placeholder="Nouveau UID" required>
                <select name="employee_id">
                    <option value="">Employe actuel</option>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($employee->id); ?>" <?php echo e((string) $card->assigned_employee_id === (string) $employee->id ? 'selected' : ''); ?>>
                            <?php echo e($employee->employee_no); ?> - <?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input type="text" name="reason" placeholder="Raison remplacement (optionnel)">
                <button class="btn" type="submit" style="width:100%; background:#5f3dc4;">Remplacer</button>
            </form>

            <form method="POST" action="<?php echo e(route('cards.reassign', $card)); ?>" style="margin-bottom:1rem;"
                  data-confirm="true"
                  data-confirm-type="info"
                  data-confirm-title="Reassigner carte"
                  data-confirm-message="Confirmer la reassignment de cette carte ?">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <label>Reassigner la carte</label>
                <select name="employee_id" required>
                    <option value="">Choisir un employe</option>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($employee->id); ?>" <?php echo e((string) $card->assigned_employee_id === (string) $employee->id ? 'selected' : ''); ?>>
                            <?php echo e($employee->employee_no); ?> - <?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button class="btn" type="submit" style="width:100%; background:#2c6cb0;">Reassigner</button>
            </form>

            <?php if($card->employee): ?>
                <form method="POST" action="<?php echo e(route('cards.detach', $card)); ?>"
                      data-confirm="true"
                      data-confirm-type="warning"
                      data-confirm-title="Detacher carte"
                      data-confirm-message="Confirmer le detachement de cette carte ?">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <button class="btn" type="submit" style="width:100%; background:#6b7280;">Detacher</button>
                </form>
            <?php endif; ?>
        </aside>
    </div>

    <div class="card">
        <h2 style="margin-top:0;">Journal d'audit des actions admin</h2>
        <?php if($auditLogs->isEmpty()): ?>
            <?php if (isset($component)) { $__componentOriginal99089f8e2ef4184d7d35db81d60c6521 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.empty-state','data' => ['title' => 'Aucune action admin','message' => 'Aucun evenement de cycle de vie n\'a encore ete enregistre.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Aucune action admin','message' => 'Aucun evenement de cycle de vie n\'a encore ete enregistre.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $attributes = $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $component = $__componentOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
        <?php else: ?>
            <?php if (isset($component)) { $__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.data-table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <thead>
                <tr>
                    <th>Date</th>
                    <th>Action</th>
                    <th>Admin</th>
                    <th>Motif</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $auditLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(optional($entry->performed_at)->format('Y-m-d H:i:s') ?: '-'); ?></td>
                        <td><?php echo e($entry->action_type); ?></td>
                        <td><?php echo e($entry->performedBy?->name ?? '-'); ?></td>
                        <td><?php echo e($entry->reason ?: '-'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0)): ?>
<?php $attributes = $__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0; ?>
<?php unset($__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0)): ?>
<?php $component = $__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0; ?>
<?php unset($__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0); ?>
<?php endif; ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\TSP-Restaurant-pointage\resources\views\cards\show.blade.php ENDPATH**/ ?>