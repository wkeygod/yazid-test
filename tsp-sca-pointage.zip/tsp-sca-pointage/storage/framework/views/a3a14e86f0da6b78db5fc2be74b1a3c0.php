<footer class="kiosk-footer">
    <div class="footer-content">
        <p class="footer-text">Développé par <span class="footer-highlight">Taleb Mohammed Saïd</span> • Tous droits réservés © <span class="footer-company">SARL Societe Coopérative d'Approvisionnement (SCA)</span></p>
    </div>
</footer>

<style>
    .kiosk-footer {
        background: linear-gradient(135deg, rgba(17, 102, 156, 0.95), rgba(26, 121, 184, 0.95));
        backdrop-filter: blur(10px);
        border-top: 1px solid rgba(31, 95, 191, 0.2);
        padding: 1rem 1.5rem;
        text-align: center;
        color: #ffffff;
        font-size: 0.85rem;
        letter-spacing: 0.3px;
        box-shadow: 0 -4px 12px rgba(17, 102, 156, 0.15);
        margin-top: auto;
    }

    .footer-content {
        max-width: 1200px;
        margin: 0 auto;
    }

    .footer-text {
        margin: 0;
        opacity: 0.95;
        line-height: 1.5;
    }

    .footer-highlight {
        font-weight: 700;
        color: #e8f2ff;
        letter-spacing: 0.5px;
    }

    .footer-company {
        font-weight: 600;
        color: #d6e8f8;
        letter-spacing: 0.3px;
    }

    @media (max-width: 768px) {
        .kiosk-footer {
            padding: 0.8rem 1rem;
            font-size: 0.8rem;
        }

        .footer-text {
            line-height: 1.4;
        }
    }
</style>
<?php /**PATH C:\xampp\htdocs\TSP-Restaurant-pointage\resources\views\partials\footer.blade.php ENDPATH**/ ?>