<?php $__env->startSection('title', 'Tableau de bord'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <h1>Systeme Restaurant Employes</h1>
    <p class="muted">Application Laravel avec modules employes, cartes, regles repas, logs et page kiosk de pointage.</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\TSP-Restaurant-pointage\resources\views\welcome.blade.php ENDPATH**/ ?>