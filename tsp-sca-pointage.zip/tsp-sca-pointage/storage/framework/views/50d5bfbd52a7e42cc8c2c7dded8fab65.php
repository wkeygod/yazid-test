<?php $__env->startSection('title', 'Extra'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $periodLabel = ($selectedDateFrom && $selectedDateTo)
            ? ($selectedDateFrom . ' au ' . $selectedDateTo)
            : 'Toutes les dates';

        $mealLabels = [
            'breakfast' => 'Petit-dejeuner',
            'lunch' => 'Dejeuner',
            'dinner' => 'Diner',
        ];
    ?>

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Extra','subtitle' => 'Historique et statistiques des entrees creees depuis le kiosque Extra']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Extra','subtitle' => 'Historique et statistiques des entrees creees depuis le kiosque Extra']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <style>
        .extra-filter-form {
            gap: .8rem;
        }

        .extra-filter-actions-wrap {
            grid-column: 1 / -1;
            margin-top: .15rem;
        }

        .extra-filter-actions {
            display: flex;
            gap: .5rem;
            flex-wrap: nowrap;
            align-items: center;
            width: 100%;
            min-width: 0;
        }

        .extra-filter-btn {
            min-height: 2.5rem !important;
            min-width: 0;
            flex: 1 1 0;
            padding: .58rem .84rem !important;
            font-size: .88rem !important;
            font-weight: 800 !important;
            letter-spacing: .12px;
            text-shadow: 0 1px 0 rgba(9, 34, 58, .35);
            white-space: nowrap;
        }

        .extra-filter-btn-reset {
            background: linear-gradient(180deg, #5d708a, #4d617d) !important;
        }

        .extra-filter-btn-csv {
            background: linear-gradient(180deg, #1f7a4f, #17613e) !important;
        }

        @media (max-width: 980px) {
            .extra-filter-actions {
                width: 100%;
            }

            .extra-filter-btn {
                font-size: .82rem !important;
                padding: .54rem .48rem !important;
                letter-spacing: .08px;
            }
        }
    </style>

    <div class="card" style="margin-bottom: 1rem;">
        <div class="panel-header">
            <h2>Filtres</h2>
        </div>

        <?php if (isset($component)) { $__componentOriginal3f97fad59f1d161af1828ef2108f500f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3f97fad59f1d161af1828ef2108f500f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.filter-bar','data' => ['action' => ''.e(route('extra.index')).'','class' => 'extra-filter-form']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.filter-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => ''.e(route('extra.index')).'','class' => 'extra-filter-form']); ?>
            <div>
                <label>Date debut</label>
                <input type="date" name="date_from" value="<?php echo e($selectedDateFrom); ?>">
            </div>

            <div>
                <label>Date fin</label>
                <input type="date" name="date_to" value="<?php echo e($selectedDateTo); ?>">
            </div>

            <div>
                <label>Recherche</label>
                <input id="extra-realtime-search" type="text" name="q" value="<?php echo e($search); ?>" placeholder="Nom, compagnie, rig, identifiant...">
            </div>

            <div>
                <label>Compagnie</label>
                <input type="text" name="company" value="<?php echo e($company); ?>" placeholder="Filtrer par compagnie">
            </div>

            <div>
                <label>Rig</label>
                <input type="text" name="rig" value="<?php echo e($rig); ?>" placeholder="Filtrer par rig">
            </div>

            <div class="extra-filter-actions-wrap">
                <div class="extra-filter-actions">
                    <button class="btn extra-filter-btn" type="submit">Appliquer</button>
                    <a class="btn extra-filter-btn extra-filter-btn-reset" href="<?php echo e(route('extra.index')); ?>">Reinitialiser</a>
                    <a class="btn extra-filter-btn extra-filter-btn-csv export-link" data-export-url="<?php echo e(route('extra.export', array_merge(request()->query(), ['format' => 'excel']))); ?>" href="#">Exporter Excel Pro</a>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3f97fad59f1d161af1828ef2108f500f)): ?>
<?php $attributes = $__attributesOriginal3f97fad59f1d161af1828ef2108f500f; ?>
<?php unset($__attributesOriginal3f97fad59f1d161af1828ef2108f500f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f97fad59f1d161af1828ef2108f500f)): ?>
<?php $component = $__componentOriginal3f97fad59f1d161af1828ef2108f500f; ?>
<?php unset($__componentOriginal3f97fad59f1d161af1828ef2108f500f); ?>
<?php endif; ?>
    </div>

    <div class="grid grid-2" style="margin-bottom:1rem;">
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Total entrees Extra','value' => number_format((int) $summary['total_entries'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Total entrees Extra','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) $summary['total_entries']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Avec repas','value' => number_format((int) $summary['with_meal']),'tone' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Avec repas','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) $summary['with_meal'])),'tone' => 'success']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Sans repas','value' => number_format((int) $summary['without_meal']),'tone' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Sans repas','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) $summary['without_meal'])),'tone' => 'danger']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Total repas consommes','value' => number_format((int) $summary['total_meals']),'tone' => 'info']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Total repas consommes','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) $summary['total_meals'])),'tone' => 'info']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Petit-dejeuner','value' => number_format((int) $summary['breakfast'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Petit-dejeuner','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) $summary['breakfast']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Dejeuner','value' => number_format((int) $summary['lunch'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Dejeuner','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) $summary['lunch']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Diner','value' => number_format((int) $summary['dinner'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Diner','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) $summary['dinner']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
    </div>

    <div class="card" style="margin-bottom: 1rem;">
        <div class="panel-header">
            <h2>Graphes statistiques universels</h2>
        </div>

        <style>
            .graph-shell {
                display: grid;
                gap: 1rem;
            }

            .graph-card {
                border: 1px solid #dbe8f8;
                border-radius: .9rem;
                padding: .9rem;
                background: linear-gradient(180deg, #fbfdff, #f5f9ff);
            }

            .graph-title {
                margin: 0;
                font-size: 1rem;
                font-weight: 800;
                color: #183e6d;
            }

            .graph-subtitle {
                margin: .18rem 0 .75rem;
                font-size: .82rem;
                color: #6b7f95;
            }

            .graph-row {
                display: grid;
                grid-template-columns: 120px 42px 42px minmax(0, 1fr);
                gap: .5rem;
                align-items: center;
                padding: .45rem 0;
                border-top: 1px solid #e3edf9;
            }

            .graph-row:first-child {
                border-top: 0;
            }

            .graph-label {
                font-size: .84rem;
                font-weight: 700;
                color: #23466d;
            }

            .graph-value {
                text-align: right;
                font-size: .82rem;
                color: #54708d;
                font-weight: 700;
            }

            .graph-track {
                height: 12px;
                border-radius: 999px;
                background: #e7eff9;
                overflow: hidden;
                display: flex;
                gap: 2px;
            }

            .graph-fill {
                height: 100%;
                border-radius: 999px;
            }

            .graph-fill-blue {
                background: linear-gradient(90deg, #1e5bb9, #5a8ff0);
            }

            .graph-fill-green {
                background: linear-gradient(90deg, #12845b, #3db37e);
            }

            .graph-fill-cyan {
                background: linear-gradient(90deg, #2f6fcf, #69a0ff);
            }

            .graph-legend {
                display: flex;
                flex-wrap: wrap;
                gap: .75rem;
                margin-bottom: .7rem;
                font-size: .78rem;
                color: #4d6480;
            }

            .graph-legend-item {
                display: inline-flex;
                align-items: center;
                gap: .35rem;
            }

            .graph-swatch {
                width: .7rem;
                height: .7rem;
                border-radius: 999px;
            }
        </style>

        <div class="graph-shell">
            <div class="graph-card">
                <h3 class="graph-title">Tendance journaliere</h3>
                <p class="graph-subtitle">Entrées et repas sur les 12 dernières dates du filtre courant.</p>
                <div class="graph-legend">
                    <span class="graph-legend-item"><span class="graph-swatch" style="background:#1e5bb9"></span>Entrées</span>
                    <span class="graph-legend-item"><span class="graph-swatch" style="background:#12845b"></span>Repas</span>
                </div>

                <?php $__empty_1 = true; $__currentLoopData = $dailyGraphRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="graph-row">
                        <div class="graph-label"><?php echo e($row['label']); ?></div>
                        <div class="graph-value"><?php echo e($row['entries']); ?></div>
                        <div class="graph-value"><?php echo e($row['meals']); ?></div>
                        <div class="graph-track" aria-label="Graphique journalier">
                            <div class="graph-fill graph-fill-blue" style="width: <?php echo $row['entry_pct']; ?>%;"></div>
                            <div class="graph-fill graph-fill-green" style="width: <?php echo $row['meal_pct']; ?>%; opacity:.55;"></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="muted">Aucune donnée pour tracer un graphe.</div>
                <?php endif; ?>
            </div>

            <div class="graph-card">
                <h3 class="graph-title">Répartition des repas</h3>
                <p class="graph-subtitle">Volume global par type de repas.</p>
                <div class="graph-legend">
                    <span class="graph-legend-item"><span class="graph-swatch" style="background:#2f6fcf"></span>Volume</span>
                </div>

                <?php $__currentLoopData = $mealGraphRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="graph-row">
                        <div class="graph-label"><?php echo e($item['label']); ?></div>
                        <div class="graph-value"><?php echo e($item['value']); ?></div>
                        <div class="graph-value"><?php echo e($item['pct']); ?>%</div>
                        <div class="graph-track">
                            <div class="graph-fill graph-fill-cyan" style="width: <?php echo $item['pct']; ?>%;"></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="panel-header">
            <h2 style="margin:0;">Historique Extra</h2>
            <span class="muted"><?php echo e($periodLabel); ?></span>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Heure creation</th>
                    <th>Nom</th>
                    <th>Compagnie</th>
                    <th>RiG</th>
                    <th>Repas jour (0/1)</th>
                    <th>Total repas</th>
                </tr>
            </thead>
            <tbody id="extra-history-body">
                <?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php ($entryDate = optional($entry->entry_date)->format('Y-m-d')); ?>
                    <?php ($rowSearch = mb_strtolower(trim(($entry->full_name ?? '') . ' ' . ($entry->rig_company ?? '') . ' ' . ($entry->position ?? '') . ' ' . ($entry->external_id ?? '')))); ?>
                    <?php ($flags = $entry->meal_flags ?? ['breakfast' => 0, 'lunch' => 0, 'dinner' => 0]); ?>
                    <tr data-extra-row="1" data-row-search="<?php echo e(e($rowSearch)); ?>">
                        <td><?php echo e($entryDate ?: '-'); ?></td>
                        <td><?php echo e(optional($entry->created_at)->format('H:i:s') ?: '-'); ?></td>
                        <td><?php echo e($entry->full_name); ?></td>
                        <td><?php echo e($entry->rig_company ?: '-'); ?></td>
                        <td><?php echo e($entry->position ?: '-'); ?></td>
                        <td>
                            <?php echo e($mealLabels['breakfast']); ?>=<?php echo e($flags['breakfast']); ?>,
                            <?php echo e($mealLabels['lunch']); ?>=<?php echo e($flags['lunch']); ?>,
                            <?php echo e($mealLabels['dinner']); ?>=<?php echo e($flags['dinner']); ?>

                        </td>
                        <td><?php echo e($entry->consumed_meals_count); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                            <td colspan="7">Aucune entree Extra pour ces filtres.</td>
                    </tr>
                <?php endif; ?>
                    <tr id="extra-no-results-row" hidden>
                        <td colspan="7">Aucun resultat pour cette recherche.</td>
                    </tr>
            </tbody>
        </table>

        <div style="margin-top: .8rem;"><?php echo e($entries->links()); ?></div>
    </div>

    <div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,1fr); margin-top:1rem;">
        <div class="card">
            <div class="panel-header">
                <h3 style="margin:0;">Top compagnies (Extra)</h3>
                <span class="muted">Top 10</span>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>Compagnie</th>
                        <th>Entrees</th>
                        <th>Avec repas</th>
                        <th>Total repas</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $topCompanies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($row['label']); ?></td>
                            <td><?php echo e($row['entries']); ?></td>
                            <td><?php echo e($row['with_meal']); ?></td>
                            <td><?php echo e($row['total_meals']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4">Aucune donnee.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="card">
            <div class="panel-header">
                <h3 style="margin:0;">Top rigs (Extra)</h3>
                <span class="muted">Top 10</span>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>Rig</th>
                        <th>Entrees</th>
                        <th>Avec repas</th>
                        <th>Total repas</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $topRigs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($row['label']); ?></td>
                            <td><?php echo e($row['entries']); ?></td>
                            <td><?php echo e($row['with_meal']); ?></td>
                            <td><?php echo e($row['total_meals']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4">Aucune donnee.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        (function () {
            var searchInput = document.getElementById('extra-realtime-search');
            var tableBody = document.getElementById('extra-history-body');
            var noResultsRow = document.getElementById('extra-no-results-row');

            if (!searchInput || !tableBody) {
                return;
            }

            var rows = Array.prototype.slice.call(tableBody.querySelectorAll('tr[data-extra-row="1"]'));

            function normalize(value) {
                return (value || '')
                    .toString()
                    .toLowerCase()
                    .normalize('NFD')
                    .replace(/[\u0300-\u036f]/g, '')
                    .trim();
            }

            function applyFilter() {
                var term = normalize(searchInput.value);
                var visibleCount = 0;

                rows.forEach(function (row) {
                    var haystack = normalize(row.getAttribute('data-row-search'));
                    var isVisible = term === '' || haystack.indexOf(term) !== -1;
                    row.hidden = !isVisible;
                    if (isVisible) {
                        visibleCount += 1;
                    }
                });

                if (noResultsRow) {
                    noResultsRow.hidden = visibleCount !== 0;
                }
            }

            searchInput.addEventListener('input', applyFilter);
            applyFilter();
        })();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/madi/TSP-Restaurant-pointage/resources/views/extra/index.blade.php ENDPATH**/ ?>