<?php $__env->startSection('title', 'Reports'); ?>

<?php $__env->startSection('topbar_actions'); ?>
    <a class="btn" style="background:#5d708a;" href="<?php echo e(route('reports.index')); ?>">Réinitialiser</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $dateFrom = $filters['date_from'] ?? '';
        $dateTo = $filters['date_to'] ?? '';
        $departmentFilter = (int) ($filters['department_id'] ?? 0);
        $resultTypeFilter = $filters['result_type'] ?? '';
        $sourceFilter = $filters['source'] ?? 'all';
        $budgetPerDay = (float) ($filters['budget_per_day'] ?? 0);

        $dailyMax = (int) ($dailyReport->max('total') ?? 0);
        $weeklyMax = (int) ($weeklyReport->max('total') ?? 0);
        $monthlyMax = (int) ($monthlyReport->max('total') ?? 0);
        $denialMax = (int) ($denialReasons->max('count') ?? 0);

        $cmpTotal = $comparison['total'] ?? ['delta' => 0, 'pct' => null];
        $cmpAmount = $comparison['amount'] ?? ['delta' => 0, 'pct' => null];
        $cmpRejected = $comparison['rejected'] ?? ['delta' => 0, 'pct' => null];

        $trendClass = static function (float|int $delta): string {
            if ($delta > 0) {
                return 'trend-up';
            }
            if ($delta < 0) {
                return 'trend-down';
            }

            return 'trend-neutral';
        };

        $trendText = static function (float|int|null $pct): string {
            if ($pct === null) {
                return 'N/A';
            }

            $sign = $pct > 0 ? '+' : '';

            return $sign . number_format((float) $pct, 1) . '%';
        };
    ?>

    <style>
        .report-grid {
            display: grid;
            gap: 1rem;
        }

        .report-alerts {
            display: grid;
            gap: .6rem;
        }

        .report-alert {
            border-radius: 12px;
            padding: .72rem .85rem;
            border: 1px solid transparent;
            box-shadow: 0 8px 20px rgba(14, 37, 64, 0.08);
        }

        .report-alert strong {
            display: block;
            margin-bottom: .12rem;
        }

        .report-alert-success { background: #e6f8ee; border-color: #bae7cc; color: #145b33; }
        .report-alert-info { background: #e9f2ff; border-color: #cddfff; color: #1d4f90; }
        .report-alert-warning { background: #fff3de; border-color: #f4d39d; color: #7a5210; }
        .report-alert-danger { background: #feeaea; border-color: #f5c0c0; color: #842626; }

        .compare-grid {
            display: grid;
            gap: .75rem;
            grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
        }

        .compare-card {
            border: 1px solid #d8e4f3;
            border-radius: 12px;
            background: linear-gradient(180deg, #ffffff, #f8fbff);
            padding: .72rem .8rem;
        }

        .compare-label {
            color: #5b7696;
            font-size: .76rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: .55px;
        }

        .compare-value {
            margin-top: .2rem;
            font-weight: 800;
            font-size: 1.02rem;
            color: #1a3f6d;
        }

        .compare-trend {
            margin-top: .2rem;
            font-weight: 700;
            font-size: .82rem;
        }

        .trend-up { color: #145b33; }
        .trend-down { color: #8f2b2b; }
        .trend-neutral { color: #5d738f; }

        .bar-track {
            width: 100%;
            height: 10px;
            border-radius: 999px;
            background: #e9f0fa;
            overflow: hidden;
        }

        .bar-fill {
            height: 100%;
            border-radius: 999px;
            background: linear-gradient(90deg, #1e5bb9, #4b86de);
        }

        .forecast-card {
            border: 1px solid #d8e4f3;
            border-radius: 12px;
            background: linear-gradient(180deg, #ffffff, #f8fbff);
            padding: .8rem;
        }

        .forecast-value {
            font-size: 1.15rem;
            font-weight: 800;
            color: #19406e;
            margin-top: .15rem;
        }
    </style>

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Rapports opérationnels','subtitle' => 'Centre de décision: alertes, comparaison, budget, prévision et export']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Rapports opérationnels','subtitle' => 'Centre de décision: alertes, comparaison, budget, prévision et export']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <div class="report-grid">
        <div class="card">
            <div class="panel-header">
                <h2>Filtres avancés</h2>
            </div>

            <?php if (isset($component)) { $__componentOriginal3f97fad59f1d161af1828ef2108f500f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3f97fad59f1d161af1828ef2108f500f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.filter-bar','data' => ['action' => ''.e(route('reports.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.filter-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => ''.e(route('reports.index')).'']); ?>
                <div>
                    <label>Date début</label>
                    <input type="date" name="date_from" value="<?php echo e($dateFrom); ?>">
                </div>

                <div>
                    <label>Date fin</label>
                    <input type="date" name="date_to" value="<?php echo e($dateTo); ?>">
                </div>

                <div>
                    <label>Source</label>
                    <select name="source">
                        <option value="all" <?php echo e($sourceFilter === 'all' ? 'selected' : ''); ?>>Tout</option>
                        <option value="employee" <?php echo e($sourceFilter === 'employee' ? 'selected' : ''); ?>>Employés NFC</option>
                        <option value="la_releve" <?php echo e($sourceFilter === 'la_releve' ? 'selected' : ''); ?>>La Relève</option>
                        <option value="extra" <?php echo e($sourceFilter === 'extra' ? 'selected' : ''); ?>>Extra</option>
                    </select>
                </div>

                <div>
                    <label>Département</label>
                    <select name="department_id">
                        <option value="">Tous</option>
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($department->id); ?>" <?php echo e($departmentFilter === (int) $department->id ? 'selected' : ''); ?>><?php echo e($department->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div>
                    <label>Type résultat</label>
                    <select name="result_type">
                        <option value="">Tous</option>
                        <option value="approved" <?php echo e($resultTypeFilter === 'approved' ? 'selected' : ''); ?>>Autorisé</option>
                        <option value="rejected" <?php echo e($resultTypeFilter === 'rejected' ? 'selected' : ''); ?>>Refusé</option>
                    </select>
                </div>

                <div>
                    <label>Budget / jour</label>
                    <input type="number" step="0.01" min="0" name="budget_per_day" value="<?php echo e(number_format($budgetPerDay, 2, '.', '')); ?>" placeholder="0.00">
                </div>

                <div style="display:flex; gap:.45rem; flex-wrap:wrap;">
                    <button class="btn" type="submit">Appliquer</button>
                    <a class="btn export-link" style="background:#1f7a4f;" data-export-url="<?php echo e(route('reports.export', array_merge(request()->query(), ['format' => 'excel']))); ?>" href="#">Exporter Excel Pro</a>
                    <a class="btn export-link" style="background:#3f6bb5;" data-export-url="<?php echo e(route('reports.export', array_merge(request()->query(), ['format' => 'json']))); ?>" href="#">Exporter JSON</a>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3f97fad59f1d161af1828ef2108f500f)): ?>
<?php $attributes = $__attributesOriginal3f97fad59f1d161af1828ef2108f500f; ?>
<?php unset($__attributesOriginal3f97fad59f1d161af1828ef2108f500f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f97fad59f1d161af1828ef2108f500f)): ?>
<?php $component = $__componentOriginal3f97fad59f1d161af1828ef2108f500f; ?>
<?php unset($__componentOriginal3f97fad59f1d161af1828ef2108f500f); ?>
<?php endif; ?>
        </div>

        <div class="report-alerts">
            <?php $__currentLoopData = $alerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="report-alert report-alert-<?php echo e($alert['level'] ?? 'info'); ?>">
                    <strong><?php echo e($alert['title'] ?? 'Information'); ?></strong>
                    <span><?php echo e($alert['message'] ?? ''); ?></span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="grid grid-2" style="margin-bottom: .2rem;">
            <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Total logs','value' => number_format((int) $kpi['total_logs'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Total logs','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) $kpi['total_logs']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Autorisés','value' => number_format((int) $kpi['approved_logs']),'tone' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Autorisés','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) $kpi['approved_logs'])),'tone' => 'success']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Refusés','value' => number_format((int) $kpi['rejected_logs']),'tone' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Refusés','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) $kpi['rejected_logs'])),'tone' => 'danger']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Taux d\'approbation','value' => number_format((float) $kpi['approval_rate'], 1) . '%','tone' => 'info']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Taux d\'approbation','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((float) $kpi['approval_rate'], 1) . '%'),'tone' => 'info']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Montant total','value' => number_format((float) $kpi['total_amount'], 2),'tone' => 'info']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Montant total','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((float) $kpi['total_amount'], 2)),'tone' => 'info']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Budget total','value' => number_format((float) $kpi['budget_total'], 2),'tone' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Budget total','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((float) $kpi['budget_total'], 2)),'tone' => 'primary']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Écart budget','value' => number_format((float) $kpi['budget_gap'], 2),'tone' => (float) $kpi['budget_gap'] < 0 ? 'danger' : 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Écart budget','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((float) $kpi['budget_gap'], 2)),'tone' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute((float) $kpi['budget_gap'] < 0 ? 'danger' : 'success')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Logs Employés','value' => number_format((int) $kpi['employee_logs']),'tone' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Logs Employés','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) $kpi['employee_logs'])),'tone' => 'primary']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Logs La Relève','value' => number_format((int) $kpi['la_releve_logs']),'tone' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Logs La Relève','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) $kpi['la_releve_logs'])),'tone' => 'primary']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Logs Extra','value' => number_format((int) $kpi['extra_logs']),'tone' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Logs Extra','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format((int) $kpi['extra_logs'])),'tone' => 'primary']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        </div>

        <div class="card">
            <div class="panel-header">
                <h2>Comparaison vs période précédente</h2>
                <span class="muted">Période de référence: <?php echo e($comparison['previous_period_label'] ?? '-'); ?></span>
            </div>

            <div class="compare-grid">
                <div class="compare-card">
                    <div class="compare-label">Volume total</div>
                    <div class="compare-value"><?php echo e(number_format((int) ($cmpTotal['current'] ?? 0))); ?></div>
                    <div class="compare-trend <?php echo e($trendClass($cmpTotal['delta'] ?? 0)); ?>">
                        Δ <?php echo e(number_format((float) ($cmpTotal['delta'] ?? 0), 0)); ?> • <?php echo e($trendText($cmpTotal['pct'] ?? null)); ?>

                    </div>
                </div>

                <div class="compare-card">
                    <div class="compare-label">Montant total</div>
                    <div class="compare-value"><?php echo e(number_format((float) ($cmpAmount['current'] ?? 0), 2)); ?></div>
                    <div class="compare-trend <?php echo e($trendClass($cmpAmount['delta'] ?? 0)); ?>">
                        Δ <?php echo e(number_format((float) ($cmpAmount['delta'] ?? 0), 2)); ?> • <?php echo e($trendText($cmpAmount['pct'] ?? null)); ?>

                    </div>
                </div>

                <div class="compare-card">
                    <div class="compare-label">Refus</div>
                    <div class="compare-value"><?php echo e(number_format((int) ($cmpRejected['current'] ?? 0))); ?></div>
                    <div class="compare-trend <?php echo e($trendClass(($cmpRejected['delta'] ?? 0) * -1)); ?>">
                        Δ <?php echo e(number_format((float) ($cmpRejected['delta'] ?? 0), 0)); ?> • <?php echo e($trendText($cmpRejected['pct'] ?? null)); ?>

                    </div>
                </div>

                <div class="forecast-card">
                    <div class="compare-label">Prévision (J+1)</div>
                    <div class="forecast-value"><?php echo e(number_format((int) ($forecast['next_day_total_estimate'] ?? 0))); ?> logs</div>
                    <div class="muted" style="font-size:.82rem; margin-top:.2rem;">Montant estimé: <?php echo e(number_format((float) ($forecast['next_day_amount_estimate'] ?? 0), 2)); ?></div>
                    <div class="muted" style="font-size:.78rem; margin-top:.2rem;">Basé sur <?php echo e($forecast['reference_days'] ?? 0); ?> jours récents</div>
                </div>
            </div>
        </div>

        <div class="grid" style="grid-template-columns:minmax(0, 1fr) minmax(0, 1fr);">
            <div class="card">
                <div class="panel-header">
                    <h3 style="margin:0;">Rapport journalier</h3>
                    <span class="muted"><?php echo e($dailyReport->count()); ?> périodes</span>
                </div>

                <?php if($dailyReport->isEmpty()): ?>
                    <p class="muted">Aucune donnée.</p>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Jour</th>
                                <th>Total</th>
                                <th>Autorisé</th>
                                <th>Refusé</th>
                                <th>Montant</th>
                                <th>Tendance</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $dailyReport->take(14); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php ($width = $dailyMax > 0 ? (int) round(($row['total'] / $dailyMax) * 100) : 0); ?>
                                <tr>
                                    <td><?php echo e($row['bucket']); ?></td>
                                    <td><?php echo e($row['total']); ?></td>
                                    <td><?php echo e($row['approved']); ?></td>
                                    <td><?php echo e($row['rejected']); ?></td>
                                    <td><?php echo e(number_format((float) $row['amount'], 2)); ?></td>
                                    <td><span style="font-family:monospace; color:#1e5bb9; letter-spacing:1px;"><?php echo e(str_repeat('█', max(1, (int) floor($width / 6)))); ?></span></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <div class="card">
                <div class="panel-header">
                    <h3 style="margin:0;">Rapport hebdomadaire</h3>
                    <span class="muted"><?php echo e($weeklyReport->count()); ?> périodes</span>
                </div>

                <?php if($weeklyReport->isEmpty()): ?>
                    <p class="muted">Aucune donnée.</p>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Semaine</th>
                                <th>Total</th>
                                <th>Autorisé</th>
                                <th>Refusé</th>
                                <th>Montant</th>
                                <th>Tendance</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $weeklyReport->take(12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php ($width = $weeklyMax > 0 ? (int) round(($row['total'] / $weeklyMax) * 100) : 0); ?>
                                <tr>
                                    <td><?php echo e($row['bucket']); ?></td>
                                    <td><?php echo e($row['total']); ?></td>
                                    <td><?php echo e($row['approved']); ?></td>
                                    <td><?php echo e($row['rejected']); ?></td>
                                    <td><?php echo e(number_format((float) $row['amount'], 2)); ?></td>
                                    <td><span style="font-family:monospace; color:#1e5bb9; letter-spacing:1px;"><?php echo e(str_repeat('█', max(1, (int) floor($width / 6)))); ?></span></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="panel-header">
                <h3 style="margin:0;">Rapport mensuel</h3>
                <span class="muted"><?php echo e($monthlyReport->count()); ?> périodes</span>
            </div>

            <?php if($monthlyReport->isEmpty()): ?>
                <p class="muted">Aucune donnée.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Mois</th>
                            <th>Total</th>
                            <th>Autorisé</th>
                            <th>Refusé</th>
                            <th>Montant</th>
                            <th>Tendance</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $monthlyReport->take(12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php ($width = $monthlyMax > 0 ? (int) round(($row['total'] / $monthlyMax) * 100) : 0); ?>
                            <tr>
                                <td><?php echo e($row['bucket']); ?></td>
                                <td><?php echo e($row['total']); ?></td>
                                <td><?php echo e($row['approved']); ?></td>
                                <td><?php echo e($row['rejected']); ?></td>
                                <td><?php echo e(number_format((float) $row['amount'], 2)); ?></td>
                                <td><span style="font-family:monospace; color:#1e5bb9; letter-spacing:1px;"><?php echo e(str_repeat('█', max(1, (int) floor($width / 6)))); ?></span></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <div class="grid" style="grid-template-columns:minmax(0, 1fr) minmax(0, 1fr);">
            <div class="card">
                <div class="panel-header">
                    <h3 style="margin:0;">Scorecards département</h3>
                    <span class="muted"><?php echo e($departmentSummary->count()); ?> lignes</span>
                </div>

                <?php if($departmentSummary->isEmpty()): ?>
                    <p class="muted">Aucune donnée.</p>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Département</th>
                                <th>Total</th>
                                <th>Autorisé</th>
                                <th>Refusé</th>
                                <th>Taux</th>
                                <th>Montant</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $departmentSummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($row['label']); ?></td>
                                    <td><?php echo e($row['total']); ?></td>
                                    <td><?php echo e($row['approved']); ?></td>
                                    <td><?php echo e($row['rejected']); ?></td>
                                    <td><?php echo e(number_format((float) $row['approval_rate'], 1)); ?>%</td>
                                    <td><?php echo e(number_format((float) $row['amount'], 2)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <div class="card">
                <div class="panel-header">
                    <h3 style="margin:0;">Motifs de refus</h3>
                    <span class="muted"><?php echo e($denialReasons->count()); ?> motifs</span>
                </div>

                <?php if($denialReasons->isEmpty()): ?>
                    <p class="muted">Aucun refus enregistré.</p>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Motif</th>
                                <th>Occurrences</th>
                                <th>Poids</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $denialReasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php ($width = $denialMax > 0 ? (int) round(($row['count'] / $denialMax) * 100) : 0); ?>
                                <tr>
                                    <td><?php echo e($row['reason']); ?></td>
                                    <td><?php echo e($row['count']); ?></td>
                                    <td><span style="font-family:monospace; color:#c53030; letter-spacing:1px;"><?php echo e(str_repeat('█', max(1, (int) floor($width / 6)))); ?></span></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="panel-header">
                <h3 style="margin:0;">Derniers logs inclus dans le rapport</h3>
                <span class="muted"><?php echo e($latestLogs->count()); ?> lignes</span>
            </div>

            <?php if($latestLogs->isEmpty()): ?>
                <p class="muted">Aucun log.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Date/Heure</th>
                            <th>Source</th>
                            <th>Résultat</th>
                            <th>Département</th>
                            <th>Plat</th>
                            <th>Montant</th>
                            <th>Motif</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $latestLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(\Carbon\Carbon::parse($log['at'])->format('Y-m-d H:i:s')); ?></td>
                                <td><?php echo e(strtoupper($log['source'])); ?></td>
                                <td>
                                    <?php if (isset($component)) { $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.badge','data' => ['tone' => $log['status'] === 'approved' ? 'approved' : 'rejected']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($log['status'] === 'approved' ? 'approved' : 'rejected')]); ?>
                                        <?php echo e($log['status'] === 'approved' ? 'AUTORISE' : 'REFUSE'); ?>

                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $attributes = $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $component = $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
                                </td>
                                <td><?php echo e($log['department'] ?: '-'); ?></td>
                                <td><?php echo e($log['meal'] ?: '-'); ?></td>
                                <td><?php echo e(number_format((float) $log['amount'], 2)); ?></td>
                                <td><?php echo e($log['reason'] ?: '-'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\TSP-Restaurant-pointage\resources\views/reports/index.blade.php ENDPATH**/ ?>