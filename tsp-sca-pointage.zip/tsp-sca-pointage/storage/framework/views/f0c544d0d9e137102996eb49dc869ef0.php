<div id="admin-confirm-modal" class="confirm-modal" hidden>
    <div class="confirm-modal-backdrop" data-confirm-close></div>

    <div
        class="confirm-modal-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="admin-confirm-modal-title"
        aria-describedby="admin-confirm-modal-message"
        tabindex="-1"
    >
        <h2 id="admin-confirm-modal-title" class="confirm-modal-title">Confirmation</h2>
        <p id="admin-confirm-modal-message" class="confirm-modal-message">Veuillez confirmer cette action.</p>

        <div class="confirm-modal-actions">
            <button type="button" class="btn btn-secondary" data-confirm-cancel>Annuler</button>
            <button type="button" class="btn" data-confirm-approve>Confirmer</button>
        </div>
    </div>
</div>
<?php /**PATH /var/www/html/resources/views/components/admin/confirm-modal.blade.php ENDPATH**/ ?>