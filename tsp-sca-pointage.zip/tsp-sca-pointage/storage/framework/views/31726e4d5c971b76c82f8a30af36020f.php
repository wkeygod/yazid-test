<?php $__env->startSection('title', 'Historique Employes'); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        .employee-history-export-csv {
            background: linear-gradient(180deg, #1f7a4f, #17613e) !important;
            color: #fff !important;
        }

        .field-hidden {
            display: none !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $historyAuthUser = auth()->user();
        $historyAccessiblePages = $historyAuthUser ? $historyAuthUser->getAccessiblePages() : [];
        $canEditEmployeesFromHistory = $historyAuthUser && ($historyAuthUser->is_admin || in_array('employees.index', $historyAccessiblePages, true));
    ?>

    <?php if (isset($component)) { $__componentOriginalc54d3df993b2b7217886cf18c9828547 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc54d3df993b2b7217886cf18c9828547 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.panel','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.panel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Historique Employes','subtitle' => 'Suivi des repas consommés par les employés.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Historique Employes','subtitle' => 'Suivi des repas consommés par les employés.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

        <div class="grid grid-2" style="margin-bottom:.9rem;">
            <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Total logs','value' => $summary['total'],'tone' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Total logs','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($summary['total']),'tone' => 'primary']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Autorises','value' => $summary['authorized'],'tone' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Autorises','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($summary['authorized']),'tone' => 'success']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Refuses','value' => $summary['denied'],'tone' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Refuses','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($summary['denied']),'tone' => 'danger']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Employes uniques','value' => $summary['employees'],'tone' => 'info']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Employes uniques','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($summary['employees']),'tone' => 'info']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Petit-dejeuner','value' => $summary['breakfast'],'tone' => 'warning']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Petit-dejeuner','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($summary['breakfast']),'tone' => 'warning']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Dejeuner','value' => $summary['lunch'],'tone' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Dejeuner','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($summary['lunch']),'tone' => 'primary']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.kpi-card','data' => ['label' => 'Diner','value' => $summary['dinner'],'tone' => 'info']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.kpi-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Diner','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($summary['dinner']),'tone' => 'info']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $attributes = $__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__attributesOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3)): ?>
<?php $component = $__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3; ?>
<?php unset($__componentOriginal70a6fcfaf7f2326c7059ce9dfede57e3); ?>
<?php endif; ?>
        </div>

        <?php if (isset($component)) { $__componentOriginal3f97fad59f1d161af1828ef2108f500f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3f97fad59f1d161af1828ef2108f500f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.filter-bar','data' => ['action' => ''.e(route('employee-history.index')).'','style' => 'margin-bottom:.9rem;']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.filter-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => ''.e(route('employee-history.index')).'','style' => 'margin-bottom:.9rem;']); ?>
            <div>
                <label>Mode de date</label>
                <select name="filter_mode" id="employee_history_filter_mode">
                    <option value="day" <?php echo e($filterMode === 'day' ? 'selected' : ''); ?>>Date unique</option>
                    <option value="range" <?php echo e($filterMode === 'range' ? 'selected' : ''); ?>>Intervalle</option>
                </select>
            </div>
            <div id="employee_history_day_wrap">
                <label>Date (jour)</label>
                <input type="date" id="employee_history_date" name="date" value="<?php echo e($selectedDate); ?>">
            </div>
            <div id="employee_history_from_wrap">
                <label>Date debut</label>
                <input type="date" id="employee_history_date_from" name="date_from" value="<?php echo e($selectedDateFrom); ?>">
            </div>
            <div id="employee_history_to_wrap">
                <label>Date fin</label>
                <input type="date" id="employee_history_date_to" name="date_to" value="<?php echo e($selectedDateTo); ?>">
            </div>
            <div>
                <label>Recherche</label>
                <input id="employee_history_realtime_search" type="text" name="q" value="<?php echo e($search); ?>" placeholder="Nom, matricule, poste, entreprise, type repas..." autocomplete="off">
            </div>
            <div class="actions" style="align-self: end;">
                <button class="btn" type="submit">Filtrer</button>
                <a class="btn btn-secondary" href="<?php echo e(route('employee-history.index')); ?>">Reinitialiser</a>
                <a class="btn employee-history-export-csv export-link" data-export-url="<?php echo e(route('employee-history.export', array_merge(request()->query(), ['format' => 'excel']))); ?>" href="#">Exporter Excel Pro</a>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3f97fad59f1d161af1828ef2108f500f)): ?>
<?php $attributes = $__attributesOriginal3f97fad59f1d161af1828ef2108f500f; ?>
<?php unset($__attributesOriginal3f97fad59f1d161af1828ef2108f500f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f97fad59f1d161af1828ef2108f500f)): ?>
<?php $component = $__componentOriginal3f97fad59f1d161af1828ef2108f500f; ?>
<?php unset($__componentOriginal3f97fad59f1d161af1828ef2108f500f); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.data-table','data' => ['class' => 'table-sticky table-compact']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'table-sticky table-compact']); ?>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Heure</th>
                    <th>Matricule</th>
                    <th>Nom complet</th>
                    <th>Poste</th>
                    <th>Entreprise</th>
                    <th>Type repas</th>
                    <th>Statut</th>
                    <th>Motif refus</th>
                    <th class="actions-col">Actions</th>
                </tr>
            </thead>
            <tbody id="employee_history_table_body">
            <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $statusLabel = $log->status === 'approved' ? 'Autorise' : 'Refuse';
                    $statusClass = $log->status === 'approved' ? 'status-approved' : 'status-rejected';
                    $employee = $log->employee;
                    $searchIndex = strtolower(trim(implode(' ', array_filter([
                        $log->logged_at?->format('Y-m-d'),
                        $log->logged_at?->format('H:i:s'),
                        $employee?->employee_no,
                        trim(($employee?->first_name ?? '') . ' ' . ($employee?->last_name ?? '')),
                        $employee?->position,
                        $employee?->rig_company,
                        $log->meal_type_label,
                        $statusLabel,
                        $log->reason,
                    ]))));
                ?>
                <tr data-history-row data-search="<?php echo e($searchIndex); ?>">
                    <td><?php echo e($log->logged_at?->format('Y-m-d') ?: '-'); ?></td>
                    <td><?php echo e($log->logged_at?->format('H:i:s') ?: '-'); ?></td>
                    <td><?php echo e($employee?->employee_no ?: '-'); ?></td>
                    <td><?php echo e(trim(($employee?->first_name ?? '') . ' ' . ($employee?->last_name ?? '')) ?: '-'); ?></td>
                    <td><?php echo e($employee?->position ?: '-'); ?></td>
                    <td><?php echo e($employee?->rig_company ?: '-'); ?></td>
                    <td><?php echo e($log->meal_type_label ?: '-'); ?></td>
                    <td><span class="status-badge <?php echo e($statusClass); ?>"><?php echo e($statusLabel); ?></span></td>
                    <td><?php echo e($log->status === 'rejected' ? ($log->reason ?: '-') : '-'); ?></td>
                    <td>
                        <?php if($canEditEmployeesFromHistory && $employee): ?>
                            <?php if (isset($component)) { $__componentOriginal2cf8d150d764feb90655ba7ed73d9171 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2cf8d150d764feb90655ba7ed73d9171 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.table-actions','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.table-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                <a class="btn-action btn-action-info" href="<?php echo e(route('employees.edit', $employee)); ?>">Modifier</a>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2cf8d150d764feb90655ba7ed73d9171)): ?>
<?php $attributes = $__attributesOriginal2cf8d150d764feb90655ba7ed73d9171; ?>
<?php unset($__attributesOriginal2cf8d150d764feb90655ba7ed73d9171); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2cf8d150d764feb90655ba7ed73d9171)): ?>
<?php $component = $__componentOriginal2cf8d150d764feb90655ba7ed73d9171; ?>
<?php unset($__componentOriginal2cf8d150d764feb90655ba7ed73d9171); ?>
<?php endif; ?>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="10">
                        <?php if (isset($component)) { $__componentOriginal99089f8e2ef4184d7d35db81d60c6521 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.empty-state','data' => ['title' => 'Aucun historique employe','message' => 'Aucune consommation trouvée pour les filtres sélectionnés.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Aucun historique employe','message' => 'Aucune consommation trouvée pour les filtres sélectionnés.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $attributes = $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $component = $__componentOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0)): ?>
<?php $attributes = $__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0; ?>
<?php unset($__attributesOriginal8a75a2be9d4747e9fac92a4568c3c2d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0)): ?>
<?php $component = $__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0; ?>
<?php unset($__componentOriginal8a75a2be9d4747e9fac92a4568c3c2d0); ?>
<?php endif; ?>

        <div id="employee_history_no_results" class="card" style="padding:.8rem; margin-bottom:.75rem; display:none;">
            Aucun résultat trouvé pour la recherche en temps réel.
        </div>

        <div class="pager"><?php echo e($logs->links()); ?></div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc54d3df993b2b7217886cf18c9828547)): ?>
<?php $attributes = $__attributesOriginalc54d3df993b2b7217886cf18c9828547; ?>
<?php unset($__attributesOriginalc54d3df993b2b7217886cf18c9828547); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc54d3df993b2b7217886cf18c9828547)): ?>
<?php $component = $__componentOriginalc54d3df993b2b7217886cf18c9828547; ?>
<?php unset($__componentOriginalc54d3df993b2b7217886cf18c9828547); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        (function () {
            var modeEl = document.getElementById('employee_history_filter_mode');
            var dayWrap = document.getElementById('employee_history_day_wrap');
            var fromWrap = document.getElementById('employee_history_from_wrap');
            var toWrap = document.getElementById('employee_history_to_wrap');

            function syncFilterFields() {
                if (!modeEl || !dayWrap || !fromWrap || !toWrap) {
                    return;
                }

                var mode = modeEl.value || 'range';
                var isRange = mode === 'range';

                dayWrap.classList.toggle('field-hidden', isRange);
                fromWrap.classList.toggle('field-hidden', !isRange);
                toWrap.classList.toggle('field-hidden', !isRange);
            }

            if (modeEl) {
                modeEl.addEventListener('change', syncFilterFields);
            }
            syncFilterFields();

            var realtimeInput = document.getElementById('employee_history_realtime_search');
            var noResultsBox = document.getElementById('employee_history_no_results');

            function normalize(value) {
                return (value || '')
                    .toString()
                    .normalize('NFD')
                    .replace(/[\u0300-\u036f]/g, '')
                    .toLowerCase()
                    .trim();
            }

            function applyRealtimeFilter() {
                var rows = document.querySelectorAll('[data-history-row]');
                if (!rows.length) {
                    return;
                }

                var term = normalize(realtimeInput ? realtimeInput.value : '');
                var visibleCount = 0;

                rows.forEach(function (row) {
                    var haystack = normalize(row.getAttribute('data-search'));
                    var visible = term === '' || haystack.indexOf(term) !== -1;
                    row.style.display = visible ? '' : 'none';
                    if (visible) {
                        visibleCount += 1;
                    }
                });

                if (noResultsBox) {
                    noResultsBox.style.display = visibleCount === 0 ? '' : 'none';
                }
            }

            if (realtimeInput) {
                realtimeInput.addEventListener('input', applyRealtimeFilter);
                applyRealtimeFilter();
            }
        })();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/employee-history/index.blade.php ENDPATH**/ ?>