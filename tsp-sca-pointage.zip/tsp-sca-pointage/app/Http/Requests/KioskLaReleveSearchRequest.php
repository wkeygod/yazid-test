<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class KioskLaReleveSearchRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'search_term' => ['required', 'string', 'max:160'],
            'selected_date' => ['nullable', 'date'],
        ];
    }
}
