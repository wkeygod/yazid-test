# Système de Gestion des Rôles et Permissions - Documentation technique

## Vue d'ensemble

Ce document décrit l'architecture technique complète du système de gestion des rôles et permissions implémenté pour TSP Restaurant Pointage.

## Structure des fichiers créés

```
app/
├── Models/
│   ├── Role.php                          # Modèle Role avec relations
│   ├── Permission.php                    # Modèle Permission
│   └── User.php                          # Modèle User modifié (nouvelles relations)
├── Http/
│   ├── Controllers/
│   │   └── RoleController.php            # Contrôleur de gestion des rôles
│   └── Middleware/
│       └── CheckPagePermission.php       # Middleware de vérification des permissions
├── Traits/
│   └── ChecksPagePermission.php          # Trait utilitaire (optionnel)
└── Providers/                             # (Pas modifiés)

database/
├── migrations/
│   ├── 2026_04_17_183139_create_roles_permissions_tables.php
│   ├── 2026_04_17_183151_add_first_name_to_users_table.php
└── seeders/
    ├── PermissionSeeder.php              # Seeder des permissions
    └── TestUserSeeder.php                # Seeder des utilisateurs de test

resources/
└── views/
    └── roles/
        └── index.blade.php               # Vue de gestion des rôles (UX complète)

bootstrap/
└── app.php                               # Configuration des middlewares

routes/
└── web.php                               # Routes modifiées avec middlewares
```

## Flux d'authentification

```
┌─────────────┐
│ Utilisateur │
└──────┬──────┘
       │ Connexion (email, password)
       ▼
┌──────────────────────┐
│ AdminAuthController  │
│ - login()            │
└──────────┬───────────┘
           │
           ├─ Vérifier les credentials
           │
           ├─ Si échoué → Rediriger avec erreur
           │
           ├─ Si admin → Rediriger vers dashboard
           │
           ├─ Si non-admin sans permissions → Logout + Erreur
           │
           ├─ Si non-admin avec 1 page → Rediriger vers cette page
           │
           └─ Si non-admin avec N pages → Rediriger vers dashboard
```

## Architecture des modèles

### Modèle User
```php
User
├── is_admin : boolean
├── first_name : string
├── last_name : string
├── roles() : belongsToMany(Role)
├── permissions() : belongsToMany(Permission, through=Role)
├── hasPermission(pageSlug) : bool
└── getAccessiblePages() : array
```

### Modèle Role
```php
Role
├── name : string (unique)
├── description : string
├── permissions() : belongsToMany(Permission)
└── users() : belongsToMany(User)
```

### Modèle Permission
```php
Permission
├── name : string (unique)
├── page_slug : string (unique)
├── description : string
└── roles() : belongsToMany(Role)
```

## Flux de vérification des permissions

```
Requête HTTP pour /dashboard
       │
       ▼
┌──────────────────────┐
│ Middleware 'auth'    │
│ Vérifier session     │
└──────────┬───────────┘
           │
           ├─ Si non authentifié → Rediriger vers /login
           │
           ▼
┌──────────────────────────────────┐
│ Middleware 'check_permission:    │
│ dashboard.index'                 │
└──────────┬───────────────────────┘
           │
           ├─ Si admin → Continuer (accès complet)
           │
           ├─ Si non-admin → Vérifier user.hasPermission('dashboard.index')
           │
           ├─ Si permission accordée → Continuer vers le contrôleur
           │
           └─ Si pas de permission → Abort(403)
```

## Structure des routes

### Routes publiques
```php
Route::middleware('guest')->group(function () {
    Route::get('/login', [AdminAuthController::class, 'showLogin']);
    Route::post('/login', [AdminAuthController::class, 'login']);
});
```

### Routes admin (full access)
```php
Route::middleware(['auth', 'admin'])->group(function () {
    // Tous les contrôleurs + ressources
});
```

### Routes utilisateur (permission-based)
```php
Route::middleware(['auth'])->group(function () {
    // Chaque route protégée par check_permission middleware
    Route::get('dashboard', ...)
        ->middleware('check_permission:dashboard.index');
});
```

## Commandes utiles

### Créer un nouvel utilisateur via CLI
```bash
php artisan tinker
>>> $user = User::create([...]);
>>> $role = Role::create(['name' => 'custom_role_' . $user->id]);
>>> $role->permissions()->attach([permission_ids]);
>>> $user->roles()->attach($role);
```

### Vérifier les permissions d'un utilisateur
```bash
php artisan tinker
>>> $user = User::find(1);
>>> $user->hasPermission('dashboard.index');  // true/false
>>> $user->getAccessiblePages();  // ['page1', 'page2']
>>> $user->roles->flatMap->permissions;  // Toutes les permissions
```

### Réinitialiser les permissions
```bash
php artisan migrate:rollback --step=2
php artisan migrate
php artisan db:seed --class=PermissionSeeder
```

## Validations

### Création d'utilisateur (RoleController@store)
```php
$validated = $request->validate([
    'first_name' => 'required|string|max:255',
    'last_name' => 'required|string|max:255',
    'email' => 'required|email|unique:users',
    'password' => 'required|string|min:8',
    'permissions' => 'array',
    'permissions.*' => 'exists:permissions,id',
]);
```

### Modification d'utilisateur (RoleController@update)
```php
$validated = $request->validate([
    'first_name' => 'required|string|max:255',
    'last_name' => 'required|string|max:255',
    'email' => 'required|email|unique:users,email,' . $user->id,
    'password' => 'nullable|string|min:8',  // Optionnel
    'permissions' => 'array',
    'permissions.*' => 'exists:permissions,id',
]);
```

## Points de sécurité

1. **Authentification** : Utilise la session Laravel avec CSRF token
2. **Hachage des mots de passe** : bcrypt automatique via User model
3. **Middleware de vérification** : Toutes les routes protégées
4. **Validation des données** : Côté serveur avec Form Request (implicite)
5. **Protection CSRF** : Automatique dans tous les formulaires Blade
6. **Autorisation** : Admin-only sur /roles + check_permission sur toutes les routes

## Points de performance

1. **Requêtes optimisées** : Eager loading avec `->with('roles.permissions')`
2. **Cache des routes** : `php artisan route:cache` est compatible
3. **Cache des vues** : `php artisan view:clear` nécessaire après modification
4. **Permissions en mémoire** : `getAccessiblePages()` utilise les données chargées

## Évolutivité future

### Ajouter une nouvelle page protégée

1. Créer la permission dans PermissionSeeder
2. Ajouter la route avec middleware
3. Relancer le seeder
4. Ajouter au formulaire de gestion des rôles

### Ajouter des rôles prédéfinis

```php
// Dans un nouveau seeder
$adminRole = Role::create(['name' => 'Manager']);
$adminRole->permissions()->attach([...]);
```

### Ajouter la log d'audit

```php
// Dans RoleController
AdminActionLog::create([
    'action' => 'user_created',
    'description' => "Created user {$user->email}",
]);
```

## Testeurs fournis

### Utilisateur Kiosque uniquement
- Email : `kiosk.user@example.com`
- Mot de passe : `password123`
- Accès : Kiosque uniquement (redirection automatique)

### Utilisateur limité
- Email : `limited.user@example.com`
- Mot de passe : `password123`
- Accès : Dashboard, Historique repas, Historique employés

### Utilisateur puissant
- Email : `power.user@example.com`
- Mot de passe : `password123`
- Accès : Toutes les pages sauf Kiosque

### Administrateur
- Créer manuellement ou utiliser seeder existant
- Email/mot de passe à définir
- Accès : Toutes les pages + Gestion des rôles

## Dépannage technique

### Le middleware ne s'applique pas
- Vérifier le bootstrap/app.php pour le registrar du middleware
- Vérifier le nom du middleware dans la route
- Vérifier la casse du paramètre

### Les permissions ne se mettent à jour
- Vérifier la requête PUT/PATCH dans DevTools
- Vérifier les logs Laravel (storage/logs/laravel.log)
- Vérifier que l'utilisateur n'est pas admin

### La vue ne charge pas
- Vérifier que la route est bien enregistrée : `php artisan route:list | grep roles`
- Vérifier le middleware d'authentification
- Vérifier le dossier resources/views/roles/index.blade.php existe

## Conclusion

Le système est prêt à l'emploi avec une UX complète, une sécurité robuste et une architecture évolutive. Les administrateurs peuvent maintenant créer facilement des utilisateurs avec accès limité aux pages du système.
