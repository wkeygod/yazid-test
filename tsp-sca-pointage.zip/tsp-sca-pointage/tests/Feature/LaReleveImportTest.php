<?php

namespace Tests\Feature;

use App\Models\LaReleveEntry;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Hash;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Tests\TestCase;

class LaReleveImportTest extends TestCase
{
    use RefreshDatabase;

    public function test_import_accepts_crew_change_excel_template(): void
    {
        $admin = User::create([
            'name' => 'Super Admin',
            'email' => 'admin@intranet.local',
            'password' => Hash::make('password'),
            'is_admin' => true,
        ]);

        $file = $this->makeCrewChangeTemplateUpload([
            ['1', 'B', 'Ahmed', 'Benali', 'Assistant Driller'],
            ['2', 'D', 'Yacine', 'Mansouri', 'Derrickman'],
        ]);

        $response = $this->actingAs($admin)->post(route('la-releve.import.store'), [
            'csv_file' => $file,
            'entry_date' => '2026-06-28',
            'end_date' => '2026-06-30',
            'allowed_meal_types' => ['breakfast', 'lunch'],
        ]);

        $response
            ->assertRedirect(route('la-releve.index', ['date' => '2026-06-28']))
            ->assertSessionHas('success');

        $firstEntry = LaReleveEntry::where('external_id', '1')->firstOrFail();

        $this->assertSame('Ahmed Benali', $firstEntry->full_name);
        $this->assertSame('Assistant Driller', $firstEntry->position);
        $this->assertSame('B', $firstEntry->rig_company);
        $this->assertSame('2026-06-28', $firstEntry->entry_date->toDateString());
        $this->assertSame('2026-06-30', $firstEntry->end_date->toDateString());
        $this->assertSame('la_releve', $firstEntry->source);
        $this->assertSame($admin->id, $firstEntry->created_by_user_id);

        $secondEntry = LaReleveEntry::where('external_id', '2')->firstOrFail();

        $this->assertSame('Yacine Mansouri', $secondEntry->full_name);
        $this->assertSame('Derrickman', $secondEntry->position);
        $this->assertSame('D', $secondEntry->rig_company);
        $this->assertSame('2026-06-28', $secondEntry->entry_date->toDateString());

        $this->assertSame(2, LaReleveEntry::count());
        $this->assertSame(['breakfast', 'lunch'], $firstEntry->allowed_meal_types);
    }

    public function test_import_reports_empty_rows_when_crew_template_has_no_names(): void
    {
        $admin = User::create([
            'name' => 'Super Admin',
            'email' => 'admin-empty@intranet.local',
            'password' => Hash::make('password'),
            'is_admin' => true,
        ]);

        $file = $this->makeCrewChangeTemplateUpload([
            ['1', 'B', '', '', 'Assistant Driller'],
            ['2', 'D', '', '', 'Derrickman'],
        ]);

        $response = $this->actingAs($admin)->from(route('la-releve.import'))->post(route('la-releve.import.store'), [
            'csv_file' => $file,
            'entry_date' => '2026-06-28',
            'allowed_meal_types' => ['breakfast'],
        ]);

        $response
            ->assertRedirect(route('la-releve.import'))
            ->assertSessionHas('error', fn (string $message): bool => str_contains($message, 'aucune ligne importable'));

        $this->assertSame(0, LaReleveEntry::count());
    }

    /**
     * @param array<int, array{0: string, 1: string, 2: string, 3: string, 4: string}> $rows
     */
    private function makeCrewChangeTemplateUpload(array $rows): UploadedFile
    {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle('Crew change');

        $sheet->fromArray(['', '', '', '', '', 'Crew IN', '', '', '', 'Crew Change Day', 'Crew Out'], null, 'A4');
        $sheet->fromArray(['', '', '', 'N', 'Crew', 'First Name', 'Last Name', 'Position', 'Remark'], null, 'A5');

        foreach ($rows as $index => $row) {
            $sheet->fromArray(['', '', '', $row[0], $row[1], $row[2], $row[3], $row[4], ''], null, 'A' . (6 + $index));
        }

        $path = tempnam(sys_get_temp_dir(), 'crew-change-import-');
        $xlsxPath = $path . '.xlsx';

        (new Xlsx($spreadsheet))->save($xlsxPath);
        $spreadsheet->disconnectWorksheets();

        return new UploadedFile(
            $xlsxPath,
            'Crew change tamplate.xlsx',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            null,
            true
        );
    }
}
