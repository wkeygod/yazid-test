<?php

namespace Tests\Feature;

use App\Models\Department;
use App\Models\Employee;
use App\Models\Permission;
use App\Models\Role;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class DepartmentManagementTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;

    protected function setUp(): void
    {
        parent::setUp();

        $this->admin = User::create([
            'name' => 'Super Admin',
            'email' => 'admin@intranet.local',
            'password' => Hash::make('password'),
            'is_admin' => true,
        ]);
    }

    public function test_admin_can_list_departments(): void
    {
        Department::create(['code' => 'CUI', 'name' => 'Cuisine', 'is_active' => true]);

        $response = $this->actingAs($this->admin)->get(route('departments.index'));

        $response->assertOk()->assertSee('Cuisine');
    }

    public function test_admin_can_create_a_department(): void
    {
        $response = $this->actingAs($this->admin)->post(route('departments.store'), [
            'code' => 'MAINT',
            'name' => 'Maintenance',
            'is_active' => '1',
        ]);

        $response->assertRedirect(route('departments.index'));
        $this->assertDatabaseHas('departments', ['code' => 'MAINT', 'name' => 'Maintenance', 'is_active' => true]);
    }

    public function test_department_code_must_be_unique(): void
    {
        Department::create(['code' => 'MAINT', 'name' => 'Maintenance', 'is_active' => true]);

        $response = $this->actingAs($this->admin)->post(route('departments.store'), [
            'code' => 'MAINT',
            'name' => 'Autre maintenance',
        ]);

        $response->assertSessionHasErrors('code');
    }

    public function test_admin_can_update_a_department(): void
    {
        $department = Department::create(['code' => 'LOG', 'name' => 'Logistique', 'is_active' => true]);

        $response = $this->actingAs($this->admin)->put(route('departments.update', $department), [
            'code' => 'LOG',
            'name' => 'Logistique & Transport',
            'is_active' => '0',
        ]);

        $response->assertRedirect(route('departments.index'));
        $department->refresh();
        $this->assertSame('Logistique & Transport', $department->name);
        $this->assertFalse($department->is_active);
    }

    public function test_department_with_employees_cannot_be_deleted(): void
    {
        $department = Department::create(['code' => 'SEC', 'name' => 'Securite', 'is_active' => true]);
        Employee::create([
            'employee_no' => 'EMP-9001',
            'department_id' => $department->id,
            'first_name' => 'Yacine',
            'last_name' => 'Amrani',
            'is_active' => true,
        ]);

        $response = $this->actingAs($this->admin)->delete(route('departments.destroy', $department));

        $response->assertRedirect();
        $this->assertDatabaseHas('departments', ['id' => $department->id]);
    }

    public function test_department_without_employees_can_be_deleted(): void
    {
        $department = Department::create(['code' => 'TMP', 'name' => 'Temporaire', 'is_active' => true]);

        $response = $this->actingAs($this->admin)->delete(route('departments.destroy', $department));

        $response->assertRedirect(route('departments.index'));
        $this->assertDatabaseMissing('departments', ['id' => $department->id]);
    }

    public function test_user_without_departments_permission_cannot_access_the_page(): void
    {
        $user = User::create([
            'name' => 'Limited User',
            'email' => 'limited@intranet.local',
            'password' => Hash::make('password'),
            'is_admin' => false,
        ]);
        $permission = Permission::firstOrCreate(
            ['page_slug' => 'dashboard.index'],
            ['name' => 'dashboard.index', 'description' => 'dashboard.index']
        );
        $role = Role::create(['name' => 'role_' . uniqid()]);
        $role->permissions()->attach($permission->id);
        $user->roles()->attach($role->id);

        $response = $this->actingAs($user)->get(route('departments.index'));

        $response->assertRedirect(route('dashboard.index'));
    }
}
