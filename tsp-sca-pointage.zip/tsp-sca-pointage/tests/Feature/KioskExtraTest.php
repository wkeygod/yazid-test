<?php

namespace Tests\Feature;

use App\Models\LaReleveEntry;
use App\Models\LaReleveMealLog;
use App\Models\MealRule;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class KioskExtraTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;
    private MealRule $breakfast;

    protected function setUp(): void
    {
        parent::setUp();

        $this->admin = User::create([
            'name' => 'Super Admin',
            'email' => 'admin@intranet.local',
            'password' => Hash::make('password'),
            'is_admin' => true,
        ]);

        $this->breakfast = MealRule::create([
            'name' => 'Petit-dejeuner',
            'start_time' => '06:00:00',
            'end_time' => '09:00:00',
            'is_active' => true,
        ]);
    }

    public function test_extra_page_renders_with_room_number_and_quantity_columns(): void
    {
        $entry = LaReleveEntry::create([
            'full_name' => 'Karim Belkacem',
            'external_id' => 'EXTRA-RENDER1',
            'rig_company' => 'ACME',
            'room_number' => '204B',
            'entry_date' => '2026-06-26',
            'allowed_meal_types' => [$this->breakfast->id],
            'source' => 'extra',
        ]);

        LaReleveMealLog::create([
            'la_releve_entry_id' => $entry->id,
            'meal_type' => $this->breakfast->name,
            'meal_rule_id' => $this->breakfast->id,
            'consumed_at' => '2026-06-26 07:00:00',
            'quantity' => 4,
        ]);

        $response = $this->actingAs($this->admin)
            ->get(route('kiosk.extra.page', ['list_date' => '2026-06-26']));

        $response->assertOk();
        $response->assertSee('Numéro de chambre');
        $response->assertSee('Chambre');
        $response->assertSee('204B');
        $response->assertSee('Karim Belkacem');
        $response->assertSee('Petit-dejeuner=4', false);
    }

    public function test_store_extra_saves_an_optional_room_number(): void
    {
        $response = $this->actingAs($this->admin)->post(route('kiosk.extra.store'), [
            'first_name' => 'Karim',
            'last_name' => 'Belkacem',
            'company' => 'ACME Drilling',
            'rig' => 'Rig-12',
            'room_number' => '204B',
            'selected_date' => '2026-06-26',
        ]);

        $response->assertRedirect();
        $this->assertDatabaseHas('la_releve_entries', [
            'full_name' => 'Karim Belkacem',
            'source' => 'extra',
            'room_number' => '204B',
        ]);
    }

    public function test_store_extra_works_without_a_room_number(): void
    {
        $response = $this->actingAs($this->admin)->post(route('kiosk.extra.store'), [
            'first_name' => 'Sami',
            'last_name' => 'Kaci',
            'company' => 'ACME Drilling',
            'rig' => 'Rig-12',
            'selected_date' => '2026-06-26',
        ]);

        $response->assertRedirect();
        $this->assertDatabaseHas('la_releve_entries', [
            'full_name' => 'Sami Kaci',
            'source' => 'extra',
            'room_number' => null,
        ]);
    }

    public function test_toggle_extra_records_a_meal_quantity_greater_than_one(): void
    {
        $entry = LaReleveEntry::create([
            'full_name' => 'Nadia Ouali',
            'external_id' => 'EXTRA-TEST1',
            'entry_date' => '2026-06-26',
            'allowed_meal_types' => [$this->breakfast->id],
            'source' => 'extra',
        ]);

        $response = $this->actingAs($this->admin)->post(route('kiosk.extra.toggle'), [
            'entry_id' => $entry->id,
            'meal_rule_id' => $this->breakfast->id,
            'quantity' => 3,
            'selected_date' => '2026-06-26',
        ]);

        $response->assertRedirect();
        $this->assertDatabaseHas('la_releve_meal_logs', [
            'la_releve_entry_id' => $entry->id,
            'meal_rule_id' => $this->breakfast->id,
            'quantity' => 3,
        ]);
        $this->assertSame(1, LaReleveMealLog::where('la_releve_entry_id', $entry->id)->count());
    }

    public function test_toggle_extra_edits_the_quantity_in_place_instead_of_rejecting(): void
    {
        $entry = LaReleveEntry::create([
            'full_name' => 'Nadia Ouali',
            'external_id' => 'EXTRA-TEST2',
            'entry_date' => '2026-06-26',
            'allowed_meal_types' => [$this->breakfast->id],
            'source' => 'extra',
        ]);

        $this->actingAs($this->admin)->post(route('kiosk.extra.toggle'), [
            'entry_id' => $entry->id,
            'meal_rule_id' => $this->breakfast->id,
            'quantity' => 2,
            'selected_date' => '2026-06-26',
        ]);

        $response = $this->actingAs($this->admin)->post(route('kiosk.extra.toggle'), [
            'entry_id' => $entry->id,
            'meal_rule_id' => $this->breakfast->id,
            'quantity' => 5,
            'selected_date' => '2026-06-26',
        ]);

        $response->assertRedirect();
        $this->assertSame(1, LaReleveMealLog::where('la_releve_entry_id', $entry->id)->count());
        $this->assertDatabaseHas('la_releve_meal_logs', [
            'la_releve_entry_id' => $entry->id,
            'meal_rule_id' => $this->breakfast->id,
            'quantity' => 5,
        ]);
    }

    public function test_toggle_extra_with_zero_quantity_removes_the_meal_log(): void
    {
        $entry = LaReleveEntry::create([
            'full_name' => 'Nadia Ouali',
            'external_id' => 'EXTRA-TEST3',
            'entry_date' => '2026-06-26',
            'allowed_meal_types' => [$this->breakfast->id],
            'source' => 'extra',
        ]);

        $this->actingAs($this->admin)->post(route('kiosk.extra.toggle'), [
            'entry_id' => $entry->id,
            'meal_rule_id' => $this->breakfast->id,
            'quantity' => 2,
            'selected_date' => '2026-06-26',
        ]);

        $response = $this->actingAs($this->admin)->post(route('kiosk.extra.toggle'), [
            'entry_id' => $entry->id,
            'meal_rule_id' => $this->breakfast->id,
            'quantity' => 0,
            'selected_date' => '2026-06-26',
        ]);

        $response->assertRedirect();
        $this->assertSame(0, LaReleveMealLog::where('la_releve_entry_id', $entry->id)->count());
    }

    public function test_toggle_extra_rejects_negative_quantity(): void
    {
        $entry = LaReleveEntry::create([
            'full_name' => 'Nadia Ouali',
            'external_id' => 'EXTRA-TEST4',
            'entry_date' => '2026-06-26',
            'allowed_meal_types' => [$this->breakfast->id],
            'source' => 'extra',
        ]);

        $response = $this->actingAs($this->admin)->post(route('kiosk.extra.toggle'), [
            'entry_id' => $entry->id,
            'meal_rule_id' => $this->breakfast->id,
            'quantity' => -1,
            'selected_date' => '2026-06-26',
        ]);

        $response->assertSessionHasErrors('quantity');
    }

    public function test_suggest_extra_names_is_case_and_accent_insensitive(): void
    {
        LaReleveEntry::create([
            'full_name' => 'Ahmed Bénali',
            'external_id' => 'EXTRA-SUG1',
            'entry_date' => '2026-06-26',
            'source' => 'extra',
        ]);

        $response = $this->actingAs($this->admin)
            ->getJson(route('kiosk.extra.suggest') . '?q=' . urlencode('AHMED benali'));

        $response->assertOk();
        $this->assertSame(['Ahmed Bénali'], $response->json('suggestions'));

        $response = $this->actingAs($this->admin)
            ->getJson(route('kiosk.extra.suggest') . '?q=' . urlencode('ahmed'));

        $response->assertOk();
        $this->assertSame(['Ahmed Bénali'], $response->json('suggestions'));
    }

    public function test_suggest_extra_names_only_returns_extra_source_entries(): void
    {
        LaReleveEntry::create([
            'full_name' => 'Ahmed La Releve',
            'external_id' => 'RELEVE-SUG1',
            'entry_date' => '2026-06-26',
            'source' => 'la_releve',
        ]);
        LaReleveEntry::create([
            'full_name' => 'Ahmed Extra',
            'external_id' => 'EXTRA-SUG2',
            'entry_date' => '2026-06-26',
            'source' => 'extra',
        ]);

        $response = $this->actingAs($this->admin)
            ->getJson(route('kiosk.extra.suggest') . '?q=ahmed');

        $response->assertOk();
        $this->assertSame(['Ahmed Extra'], $response->json('suggestions'));
    }

    public function test_suggest_extra_names_is_limited_to_ten_results(): void
    {
        for ($i = 1; $i <= 15; $i++) {
            LaReleveEntry::create([
                'full_name' => "Test Person {$i}",
                'external_id' => "EXTRA-LIMIT-{$i}",
                'entry_date' => '2026-06-26',
                'source' => 'extra',
            ]);
        }

        $response = $this->actingAs($this->admin)
            ->getJson(route('kiosk.extra.suggest') . '?q=test person');

        $response->assertOk();
        $this->assertCount(10, $response->json('suggestions'));
    }

    public function test_la_releve_toggle_still_defaults_to_quantity_one_and_is_unaffected(): void
    {
        $entry = LaReleveEntry::create([
            'full_name' => 'John Doe',
            'external_id' => 'RELEVE-REGRESSION',
            'entry_date' => '2026-06-26',
            'allowed_meal_types' => [$this->breakfast->id],
            'source' => 'la_releve',
        ]);

        $response = $this->actingAs($this->admin)->post(route('kiosk.la-releve.toggle'), [
            'entry_id' => $entry->id,
            'is_checked' => 1,
            'meal_rule_id' => $this->breakfast->id,
            'selected_date' => '2026-06-26',
        ]);

        $response->assertRedirect();
        $this->assertDatabaseHas('la_releve_meal_logs', [
            'la_releve_entry_id' => $entry->id,
            'meal_rule_id' => $this->breakfast->id,
            'quantity' => 1,
        ]);

        // Second click with is_checked=1 must still be rejected (unchanged La Relève behavior).
        $second = $this->actingAs($this->admin)->post(route('kiosk.la-releve.toggle'), [
            'entry_id' => $entry->id,
            'is_checked' => 1,
            'meal_rule_id' => $this->breakfast->id,
            'selected_date' => '2026-06-26',
        ]);

        $second->assertRedirect();
        $second->assertSessionHas('kiosk_la_releve_result', fn (array $result): bool => $result['status'] === 'error');
        $this->assertSame(1, LaReleveMealLog::where('la_releve_entry_id', $entry->id)->count());
    }
}
