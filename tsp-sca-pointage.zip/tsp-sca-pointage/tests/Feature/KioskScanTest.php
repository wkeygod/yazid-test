<?php

namespace Tests\Feature;

use App\Models\Card;
use App\Models\Employee;
use App\Models\MealLog;
use App\Models\MealRule;
use App\Models\User;
use Carbon\CarbonImmutable;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class KioskScanTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;
    private MealRule $breakfast;
    private Employee $employee;
    private Card $card;

    protected function setUp(): void
    {
        parent::setUp();

        $this->admin = User::create([
            'name' => 'Super Admin',
            'email' => 'admin@intranet.local',
            'password' => Hash::make('password'),
            'is_admin' => true,
        ]);

        $this->breakfast = MealRule::create([
            'name' => 'Petit-dejeuner',
            'start_time' => '06:00:00',
            'end_time' => '09:00:00',
            'cost' => 150,
            'is_active' => true,
        ]);

        $this->employee = Employee::create([
            'employee_no' => 'EMP-1000',
            'first_name' => 'Sami',
            'last_name' => 'Kaci',
            'position' => 'Agent',
            'rig_company' => 'TSP',
            'hired_at' => '2024-01-01',
            'is_active' => true,
            'allowed_meal_types' => [$this->breakfast->id],
        ]);

        $this->card = Card::create([
            'employee_id' => $this->employee->id,
            'assigned_employee_id' => $this->employee->id,
            'uid' => 'NFC-1000',
            'balance' => 0,
            'is_active' => true,
            'status' => Card::STATUS_ACTIVE,
            'issued_at' => '2024-01-01',
        ]);
    }

    protected function tearDown(): void
    {
        CarbonImmutable::setTestNow();

        parent::tearDown();
    }

    private function scan(array $overrides = []): \Illuminate\Testing\TestResponse
    {
        return $this->actingAs($this->admin)->post(route('kiosk.scan'), array_merge([
            'card_uid' => $this->card->uid,
            'meal_type' => (string) $this->breakfast->id,
        ], $overrides));
    }

    public function test_valid_scan_within_time_range_authorizes_the_meal(): void
    {
        CarbonImmutable::setTestNow('2026-06-26 07:00:00');

        $response = $this->scan();

        $response->assertSessionHas('kiosk_result', fn (array $result): bool => $result['status'] === 'success');

        $this->assertDatabaseHas('meal_logs', [
            'employee_id' => $this->employee->id,
            'card_id' => $this->card->id,
            'status' => 'approved',
            'amount_charged' => 150,
        ]);
    }

    public function test_scan_is_rejected_outside_the_allowed_time_range(): void
    {
        CarbonImmutable::setTestNow('2026-06-26 15:00:00');

        $response = $this->scan();

        $response->assertSessionHas('kiosk_result', fn (array $result): bool => $result['status'] === 'error'
            && $result['reason'] === 'outside_allowed_time');

        $this->assertSame(0, MealLog::count());
    }

    public function test_scan_is_rejected_when_meal_type_is_not_allowed_for_employee(): void
    {
        CarbonImmutable::setTestNow('2026-06-26 07:00:00');

        $lunch = MealRule::create([
            'name' => 'Dejeuner',
            'start_time' => '11:00:00',
            'end_time' => '14:00:00',
            'cost' => 200,
            'is_active' => true,
        ]);

        $response = $this->scan(['meal_type' => (string) $lunch->id]);

        $response->assertSessionHas('kiosk_result', fn (array $result): bool => $result['status'] === 'error'
            && $result['reason'] === 'meal_type_not_allowed');

        $this->assertSame(0, MealLog::count());
    }

    public function test_scan_is_rejected_for_an_unknown_card(): void
    {
        CarbonImmutable::setTestNow('2026-06-26 07:00:00');

        $response = $this->scan(['card_uid' => 'DOES-NOT-EXIST']);

        $response->assertSessionHas('kiosk_result', fn (array $result): bool => $result['status'] === 'error'
            && $result['reason'] === 'card_not_found');
    }

    public function test_scan_is_rejected_for_a_blocked_card(): void
    {
        CarbonImmutable::setTestNow('2026-06-26 07:00:00');

        $this->card->update(['status' => Card::STATUS_BLOCKED, 'is_active' => false]);

        $response = $this->scan();

        $response->assertSessionHas('kiosk_result', fn (array $result): bool => $result['status'] === 'error'
            && $result['reason'] === 'card_inactive');
    }

    public function test_scan_is_rejected_for_an_inactive_employee(): void
    {
        CarbonImmutable::setTestNow('2026-06-26 07:00:00');

        $this->employee->update(['is_active' => false]);

        $response = $this->scan();

        $response->assertSessionHas('kiosk_result', fn (array $result): bool => $result['status'] === 'error'
            && $result['reason'] === 'employee_inactive');
    }

    public function test_second_scan_for_the_same_meal_on_the_same_day_is_rejected(): void
    {
        CarbonImmutable::setTestNow('2026-06-26 07:00:00');

        $this->scan();
        $response = $this->scan();

        $response->assertSessionHas('kiosk_result', fn (array $result): bool => $result['status'] === 'error'
            && $result['reason'] === 'already_authorized_today');

        $this->assertSame(1, MealLog::count());
    }

    public function test_api_scan_validate_endpoint_authorizes_a_valid_card(): void
    {
        CarbonImmutable::setTestNow('2026-06-26 07:00:00');

        $response = $this->postJson('/api/scan/validate', [
            'card_uid' => $this->card->uid,
            'meal_rule_id' => $this->breakfast->id,
        ]);

        $response->assertOk()->assertJson(['status' => 'success']);
    }

    public function test_api_scan_validate_endpoint_returns_422_for_an_unknown_card(): void
    {
        $response = $this->postJson('/api/scan/validate', [
            'card_uid' => 'DOES-NOT-EXIST',
        ]);

        $response->assertStatus(422)->assertJson(['status' => 'error']);
    }

    public function test_api_meal_check_endpoint_reports_denied_for_blocked_card(): void
    {
        CarbonImmutable::setTestNow('2026-06-26 07:00:00');

        $this->card->update(['status' => Card::STATUS_BLOCKED, 'is_active' => false]);

        $response = $this->postJson('/api/meal/check', ['card_uid' => $this->card->uid]);

        $response->assertStatus(422)->assertJson(['status' => 'denied']);
    }
}
