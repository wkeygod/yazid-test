<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class BackupDatabaseCommandTest extends TestCase
{
    use RefreshDatabase;

    public function test_command_exits_successfully_and_reports_skip_when_not_using_mysql(): void
    {
        $this->artisan('backup:database')
            ->expectsOutputToContain('Sauvegarde ignorée')
            ->assertExitCode(0);
    }
}
