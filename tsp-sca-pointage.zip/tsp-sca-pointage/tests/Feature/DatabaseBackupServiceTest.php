<?php

namespace Tests\Feature;

use App\Services\DatabaseBackupService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class DatabaseBackupServiceTest extends TestCase
{
    use RefreshDatabase;

    protected function tearDown(): void
    {
        putenv('AWS_ACCESS_KEY_ID');
        putenv('AWS_BUCKET');
        putenv('BACKUP_RETENTION_DAYS');

        parent::tearDown();
    }

    public function test_run_is_skipped_when_the_active_connection_is_not_mysql(): void
    {
        $result = app(DatabaseBackupService::class)->run();

        $this->assertSame('skipped', $result['status']);
        $this->assertNull($result['filename']);
        $this->assertFalse($result['uploaded_offsite']);
    }

    public function test_is_offsite_configured_requires_both_key_and_bucket(): void
    {
        $service = app(DatabaseBackupService::class);

        putenv('AWS_ACCESS_KEY_ID');
        putenv('AWS_BUCKET');
        $this->assertFalse($service->isOffsiteConfigured());

        putenv('AWS_ACCESS_KEY_ID=test-key');
        $this->assertFalse($service->isOffsiteConfigured());

        putenv('AWS_BUCKET=test-bucket');
        $this->assertTrue($service->isOffsiteConfigured());
    }

    public function test_retention_days_defaults_to_fourteen_and_is_never_below_one(): void
    {
        $service = app(DatabaseBackupService::class);

        putenv('BACKUP_RETENTION_DAYS');
        $this->assertSame(14, $service->retentionDays());

        putenv('BACKUP_RETENTION_DAYS=0');
        $this->assertSame(1, $service->retentionDays());

        putenv('BACKUP_RETENTION_DAYS=30');
        $this->assertSame(30, $service->retentionDays());
    }

    public function test_prune_local_backups_removes_only_files_older_than_retention(): void
    {
        Storage::fake('local');

        Storage::disk('local')->put('backups/old.sql.gz', 'old');
        Storage::disk('local')->put('backups/recent.sql.gz', 'recent');

        touch(Storage::disk('local')->path('backups/old.sql.gz'), now()->subDays(30)->getTimestamp());
        touch(Storage::disk('local')->path('backups/recent.sql.gz'), now()->subDays(2)->getTimestamp());

        $deleted = app(DatabaseBackupService::class)->pruneLocalBackups(14);

        $this->assertSame(1, $deleted);
        $this->assertFalse(Storage::disk('local')->exists('backups/old.sql.gz'));
        $this->assertTrue(Storage::disk('local')->exists('backups/recent.sql.gz'));
    }

    public function test_prune_remote_backups_is_a_no_op_when_offsite_is_not_configured(): void
    {
        putenv('AWS_ACCESS_KEY_ID');
        putenv('AWS_BUCKET');

        $deleted = app(DatabaseBackupService::class)->pruneRemoteBackups(14);

        $this->assertSame(0, $deleted);
    }
}
