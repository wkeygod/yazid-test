<?php

namespace Tests\Feature;

use App\Models\LaReleveEntry;
use App\Models\LaReleveMealLog;
use App\Models\MealRule;
use App\Models\User;
use Carbon\CarbonImmutable;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class LaReleveDateRangeTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;
    private MealRule $breakfast;
    private MealRule $lunch;

    protected function setUp(): void
    {
        parent::setUp();

        // Create admin user
        $this->admin = User::create([
            'name' => 'Super Admin',
            'email' => 'admin@intranet.local',
            'password' => \Illuminate\Support\Facades\Hash::make('password'),
            'is_admin' => true,
        ]);

        // Create meal rules
        $this->breakfast = MealRule::create([
            'name' => 'Petit-déjeuner',
            'start_time' => '06:00:00',
            'end_time' => '09:00:00',
            'is_active' => true,
        ]);

        $this->lunch = MealRule::create([
            'name' => 'Déjeuner',
            'start_time' => '11:00:00',
            'end_time' => '14:00:00',
            'is_active' => true,
        ]);
    }

    public function test_entry_listed_in_kiosk_within_date_range_and_not_outside()
    {
        // Create an entry valid from 2026-06-25 to 2026-06-30
        $entry = LaReleveEntry::create([
            'full_name' => 'John Doe Range',
            'external_id' => 'RELEVE-RANGE-1',
            'position' => 'Rig operator',
            'rig_company' => 'Catering Corp',
            'entry_date' => '2026-06-25',
            'end_date' => '2026-06-30',
            'allowed_meal_types' => [$this->breakfast->id, $this->lunch->id],
            'source' => 'la_releve',
        ]);

        // 1. Check a date before the range (2026-06-24)
        $response = $this->actingAs($this->admin)
            ->get(route('kiosk.la-releve.page', ['list_date' => '2026-06-24']));
        $response->assertStatus(200);
        $response->assertDontSee('John Doe Range');

        // 2. Check a date inside the range (2026-06-26)
        $response = $this->actingAs($this->admin)
            ->get(route('kiosk.la-releve.page', ['list_date' => '2026-06-26']));
        $response->assertStatus(200);
        $response->assertSee('John Doe Range');
        $response->assertSee('2026-06-25');
        $response->assertSee('2026-06-30');

        // 3. Check a date after the range (2026-07-01)
        $response = $this->actingAs($this->admin)
            ->get(route('kiosk.la-releve.page', ['list_date' => '2026-07-01']));
        $response->assertStatus(200);
        $response->assertDontSee('John Doe Range');
    }

    public function test_daily_consumption_quota_resets_daily_for_range_entries()
    {
        // Create an entry valid from 2026-06-25 to 2026-06-30
        $entry = LaReleveEntry::create([
            'full_name' => 'Alice Reset',
            'external_id' => 'RELEVE-RANGE-2',
            'position' => 'Mechanic',
            'rig_company' => 'Drill Co',
            'entry_date' => '2026-06-25',
            'end_date' => '2026-06-30',
            'allowed_meal_types' => [$this->breakfast->id, $this->lunch->id],
            'source' => 'la_releve',
        ]);

        // 1. Verify initially 0 meals consumed on 2026-06-26
        $response = $this->actingAs($this->admin)
            ->get(route('kiosk.la-releve.page', ['list_date' => '2026-06-26']));
        $response->assertStatus(200);
        // The meal button shows that it's open (allowed to eat)
        $response->assertSee('Alice Reset');
        $response->assertSee('Petit-déjeuner');

        // 2. Consume breakfast on 2026-06-26
        $toggleResponse = $this->actingAs($this->admin)
            ->post(route('kiosk.la-releve.toggle'), [
                'entry_id' => $entry->id,
                'selected_date' => '2026-06-26',
                'meal_rule_id' => $this->breakfast->id,
                'is_checked' => 1,
            ]);
        $toggleResponse->assertRedirect();

        // Assert log is created for 2026-06-26
        $this->assertDatabaseHas('la_releve_meal_logs', [
            'la_releve_entry_id' => $entry->id,
            'meal_rule_id' => $this->breakfast->id,
        ]);
        $log = LaReleveMealLog::where('la_releve_entry_id', $entry->id)->first();
        $this->assertEquals('2026-06-26', CarbonImmutable::parse($log->consumed_at)->toDateString());

        // 3. Verify Kiosk page on 2026-06-26 shows consumedCount = 1
        $response = $this->actingAs($this->admin)
            ->get(route('kiosk.la-releve.page', ['list_date' => '2026-06-26']));
        $response->assertStatus(200);
        // The table row should show 1 consumed and 1 remaining
        $response->assertSee('<td>1</td>', false); // Consumed
        $response->assertSee('<td>1</td>', false); // Remaining (out of 2 allowed)

        // 4. Verify Kiosk page on 2026-06-27 (tomorrow) shows consumedCount = 0 (daily reset)
        $response = $this->actingAs($this->admin)
            ->get(route('kiosk.la-releve.page', ['list_date' => '2026-06-27']));
        $response->assertStatus(200);
        // On a new day, the count of consumed meals must reset to 0
        $response->assertSee('<td>0</td>', false); // Consumed
        $response->assertSee('<td>2</td>', false); // Remaining (out of 2 allowed)

        // 5. Consume breakfast on 2026-06-27
        $toggleResponse = $this->actingAs($this->admin)
            ->post(route('kiosk.la-releve.toggle'), [
                'entry_id' => $entry->id,
                'selected_date' => '2026-06-27',
                'meal_rule_id' => $this->breakfast->id,
                'is_checked' => 1,
            ]);
        $toggleResponse->assertRedirect();

        // Assert another log is created for 2026-06-27
        $this->assertDatabaseCount('la_releve_meal_logs', 2);
    }

    public function test_reliability_with_clock_travel()
    {
        // 1. Set the initial system date to 2026-06-26
        CarbonImmutable::setTestNow('2026-06-26 12:00:00');

        // Create an entry valid from 2026-06-25 to 2026-06-30
        $entry = LaReleveEntry::create([
            'full_name' => 'Charlie ClockTraveler',
            'external_id' => 'RELEVE-RANGE-3',
            'position' => 'Driller',
            'rig_company' => 'Rig Co',
            'entry_date' => '2026-06-25',
            'end_date' => '2026-06-30',
            'allowed_meal_types' => [$this->breakfast->id, $this->lunch->id],
            'source' => 'la_releve',
        ]);

        // 2. Kiosk page loaded without list_date parameter (defaults to today = 2026-06-26)
        $response = $this->actingAs($this->admin)
            ->get(route('kiosk.la-releve.page'));
        $response->assertStatus(200);
        $response->assertSee('Charlie ClockTraveler');
        $response->assertSee('<td>0</td>', false); // 0 consumed

        // 3. Mark breakfast as consumed (without providing selected_date, meaning it falls back to current system date)
        $toggleResponse = $this->actingAs($this->admin)
            ->post(route('kiosk.la-releve.toggle'), [
                'entry_id' => $entry->id,
                'meal_rule_id' => $this->breakfast->id,
                'is_checked' => 1,
            ]);
        $toggleResponse->assertRedirect();

        // Verify the database has the log created with today's date
        $this->assertDatabaseHas('la_releve_meal_logs', [
            'la_releve_entry_id' => $entry->id,
            'meal_rule_id' => $this->breakfast->id,
        ]);
        $log = LaReleveMealLog::where('la_releve_entry_id', $entry->id)->first();
        $this->assertEquals('2026-06-26', CarbonImmutable::parse($log->consumed_at)->toDateString());

        // Verify kiosk shows 1 consumed
        $response = $this->actingAs($this->admin)->get(route('kiosk.la-releve.page'));
        $response->assertSee('<td>1</td>', false);

        // 4. Shift system time to tomorrow (2026-06-27)
        CarbonImmutable::setTestNow('2026-06-27 09:00:00');

        // Verify that the kiosk page (loaded without parameters) now naturally shows 0 consumed
        $response = $this->actingAs($this->admin)->get(route('kiosk.la-releve.page'));
        $response->assertStatus(200);
        $response->assertSee('Charlie ClockTraveler');
        $response->assertSee('<td>0</td>', false); // resets to 0 automatically on the new day

        // 5. Shift system time past range end (2026-07-01)
        CarbonImmutable::setTestNow('2026-07-01 12:00:00');

        // Verify that the entry is now naturally expired and does NOT show up in the kiosk list
        $response = $this->actingAs($this->admin)->get(route('kiosk.la-releve.page'));
        $response->assertStatus(200);
        $response->assertDontSee('Charlie ClockTraveler');

        // Clean up time travel mock
        CarbonImmutable::setTestNow();
    }
}

