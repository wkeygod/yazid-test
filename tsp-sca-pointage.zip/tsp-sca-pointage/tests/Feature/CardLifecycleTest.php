<?php

namespace Tests\Feature;

use App\Models\Card;
use App\Models\CardAssignment;
use App\Models\CardStatusHistory;
use App\Models\Employee;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class CardLifecycleTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;
    private Employee $employee;
    private Card $card;

    protected function setUp(): void
    {
        parent::setUp();

        $this->admin = User::create([
            'name' => 'Super Admin',
            'email' => 'admin@intranet.local',
            'password' => Hash::make('password'),
            'is_admin' => true,
        ]);

        $this->employee = Employee::create([
            'employee_no' => 'EMP-0001',
            'first_name' => 'Karim',
            'last_name' => 'Belkacem',
            'position' => 'Cuisinier',
            'rig_company' => 'TSP',
            'hired_at' => '2024-01-01',
            'is_active' => true,
        ]);

        $this->card = Card::create([
            'employee_id' => $this->employee->id,
            'assigned_employee_id' => $this->employee->id,
            'uid' => 'CARD-0001',
            'balance' => 0,
            'is_active' => true,
            'status' => Card::STATUS_ACTIVE,
            'issued_at' => '2024-01-01',
        ]);

        CardAssignment::create([
            'card_id' => $this->card->id,
            'employee_id' => $this->employee->id,
            'assigned_at' => now(),
            'change_reason' => 'Initial assignment',
        ]);
    }

    public function test_blocking_a_card_deactivates_it_and_records_history(): void
    {
        $response = $this->actingAs($this->admin)
            ->patch(route('cards.block', $this->card), ['block_reason' => 'Carte suspecte']);

        $response->assertRedirect();

        $this->card->refresh();
        $this->assertSame(Card::STATUS_BLOCKED, $this->card->status);
        $this->assertFalse($this->card->is_active);
        $this->assertSame('Carte suspecte', $this->card->block_reason);

        $this->assertDatabaseHas('card_status_histories', [
            'card_id' => $this->card->id,
            'from_status' => Card::STATUS_ACTIVE,
            'to_status' => Card::STATUS_BLOCKED,
        ]);
    }

    public function test_unblocking_a_card_restores_active_status(): void
    {
        $this->actingAs($this->admin)->patch(route('cards.block', $this->card), ['block_reason' => 'Test']);
        $this->actingAs($this->admin)->patch(route('cards.unblock', $this->card));

        $this->card->refresh();
        $this->assertSame(Card::STATUS_ACTIVE, $this->card->status);
        $this->assertTrue($this->card->is_active);
        $this->assertNull($this->card->block_reason);

        $this->assertDatabaseHas('card_status_histories', [
            'card_id' => $this->card->id,
            'from_status' => Card::STATUS_BLOCKED,
            'to_status' => Card::STATUS_ACTIVE,
        ]);
    }

    public function test_marking_a_card_lost_requires_a_reason(): void
    {
        $response = $this->actingAs($this->admin)
            ->patch(route('cards.mark-lost', $this->card), []);

        $response->assertSessionHasErrors('block_reason');

        $this->card->refresh();
        $this->assertSame(Card::STATUS_ACTIVE, $this->card->status);
    }

    public function test_marking_a_card_lost_records_status_history(): void
    {
        $response = $this->actingAs($this->admin)
            ->patch(route('cards.mark-lost', $this->card), ['block_reason' => 'Perdue par l\'employe']);

        $response->assertRedirect();

        $this->card->refresh();
        $this->assertSame(Card::STATUS_LOST, $this->card->status);
        $this->assertFalse($this->card->is_active);

        $this->assertDatabaseHas('card_status_histories', [
            'card_id' => $this->card->id,
            'to_status' => Card::STATUS_LOST,
            'reason' => 'Perdue par l\'employe',
        ]);
    }

    public function test_detaching_a_card_closes_the_open_assignment(): void
    {
        $response = $this->actingAs($this->admin)->patch(route('cards.detach', $this->card));

        $response->assertRedirect();

        $this->card->refresh();
        $this->assertNull($this->card->assigned_employee_id);

        $this->assertDatabaseHas('card_assignments', [
            'card_id' => $this->card->id,
            'employee_id' => $this->employee->id,
        ]);

        $assignment = CardAssignment::where('card_id', $this->card->id)->first();
        $this->assertNotNull($assignment->unassigned_at);
    }

    public function test_reassigning_a_card_closes_old_assignment_and_opens_a_new_one(): void
    {
        $otherEmployee = Employee::create([
            'employee_no' => 'EMP-0002',
            'first_name' => 'Nadia',
            'last_name' => 'Ouali',
            'position' => 'Serveuse',
            'rig_company' => 'TSP',
            'hired_at' => '2024-02-01',
            'is_active' => true,
        ]);

        $response = $this->actingAs($this->admin)
            ->patch(route('cards.reassign', $this->card), ['employee_id' => $otherEmployee->id]);

        $response->assertRedirect();

        $this->card->refresh();
        $this->assertSame($otherEmployee->id, $this->card->assigned_employee_id);

        $this->assertSame(2, CardAssignment::where('card_id', $this->card->id)->count());

        $closedAssignment = CardAssignment::where('card_id', $this->card->id)
            ->where('employee_id', $this->employee->id)
            ->first();
        $this->assertNotNull($closedAssignment->unassigned_at);

        $openAssignment = CardAssignment::where('card_id', $this->card->id)
            ->where('employee_id', $otherEmployee->id)
            ->first();
        $this->assertNull($openAssignment->unassigned_at);
    }

    public function test_replacing_a_card_creates_a_new_active_card_and_marks_the_old_one_replaced(): void
    {
        $response = $this->actingAs($this->admin)
            ->post(route('cards.replace', $this->card), [
                'new_uid' => 'CARD-0002',
                'reason' => 'Carte endommagee',
            ]);

        $response->assertRedirect();

        $this->card->refresh();
        $this->assertSame(Card::STATUS_REPLACED, $this->card->status);
        $this->assertFalse($this->card->is_active);
        $this->assertNull($this->card->assigned_employee_id);
        $this->assertNotNull($this->card->replaced_by_card_id);

        $newCard = Card::find($this->card->replaced_by_card_id);
        $this->assertNotNull($newCard);
        $this->assertSame('CARD-0002', $newCard->uid);
        $this->assertSame(Card::STATUS_ACTIVE, $newCard->status);
        $this->assertSame($this->employee->id, $newCard->assigned_employee_id);

        $this->assertDatabaseHas('card_assignments', [
            'card_id' => $newCard->id,
            'employee_id' => $this->employee->id,
            'unassigned_at' => null,
        ]);
    }

    public function test_replacing_a_card_rejects_a_duplicate_uid(): void
    {
        Card::create([
            'employee_id' => $this->employee->id,
            'uid' => 'CARD-DUPLICATE',
            'balance' => 0,
            'is_active' => true,
            'status' => Card::STATUS_INACTIVE,
        ]);

        $response = $this->actingAs($this->admin)
            ->post(route('cards.replace', $this->card), ['new_uid' => 'CARD-DUPLICATE']);

        $response->assertSessionHasErrors('new_uid');
    }
}
