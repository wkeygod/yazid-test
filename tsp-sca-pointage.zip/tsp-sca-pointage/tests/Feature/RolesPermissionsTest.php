<?php

namespace Tests\Feature;

use App\Models\Permission;
use App\Models\Role;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class RolesPermissionsTest extends TestCase
{
    use RefreshDatabase;

    private function createUserWithPermissions(array $pageSlugs, string $email): User
    {
        $user = User::create([
            'name' => 'Test User',
            'email' => $email,
            'password' => Hash::make('password'),
            'is_admin' => false,
        ]);

        if ($pageSlugs !== []) {
            $role = Role::create(['name' => 'role_' . uniqid()]);

            foreach ($pageSlugs as $slug) {
                $permission = Permission::firstOrCreate(
                    ['page_slug' => $slug],
                    ['name' => $slug, 'description' => $slug]
                );
                $role->permissions()->attach($permission->id);
            }

            $user->roles()->attach($role->id);
        }

        return $user;
    }

    public function test_admin_can_access_every_permission_protected_page(): void
    {
        $admin = User::create([
            'name' => 'Super Admin',
            'email' => 'admin@intranet.local',
            'password' => Hash::make('password'),
            'is_admin' => true,
        ]);

        $this->actingAs($admin)->get(route('dashboard.index'))->assertOk();
        $this->actingAs($admin)->get(route('employees.index'))->assertOk();
        $this->actingAs($admin)->get(route('roles.index'))->assertOk();
        $this->actingAs($admin)->get(route('kiosk.index'))->assertOk();
    }

    public function test_login_is_rejected_for_a_user_without_any_permission(): void
    {
        $user = $this->createUserWithPermissions([], 'no-permission@intranet.local');

        $response = $this->post(route('login.attempt'), [
            'email' => $user->email,
            'password' => 'password',
        ]);

        $response->assertSessionHasErrors('email');
        $this->assertGuest();
    }

    public function test_user_with_a_single_permission_is_redirected_to_it_after_login(): void
    {
        $user = $this->createUserWithPermissions(['kiosk.index'], 'kiosk-only@intranet.local');

        $response = $this->post(route('login.attempt'), [
            'email' => $user->email,
            'password' => 'password',
        ]);

        $response->assertRedirect(route('kiosk.index'));
        $this->assertAuthenticatedAs($user);
    }

    public function test_user_with_multiple_permissions_lands_on_the_dashboard_after_login(): void
    {
        $user = $this->createUserWithPermissions(
            ['dashboard.index', 'employees.index'],
            'power-user@intranet.local'
        );

        $response = $this->post(route('login.attempt'), [
            'email' => $user->email,
            'password' => 'password',
        ]);

        $response->assertRedirect(route('dashboard.index'));
    }

    public function test_user_without_the_required_permission_is_redirected_to_an_accessible_page(): void
    {
        $user = $this->createUserWithPermissions(['dashboard.index'], 'limited@intranet.local');

        $response = $this->actingAs($user)->get(route('employees.index'));

        $response->assertRedirect(route('dashboard.index'));
        $response->assertSessionHas('error');
    }

    public function test_user_cannot_access_role_management(): void
    {
        $user = $this->createUserWithPermissions(['dashboard.index'], 'not-admin@intranet.local');

        $response = $this->actingAs($user)->get(route('roles.index'));

        $response->assertRedirect(route('dashboard.index'));
    }

    public function test_user_can_access_only_the_pages_covered_by_their_permissions(): void
    {
        $user = $this->createUserWithPermissions(
            ['dashboard.index', 'kiosk.index'],
            'dashboard-and-kiosk@intranet.local'
        );

        $this->actingAs($user)->get(route('dashboard.index'))->assertOk();
        $this->actingAs($user)->get(route('kiosk.index'))->assertOk();
        $this->actingAs($user)->get(route('employees.index'))->assertRedirect(route('dashboard.index'));
    }
}
