<?php

namespace Tests\Feature;

use App\Models\Device;
use App\Models\Permission;
use App\Models\Role;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class DeviceManagementTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;

    protected function setUp(): void
    {
        parent::setUp();

        $this->admin = User::create([
            'name' => 'Super Admin',
            'email' => 'admin@intranet.local',
            'password' => Hash::make('password'),
            'is_admin' => true,
        ]);
    }

    public function test_admin_can_list_devices(): void
    {
        Device::create(['code' => 'KIOSK-01', 'name' => 'Kiosque cantine', 'is_active' => true, 'status' => Device::STATUS_ACTIVE]);

        $response = $this->actingAs($this->admin)->get(route('devices.index'));

        $response->assertOk()->assertSee('Kiosque cantine');
    }

    public function test_admin_can_create_a_device(): void
    {
        $response = $this->actingAs($this->admin)->post(route('devices.store'), [
            'code' => 'KIOSK-02',
            'name' => 'Kiosque entree',
            'location' => 'Hall principal',
            'ip_address' => '192.168.1.50',
            'is_active' => '1',
        ]);

        $response->assertRedirect(route('devices.index'));
        $this->assertDatabaseHas('devices', [
            'code' => 'KIOSK-02',
            'name' => 'Kiosque entree',
            'ip_address' => '192.168.1.50',
            'is_active' => true,
            'status' => Device::STATUS_ACTIVE,
        ]);
    }

    public function test_device_creation_syncs_status_with_is_active(): void
    {
        $this->actingAs($this->admin)->post(route('devices.store'), [
            'code' => 'KIOSK-03',
            'name' => 'Kiosque desactive',
            'is_active' => '0',
        ]);

        $this->assertDatabaseHas('devices', [
            'code' => 'KIOSK-03',
            'is_active' => false,
            'status' => Device::STATUS_INACTIVE,
        ]);
    }

    public function test_device_code_must_be_unique(): void
    {
        Device::create(['code' => 'KIOSK-04', 'name' => 'Kiosque A', 'is_active' => true, 'status' => Device::STATUS_ACTIVE]);

        $response = $this->actingAs($this->admin)->post(route('devices.store'), [
            'code' => 'KIOSK-04',
            'name' => 'Kiosque B',
        ]);

        $response->assertSessionHasErrors('code');
    }

    public function test_device_ip_address_must_be_valid(): void
    {
        $response = $this->actingAs($this->admin)->post(route('devices.store'), [
            'code' => 'KIOSK-05',
            'name' => 'Kiosque C',
            'ip_address' => 'not-an-ip',
        ]);

        $response->assertSessionHasErrors('ip_address');
    }

    public function test_admin_can_update_a_device(): void
    {
        $device = Device::create(['code' => 'KIOSK-06', 'name' => 'Kiosque D', 'is_active' => true, 'status' => Device::STATUS_ACTIVE]);

        $response = $this->actingAs($this->admin)->put(route('devices.update', $device), [
            'code' => 'KIOSK-06',
            'name' => 'Kiosque D (renomme)',
            'is_active' => '0',
        ]);

        $response->assertRedirect(route('devices.index'));
        $device->refresh();
        $this->assertSame('Kiosque D (renomme)', $device->name);
        $this->assertFalse($device->is_active);
        $this->assertSame(Device::STATUS_INACTIVE, $device->status);
    }

    public function test_admin_can_delete_a_device(): void
    {
        $device = Device::create(['code' => 'KIOSK-07', 'name' => 'Kiosque E', 'is_active' => true, 'status' => Device::STATUS_ACTIVE]);

        $response = $this->actingAs($this->admin)->delete(route('devices.destroy', $device));

        $response->assertRedirect(route('devices.index'));
        $this->assertDatabaseMissing('devices', ['id' => $device->id]);
    }

    public function test_user_without_devices_permission_cannot_access_the_page(): void
    {
        $user = User::create([
            'name' => 'Limited User',
            'email' => 'limited@intranet.local',
            'password' => Hash::make('password'),
            'is_admin' => false,
        ]);
        $permission = Permission::firstOrCreate(
            ['page_slug' => 'dashboard.index'],
            ['name' => 'dashboard.index', 'description' => 'dashboard.index']
        );
        $role = Role::create(['name' => 'role_' . uniqid()]);
        $role->permissions()->attach($permission->id);
        $user->roles()->attach($role->id);

        $response = $this->actingAs($user)->get(route('devices.index'));

        $response->assertRedirect(route('dashboard.index'));
    }
}
