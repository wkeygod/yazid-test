@extends('layouts.app')

@section('title', 'Extra')

@section('content')
    @php
        $periodLabel = ($selectedDateFrom && $selectedDateTo)
            ? ($selectedDateFrom . ' au ' . $selectedDateTo)
            : 'Toutes les dates';

        $mealLabels = [
            'breakfast' => 'Petit-dejeuner',
            'lunch' => 'Dejeuner',
            'dinner' => 'Diner',
        ];
    @endphp

    <x-admin.page-header
        title="Extra"
        subtitle="Historique et statistiques des entrees creees depuis le kiosque Extra"
    />

    <style>
        .extra-filter-form {
            gap: .8rem;
        }

        .extra-filter-actions-wrap {
            grid-column: 1 / -1;
            margin-top: .15rem;
        }

        .extra-filter-actions {
            display: flex;
            gap: .5rem;
            flex-wrap: nowrap;
            align-items: center;
            width: 100%;
            min-width: 0;
        }

        .extra-filter-btn {
            min-height: 2.5rem !important;
            min-width: 0;
            flex: 1 1 0;
            padding: .58rem .84rem !important;
            font-size: .88rem !important;
            font-weight: 800 !important;
            letter-spacing: .12px;
            text-shadow: 0 1px 0 rgba(9, 34, 58, .35);
            white-space: nowrap;
        }

        .extra-filter-btn-reset {
            background: linear-gradient(180deg, #5d708a, #4d617d) !important;
        }

        .extra-filter-btn-csv {
            background: linear-gradient(180deg, #1f7a4f, #17613e) !important;
        }

        @media (max-width: 980px) {
            .extra-filter-actions {
                width: 100%;
            }

            .extra-filter-btn {
                font-size: .82rem !important;
                padding: .54rem .48rem !important;
                letter-spacing: .08px;
            }
        }
    </style>

    <div class="card" style="margin-bottom: 1rem;">
        <div class="panel-header">
            <h2>Filtres</h2>
        </div>

        <x-admin.filter-bar action="{{ route('extra.index') }}" class="extra-filter-form">
            <div>
                <label>Date debut</label>
                <input type="date" name="date_from" value="{{ $selectedDateFrom }}">
            </div>

            <div>
                <label>Date fin</label>
                <input type="date" name="date_to" value="{{ $selectedDateTo }}">
            </div>

            <div>
                <label>Recherche</label>
                <input id="extra-realtime-search" type="text" name="q" value="{{ $search }}" placeholder="Nom, compagnie, rig, identifiant...">
            </div>

            <div>
                <label>Compagnie</label>
                <input type="text" name="company" value="{{ $company }}" placeholder="Filtrer par compagnie">
            </div>

            <div>
                <label>Rig</label>
                <input type="text" name="rig" value="{{ $rig }}" placeholder="Filtrer par rig">
            </div>

            <div class="extra-filter-actions-wrap">
                <div class="extra-filter-actions">
                    <button class="btn extra-filter-btn" type="submit">Appliquer</button>
                    <a class="btn extra-filter-btn extra-filter-btn-reset" href="{{ route('extra.index') }}">Reinitialiser</a>
                    <a class="btn extra-filter-btn extra-filter-btn-csv export-link" data-export-url="{{ route('extra.export', array_merge(request()->query(), ['format' => 'excel'])) }}" href="#">Exporter Excel Pro</a>
                </div>
            </div>
        </x-admin.filter-bar>
    </div>

    <div class="grid grid-2" style="margin-bottom:1rem;">
        <x-admin.kpi-card label="Total entrees Extra" :value="number_format((int) $summary['total_entries'])" />
        <x-admin.kpi-card label="Avec repas" :value="number_format((int) $summary['with_meal'])" tone="success" />
        <x-admin.kpi-card label="Sans repas" :value="number_format((int) $summary['without_meal'])" tone="danger" />
        <x-admin.kpi-card label="Total repas consommes" :value="number_format((int) $summary['total_meals'])" tone="info" />
        <x-admin.kpi-card label="Petit-dejeuner" :value="number_format((int) $summary['breakfast'])" />
        <x-admin.kpi-card label="Dejeuner" :value="number_format((int) $summary['lunch'])" />
        <x-admin.kpi-card label="Diner" :value="number_format((int) $summary['dinner'])" />
    </div>

    <div class="card" style="margin-bottom: 1rem;">
        <div class="panel-header">
            <h2>Graphes statistiques universels</h2>
        </div>

        <style>
            .graph-shell {
                display: grid;
                gap: 1rem;
            }

            .graph-card {
                border: 1px solid #dbe8f8;
                border-radius: .9rem;
                padding: .9rem;
                background: linear-gradient(180deg, #fbfdff, #f5f9ff);
            }

            .graph-title {
                margin: 0;
                font-size: 1rem;
                font-weight: 800;
                color: #183e6d;
            }

            .graph-subtitle {
                margin: .18rem 0 .75rem;
                font-size: .82rem;
                color: #6b7f95;
            }

            .graph-row {
                display: grid;
                grid-template-columns: 120px 42px 42px minmax(0, 1fr);
                gap: .5rem;
                align-items: center;
                padding: .45rem 0;
                border-top: 1px solid #e3edf9;
            }

            .graph-row:first-child {
                border-top: 0;
            }

            .graph-label {
                font-size: .84rem;
                font-weight: 700;
                color: #23466d;
            }

            .graph-value {
                text-align: right;
                font-size: .82rem;
                color: #54708d;
                font-weight: 700;
            }

            .graph-track {
                height: 12px;
                border-radius: 999px;
                background: #e7eff9;
                overflow: hidden;
                display: flex;
                gap: 2px;
            }

            .graph-fill {
                height: 100%;
                border-radius: 999px;
            }

            .graph-fill-blue {
                background: linear-gradient(90deg, #1e5bb9, #5a8ff0);
            }

            .graph-fill-green {
                background: linear-gradient(90deg, #12845b, #3db37e);
            }

            .graph-fill-cyan {
                background: linear-gradient(90deg, #2f6fcf, #69a0ff);
            }

            .graph-legend {
                display: flex;
                flex-wrap: wrap;
                gap: .75rem;
                margin-bottom: .7rem;
                font-size: .78rem;
                color: #4d6480;
            }

            .graph-legend-item {
                display: inline-flex;
                align-items: center;
                gap: .35rem;
            }

            .graph-swatch {
                width: .7rem;
                height: .7rem;
                border-radius: 999px;
            }
        </style>

        <div class="graph-shell">
            <div class="graph-card">
                <h3 class="graph-title">Tendance journaliere</h3>
                <p class="graph-subtitle">Entrées et repas sur les 12 dernières dates du filtre courant.</p>
                <div class="graph-legend">
                    <span class="graph-legend-item"><span class="graph-swatch" style="background:#1e5bb9"></span>Entrées</span>
                    <span class="graph-legend-item"><span class="graph-swatch" style="background:#12845b"></span>Repas</span>
                </div>

                @forelse($dailyGraphRows as $row)
                    <div class="graph-row">
                        <div class="graph-label">{{ $row['label'] }}</div>
                        <div class="graph-value">{{ $row['entries'] }}</div>
                        <div class="graph-value">{{ $row['meals'] }}</div>
                        <div class="graph-track" aria-label="Graphique journalier">
                            <div class="graph-fill graph-fill-blue" style="width: <?php echo $row['entry_pct']; ?>%;"></div>
                            <div class="graph-fill graph-fill-green" style="width: <?php echo $row['meal_pct']; ?>%; opacity:.55;"></div>
                        </div>
                    </div>
                @empty
                    <div class="muted">Aucune donnée pour tracer un graphe.</div>
                @endforelse
            </div>

            <div class="graph-card">
                <h3 class="graph-title">Répartition des repas</h3>
                <p class="graph-subtitle">Volume global par type de repas.</p>
                <div class="graph-legend">
                    <span class="graph-legend-item"><span class="graph-swatch" style="background:#2f6fcf"></span>Volume</span>
                </div>

                @foreach($mealGraphRows as $item)
                    <div class="graph-row">
                        <div class="graph-label">{{ $item['label'] }}</div>
                        <div class="graph-value">{{ $item['value'] }}</div>
                        <div class="graph-value">{{ $item['pct'] }}%</div>
                        <div class="graph-track">
                            <div class="graph-fill graph-fill-cyan" style="width: <?php echo $item['pct']; ?>%;"></div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>

    <div class="card">
        <div class="panel-header">
            <h2 style="margin:0;">Historique Extra</h2>
            <span class="muted">{{ $periodLabel }}</span>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Heure creation</th>
                    <th>Nom</th>
                    <th>Compagnie</th>
                    <th>RiG</th>
                    <th>Repas jour (quantité)</th>
                    <th>Total repas</th>
                </tr>
            </thead>
            <tbody id="extra-history-body">
                @forelse($entries as $entry)
                    @php($entryDate = optional($entry->entry_date)->format('Y-m-d'))
                    @php($rowSearch = mb_strtolower(trim(($entry->full_name ?? '') . ' ' . ($entry->rig_company ?? '') . ' ' . ($entry->position ?? '') . ' ' . ($entry->external_id ?? ''))))
                    @php($flags = $entry->meal_flags ?? ['breakfast' => 0, 'lunch' => 0, 'dinner' => 0])
                    <tr data-extra-row="1" data-row-search="{{ e($rowSearch) }}">
                        <td>{{ $entryDate ?: '-' }}</td>
                        <td>{{ optional($entry->created_at)->format('H:i:s') ?: '-' }}</td>
                        <td>{{ $entry->full_name }}</td>
                        <td>{{ $entry->rig_company ?: '-' }}</td>
                        <td>{{ $entry->position ?: '-' }}</td>
                        <td>
                            {{ $mealLabels['breakfast'] }}={{ $flags['breakfast'] }},
                            {{ $mealLabels['lunch'] }}={{ $flags['lunch'] }},
                            {{ $mealLabels['dinner'] }}={{ $flags['dinner'] }}
                        </td>
                        <td>{{ $entry->consumed_meals_count }}</td>
                    </tr>
                @empty
                    <tr>
                            <td colspan="7">Aucune entree Extra pour ces filtres.</td>
                    </tr>
                @endforelse
                    <tr id="extra-no-results-row" hidden>
                        <td colspan="7">Aucun resultat pour cette recherche.</td>
                    </tr>
            </tbody>
        </table>

        <div style="margin-top: .8rem;">{{ $entries->links() }}</div>
    </div>

    <div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,1fr); margin-top:1rem;">
        <div class="card">
            <div class="panel-header">
                <h3 style="margin:0;">Top compagnies (Extra)</h3>
                <span class="muted">Top 10</span>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>Compagnie</th>
                        <th>Entrees</th>
                        <th>Avec repas</th>
                        <th>Total repas</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($topCompanies as $row)
                        <tr>
                            <td>{{ $row['label'] }}</td>
                            <td>{{ $row['entries'] }}</td>
                            <td>{{ $row['with_meal'] }}</td>
                            <td>{{ $row['total_meals'] }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="4">Aucune donnee.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="card">
            <div class="panel-header">
                <h3 style="margin:0;">Top rigs (Extra)</h3>
                <span class="muted">Top 10</span>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>Rig</th>
                        <th>Entrees</th>
                        <th>Avec repas</th>
                        <th>Total repas</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($topRigs as $row)
                        <tr>
                            <td>{{ $row['label'] }}</td>
                            <td>{{ $row['entries'] }}</td>
                            <td>{{ $row['with_meal'] }}</td>
                            <td>{{ $row['total_meals'] }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="4">Aucune donnee.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <script>
        (function () {
            var searchInput = document.getElementById('extra-realtime-search');
            var tableBody = document.getElementById('extra-history-body');
            var noResultsRow = document.getElementById('extra-no-results-row');

            if (!searchInput || !tableBody) {
                return;
            }

            var rows = Array.prototype.slice.call(tableBody.querySelectorAll('tr[data-extra-row="1"]'));

            function normalize(value) {
                return (value || '')
                    .toString()
                    .toLowerCase()
                    .normalize('NFD')
                    .replace(/[\u0300-\u036f]/g, '')
                    .trim();
            }

            function applyFilter() {
                var term = normalize(searchInput.value);
                var visibleCount = 0;

                rows.forEach(function (row) {
                    var haystack = normalize(row.getAttribute('data-row-search'));
                    var isVisible = term === '' || haystack.indexOf(term) !== -1;
                    row.hidden = !isVisible;
                    if (isVisible) {
                        visibleCount += 1;
                    }
                });

                if (noResultsRow) {
                    noResultsRow.hidden = visibleCount !== 0;
                }
            }

            searchInput.addEventListener('input', applyFilter);
            applyFilter();
        })();
    </script>
@endsection
