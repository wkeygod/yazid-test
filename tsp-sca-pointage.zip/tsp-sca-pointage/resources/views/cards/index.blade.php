@extends('layouts.app')

@section('title', 'Cartes')
@section('topbar_actions')
    <a class="btn" href="{{ route('cards.create') }}">Nouvelle carte</a>
@endsection

@section('content')
    <x-admin.panel>
        <x-admin.page-header title="Parc cartes" subtitle="Cycle de vie, assignation et suivi" />

        <x-admin.filter-bar action="{{ route('cards.index') }}" style="margin-bottom:.9rem;">
            <div>
                <label>Statut</label>
                <select name="status">
                    <option value="">Tous les statuts</option>
                    @foreach($statuses as $statusOption)
                        <option value="{{ $statusOption }}" {{ $statusOption === $status ? 'selected' : '' }}>{{ ucfirst($statusOption) }}</option>
                    @endforeach
                </select>
            </div>
            <div>
                <label>Employe assigne</label>
                <select name="employee_id">
                    <option value="">Tous</option>
                    @foreach($employees as $employee)
                        <option value="{{ $employee->id }}" {{ (int) $employeeId === (int) $employee->id ? 'selected' : '' }}>
                            {{ $employee->employee_no }} - {{ $employee->first_name }} {{ $employee->last_name }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div>
                <label>Etat d'assignation</label>
                <select name="assignment_state">
                    <option value="">Tous</option>
                    <option value="assigned" {{ $assignmentState === 'assigned' ? 'selected' : '' }}>Assignee</option>
                    <option value="unassigned" {{ $assignmentState === 'unassigned' ? 'selected' : '' }}>Non assignee</option>
                </select>
            </div>
            <div class="actions" style="align-self: end;">
                <button class="btn" type="submit">Filtrer</button>
                <a class="btn" style="background:#5d708a;" href="{{ route('cards.index') }}"
                    data-confirm-url="{{ route('cards.index') }}"
                    data-confirm-only-when-active="true"
                    data-confirm-active-params="status,employee_id,assignment_state"
                    data-confirm-type="warning"
                    data-confirm-title="Réinitialiser les filtres"
                    data-confirm-message="Réinitialiser tous les filtres et revenir à la vue par défaut ?"
                    data-confirm-cancel-label="Annuler"
                    data-confirm-approve-label="Réinitialiser">Réinitialiser</a>
            </div>
        </x-admin.filter-bar>

        <x-admin.data-table class="table-sticky table-compact">
            <thead>
                <tr>
                    <th>UID</th>
                    <th>Employe</th>
                    <th>Assignation</th>
                    <th>Solde</th>
                    <th class="status-col">Statut</th>
                    <th class="actions-col">Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($cards as $card)
                    @php
                        $statusTone = match($card->status) {
                            \App\Models\Card::STATUS_ACTIVE => 'active',
                            \App\Models\Card::STATUS_BLOCKED, \App\Models\Card::STATUS_LOST => 'warning',
                            \App\Models\Card::STATUS_REPLACED => 'info',
                            default => 'inactive',
                        };
                    @endphp
                    <tr>
                        <td>{{ $card->uid }}</td>
                        <td>{{ trim(($card->employee?->first_name ?? '') . ' ' . ($card->employee?->last_name ?? '')) ?: '-' }}</td>
                        <td>
                            <x-admin.badge :tone="$card->assigned_employee_id ? 'active' : 'inactive'">
                                {{ $card->assigned_employee_id ? 'Assignee' : 'Non assignee' }}
                            </x-admin.badge>
                        </td>
                        <td>{{ number_format((float) $card->balance, 2) }}</td>
                        <td class="status-col">
                            <x-admin.badge :tone="$statusTone">
                                {{ strtoupper(str_replace('_', ' ', $card->status)) }}
                            </x-admin.badge>
                        </td>
                        <td class="actions-col">
                            <x-admin.table-actions>
                            <a class="btn-action" href="{{ route('cards.show', $card) }}">Details</a>
                            <a class="btn-action" href="{{ route('cards.edit', $card) }}">Modifier</a>
                            <a class="btn-action btn-action-info" href="{{ route('meal-logs.index', ['card_id' => $card->id]) }}">Scans</a>
                            <form class="inline" method="POST" action="{{ route('cards.destroy', $card) }}"
                                  data-confirm="true"
                                  data-confirm-type="danger"
                                  data-confirm-title="Supprimer carte"
                                  data-confirm-message="Confirmer la suppression de cette carte ? Cette action est irreversible.">
                                @csrf
                                @method('DELETE')
                                <button class="btn-action btn-action-danger" type="submit">Supprimer</button>
                            </form>
                            </x-admin.table-actions>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6">
                            <x-admin.empty-state
                                title="Aucune carte trouvee"
                                message="Ajustez les filtres ou ajoutez une nouvelle carte pour commencer." />
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </x-admin.data-table>

        <div class="pager">{{ $cards->links() }}</div>
    </x-admin.panel>
@endsection
