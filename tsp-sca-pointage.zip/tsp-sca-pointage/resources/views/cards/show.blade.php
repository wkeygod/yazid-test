@extends('layouts.app')

@section('title', 'Detail carte')
@section('topbar_actions')
    <a class="btn" href="{{ route('cards.edit', $card) }}">Modifier</a>
    <a class="btn btn-secondary" href="{{ route('cards.index') }}">Retour liste</a>
@endsection

@section('content')
    @php
        $statusTone = match($card->status) {
            \App\Models\Card::STATUS_ACTIVE => 'active',
            \App\Models\Card::STATUS_BLOCKED, \App\Models\Card::STATUS_LOST => 'warning',
            \App\Models\Card::STATUS_REPLACED => 'info',
            default => 'inactive',
        };

        $cardHolderName = $card->employee
            ? trim(($card->employee->first_name ?? '') . ' ' . ($card->employee->last_name ?? ''))
            : 'Unassigned employee';

        $currentAssignment = $card->assignments
            ->sortByDesc(fn ($item) => optional($item->assigned_at)?->timestamp ?? 0)
            ->first(fn ($item) => is_null($item->unassigned_at));
    @endphp

    <x-admin.page-header title="Fiche carte" :subtitle="'UID: ' . $card->uid" />

    <div class="grid" style="grid-template-columns: minmax(0, 1fr) 360px; align-items:start; gap:1rem;">
        <div style="min-width:0;">
            <div class="card" style="background:linear-gradient(120deg, #e6f0ff, #f7fbff); border-color:#c9dbf3;">
                <div style="display:flex; align-items:flex-start; justify-content:space-between; gap:1rem; flex-wrap:wrap;">
                    <div>
                        <div style="font-size:.8rem; letter-spacing:.6px; color:#48607d; text-transform:uppercase; font-weight:700;">UID Carte</div>
                        <div style="font-size:1.85rem; font-weight:800; color:#14345c; line-height:1.25; margin-top:.2rem;">{{ $card->uid }}</div>
                    </div>
                    <div>
                        <x-admin.badge :tone="$statusTone">{{ strtoupper(str_replace('_', ' ', $card->status)) }}</x-admin.badge>
                    </div>
                </div>
            </div>

            <div class="card">
                <h2 style="margin-top:0;">Informations actuelles</h2>
                <x-admin.data-table>
                    <tbody>
                    <tr>
                        <th style="width:220px;">Employe assigne</th>
                        <td>
                            @if($card->employee)
                                {{ $card->employee->employee_no }} - {{ $card->employee->first_name }} {{ $card->employee->last_name }}
                            @else
                                Non assignee
                            @endif
                        </td>
                    </tr>
                    <tr>
                        <th>Date d'assignation</th>
                        <td>{{ optional($currentAssignment?->assigned_at)->format('Y-m-d H:i') ?: '-' }}</td>
                    </tr>
                    <tr>
                        <th>Date d'emission</th>
                        <td>{{ optional($card->issued_at)->format('Y-m-d') ?: '-' }}</td>
                    </tr>
                    @if($card->status === \App\Models\Card::STATUS_BLOCKED)
                        <tr>
                            <th>Date blocage</th>
                            <td>{{ optional($card->blocked_at)->format('Y-m-d H:i') ?: '-' }}</td>
                        </tr>
                        <tr>
                            <th>Motif blocage</th>
                            <td>{{ $card->block_reason ?: '-' }}</td>
                        </tr>
                    @endif
                    @if($card->status === \App\Models\Card::STATUS_REPLACED && $card->replacedByCard)
                        <tr>
                            <th>Carte de remplacement</th>
                            <td>
                                <a href="{{ route('cards.show', $card->replacedByCard) }}" style="font-weight:700; color:#1e5bb9; text-decoration:none;">
                                    {{ $card->replacedByCard->uid }}
                                </a>
                            </td>
                        </tr>
                    @endif
                    </tbody>
                </x-admin.data-table>
            </div>

            <div class="card">
                <h2 style="margin-top:0;">Derniers logs repas de cette carte</h2>
                @php
                    $latestLogs = $card->mealLogs->take(10);
                @endphp
                @if($latestLogs->isEmpty())
                    <x-admin.empty-state title="Aucun log disponible" message="Cette carte n'a pas encore d'historique de passage." />
                @else
                    <x-admin.data-table>
                        <thead>
                        <tr>
                            <th>Date</th>
                            <th>Statut</th>
                            <th>Employe</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($latestLogs as $log)
                            <tr>
                                <td>{{ optional($log->logged_at)->format('Y-m-d H:i') ?: '-' }}</td>
                                <td>{{ strtoupper($log->status ?? '-') }}</td>
                                <td>{{ $log->employee ? ($log->employee->employee_no . ' - ' . $log->employee->first_name . ' ' . $log->employee->last_name) : '-' }}</td>
                            </tr>
                        @endforeach
                        </tbody>
                    </x-admin.data-table>
                @endif
            </div>
        </div>

        <aside class="card" style="position:sticky; top:82px;">
            <h2 style="margin-top:0;">Actions admin</h2>

            @if($card->status !== \App\Models\Card::STATUS_BLOCKED)
                <form method="POST" action="{{ route('cards.block', $card) }}" style="margin-bottom:1rem;"
                      data-confirm="true"
                      data-confirm-type="danger"
                                            data-confirm-title="Block card: {{ $card->uid }} - {{ $cardHolderName }}"
                                            data-confirm-message="Are you sure you want to block this card? The employee will not be able to access the restaurant.">
                    @csrf
                    @method('PATCH')
                    <label>Bloquer la carte</label>
                                        <input type="text" name="block_reason" placeholder="Motif de blocage (optionnel)">
                    <button class="btn" type="submit" style="width:100%; background:#d9480f;">Bloquer</button>
                </form>
            @endif

            @if($card->status === \App\Models\Card::STATUS_BLOCKED)
                <form method="POST" action="{{ route('cards.unblock', $card) }}" style="margin-bottom:1rem;"
                      data-confirm="true"
                      data-confirm-type="warning"
                      data-confirm-title="Debloquer carte"
                      data-confirm-message="Confirmer le debloquage de cette carte ?">
                    @csrf
                    @method('PATCH')
                    <button class="btn" type="submit" style="width:100%; background:#2b8a3e;">Debloquer</button>
                </form>
            @endif

            @if($card->status !== \App\Models\Card::STATUS_LOST)
                <form method="POST" action="{{ route('cards.mark-lost', $card) }}" style="margin-bottom:1rem;"
                      data-confirm="true"
                      data-confirm-type="danger"
                      data-confirm-title="Marquer carte perdue"
                      data-confirm-message="Confirmer le passage de cette carte au statut perdue ?">
                    @csrf
                    @method('PATCH')
                    <label>Marquer perdue</label>
                    <input type="text" name="block_reason" placeholder="Motif de perte" required>
                    <button class="btn" type="submit" style="width:100%; background:#c53030;">Marquer perdue</button>
                </form>
            @endif

            <form method="POST" action="{{ route('cards.replace', $card) }}" style="margin-bottom:1rem;"
                  data-confirm="true"
                  data-confirm-type="warning"
                data-confirm-title="Replace card: {{ $card->uid }}"
                data-confirm-message="Replace this card with a new one?"
                data-confirm-cancel-label="Cancel"
                data-confirm-approve-label="Confirm">
                @csrf
                <label>Remplacer la carte</label>
                <input type="text" name="new_uid" placeholder="Nouveau UID" required>
                <select name="employee_id">
                    <option value="">Employe actuel</option>
                    @foreach($employees as $employee)
                        <option value="{{ $employee->id }}" {{ (string) $card->assigned_employee_id === (string) $employee->id ? 'selected' : '' }}>
                            {{ $employee->employee_no }} - {{ $employee->first_name }} {{ $employee->last_name }}
                        </option>
                    @endforeach
                </select>
                <input type="text" name="reason" placeholder="Raison remplacement (optionnel)">
                <button class="btn" type="submit" style="width:100%; background:#5f3dc4;">Remplacer</button>
            </form>

            <form method="POST" action="{{ route('cards.reassign', $card) }}" style="margin-bottom:1rem;"
                  data-confirm="true"
                  data-confirm-type="info"
                  data-confirm-title="Reassigner carte"
                  data-confirm-message="Confirmer la reassignment de cette carte ?">
                @csrf
                @method('PATCH')
                <label>Reassigner la carte</label>
                <select name="employee_id" required>
                    <option value="">Choisir un employe</option>
                    @foreach($employees as $employee)
                        <option value="{{ $employee->id }}" {{ (string) $card->assigned_employee_id === (string) $employee->id ? 'selected' : '' }}>
                            {{ $employee->employee_no }} - {{ $employee->first_name }} {{ $employee->last_name }}
                        </option>
                    @endforeach
                </select>
                <button class="btn" type="submit" style="width:100%; background:#2c6cb0;">Reassigner</button>
            </form>

            @if($card->employee)
                <form method="POST" action="{{ route('cards.detach', $card) }}"
                      data-confirm="true"
                      data-confirm-type="warning"
                      data-confirm-title="Detacher carte"
                      data-confirm-message="Confirmer le detachement de cette carte ?">
                    @csrf
                    @method('PATCH')
                    <button class="btn" type="submit" style="width:100%; background:#6b7280;">Detacher</button>
                </form>
            @endif
        </aside>
    </div>

    <div class="card">
        <h2 style="margin-top:0;">Journal d'audit des actions admin</h2>
        @if($auditLogs->isEmpty())
            <x-admin.empty-state title="Aucune action admin" message="Aucun evenement de cycle de vie n'a encore ete enregistre." />
        @else
            <x-admin.data-table>
                <thead>
                <tr>
                    <th>Date</th>
                    <th>Action</th>
                    <th>Admin</th>
                    <th>Motif</th>
                </tr>
                </thead>
                <tbody>
                @foreach($auditLogs as $entry)
                    <tr>
                        <td>{{ optional($entry->performed_at)->format('Y-m-d H:i:s') ?: '-' }}</td>
                        <td>{{ $entry->action_type }}</td>
                        <td>{{ $entry->performedBy?->name ?? '-' }}</td>
                        <td>{{ $entry->reason ?: '-' }}</td>
                    </tr>
                @endforeach
                </tbody>
            </x-admin.data-table>
        @endif
    </div>
@endsection
