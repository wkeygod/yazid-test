@extends('layouts.app')

@section('title', 'Nouvelle carte')
@section('topbar_actions')
    <a class="btn btn-secondary" href="{{ route('cards.index') }}">Retour liste</a>
@endsection

@section('content')
    <x-admin.panel>
        <x-admin.page-header title="Creer une carte" subtitle="Associez une carte NFC a un employe actif." />
        <form method="POST" action="{{ route('cards.store') }}" class="ds-form" novalidate>
            @csrf

            <section class="ds-form-section" aria-labelledby="card-main-title">
                <h3 id="card-main-title" class="ds-form-section-title">Informations principales</h3>
                <p class="ds-form-section-subtitle">Affectation de la carte et parametres de base.</p>

                <div class="grid grid-2">
                    <div class="ds-field">
                        <label for="employee_id">Employe</label>
                        <select id="employee_id" name="employee_id" required autofocus
                                @error('employee_id') aria-invalid="true" aria-describedby="employee_id_error" class="input-error" @enderror>
                            <option value="">Choisir...</option>
                            @foreach($employees as $employee)
                                <option value="{{ $employee->id }}" {{ (string) old('employee_id', $selectedEmployeeId ?? '') === (string) $employee->id ? 'selected' : '' }}>
                                    {{ $employee->employee_no }} - {{ $employee->first_name }} {{ $employee->last_name }}
                                </option>
                            @endforeach
                        </select>
                        @error('employee_id')<p id="employee_id_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>

                    <div class="ds-field">
                        <label for="uid">UID carte</label>
                        <input id="uid" type="text" name="uid" value="{{ old('uid') }}" required
                               @error('uid') aria-invalid="true" aria-describedby="uid_error" class="input-error" @enderror>
                        @error('uid')<p id="uid_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>

                    <div class="ds-field">
                        <label for="balance">Solde</label>
                        <input id="balance" type="number" min="0" step="0.01" name="balance" value="{{ old('balance', '0') }}" required
                               @error('balance') aria-invalid="true" aria-describedby="balance_error" class="input-error" @enderror>
                        @error('balance')<p id="balance_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>

                    <div class="ds-field">
                        <label for="issued_at">Date emission</label>
                        <input id="issued_at" type="date" name="issued_at" value="{{ old('issued_at') }}"
                               @error('issued_at') aria-invalid="true" aria-describedby="issued_at_error" class="input-error" @enderror>
                        @error('issued_at')<p id="issued_at_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>
                </div>
            </section>

            <section class="ds-form-section" aria-labelledby="card-advanced-title">
                <h3 id="card-advanced-title" class="ds-form-section-title">Champs avances</h3>
                <p class="ds-form-section-subtitle">Utiliser ces champs uniquement pour les cas de blocage ou de suivi administratif.</p>

                <div class="grid grid-2">
                    <div class="ds-field">
                        <label for="status">Statut</label>
                        <select id="status" name="status" required
                                @error('status') aria-invalid="true" aria-describedby="status_error" class="input-error" @enderror>
                            @foreach($statuses as $statusOption)
                                <option value="{{ $statusOption }}" {{ old('status', 'active') === $statusOption ? 'selected' : '' }}>{{ ucfirst($statusOption) }}</option>
                            @endforeach
                        </select>
                        @error('status')<p id="status_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>

                    <div class="ds-field">
                        <label for="blocked_at">Date blocage</label>
                        <input id="blocked_at" type="datetime-local" name="blocked_at" value="{{ old('blocked_at') }}"
                               @error('blocked_at') aria-invalid="true" aria-describedby="blocked_at_error" class="input-error" @enderror>
                        @error('blocked_at')<p id="blocked_at_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>

                    <div class="ds-field">
                        <label for="block_reason">Motif blocage</label>
                        <input id="block_reason" type="text" name="block_reason" value="{{ old('block_reason') }}"
                               @error('block_reason') aria-invalid="true" aria-describedby="block_reason_error" class="input-error" @enderror>
                        @error('block_reason')<p id="block_reason_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>
                </div>

                <div class="ds-field">
                    <label for="notes">Notes</label>
                    <textarea id="notes" name="notes" rows="4"
                              @error('notes') aria-invalid="true" aria-describedby="notes_error" class="input-error" @enderror>{{ old('notes') }}</textarea>
                    @error('notes')<p id="notes_error" class="ds-field-error">{{ $message }}</p>@enderror
                </div>
            </section>

            <div class="ds-form-actions">
                <a class="btn btn-secondary" href="{{ route('cards.index') }}">Annuler</a>
                <button class="btn" type="submit">Enregistrer</button>
            </div>
        </form>
    </x-admin.panel>
@endsection
