<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kiosk SCA - Extra</title>
    <style>
        :root {
            --bg: #ecf3ff;
            --panel: #ffffff;
            --text: #12253f;
            --muted: #5a6f8d;
            --line: #d6e3f6;
            --primary: #11669c;
            --primary-2: #1a79b8;
            --ok-bg: #e4f8ec;
            --ok-text: #125a32;
            --err-bg: #fff2f2;
            --err-text: #7f1d1d;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: "Avenir Next", "Nunito Sans", "Segoe UI", sans-serif;
            color: var(--text);
            background:
                radial-gradient(circle at 2% 0%, #dce9ff 0%, transparent 32%),
                radial-gradient(circle at 92% 8%, #d7e7ff 0%, transparent 36%),
                linear-gradient(180deg, #f8fbff 0%, var(--bg) 100%);
            overflow-x: hidden;
        }

        .kiosk-shell {
            min-height: 100vh;
            display: grid;
            grid-template-rows: auto auto 1fr;
        }

        .kiosk-header {
            padding: 1rem 1.4rem;
            color: #fff;
            background: linear-gradient(120deg, var(--primary), var(--primary-2));
            box-shadow: 0 10px 26px rgba(31, 95, 191, 0.3);
            font-weight: 700;
            font-size: 1.15rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: .7rem;
            animation: headerSlide .45s ease;
        }

        .kiosk-header-right {
            display: inline-flex;
            align-items: center;
            gap: .5rem;
        }

        .logout-btn {
            border: 1px solid rgba(255, 255, 255, 0.45);
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.12);
            color: #fff;
            font-weight: 700;
            padding: .42rem .78rem;
            text-decoration: none;
            cursor: pointer;
        }

        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.2);
        }

        .kiosk-logo {
            height: 2rem;
            width: auto;
            display: block;
            background: rgba(255, 255, 255, 0.14);
            border-radius: .5rem;
            padding: .12rem;
        }

        /* ── Apple Segmented Control ── */

        .kiosk-brand {
            display: inline-flex;
            align-items: center;
            gap: .7rem;
            color: inherit;
            text-decoration: none;
        }

        .kiosk-nav {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: .45rem 1.2rem;
            background: rgba(255, 255, 255, 0.88);
            border-bottom: 1px solid rgba(190, 213, 242, 0.6);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            animation: navFade .5s ease;
            position: sticky;
            top: 0;
            z-index: 15;
        }

        .kiosk-nav-segment {
            position: relative;
            display: inline-flex;
            align-items: center;
            background: rgba(116, 150, 195, 0.14);
            border-radius: 999px;
            padding: 3px;
            gap: 0;
            box-shadow:
                inset 0 1px 3px rgba(20, 55, 105, 0.12),
                0 1px 2px rgba(255,255,255,0.9);
        }

        .kiosk-nav-link {
            position: relative;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            height: 2rem;
            line-height: 1;
            font-size: .875rem;
            font-weight: 600;
            text-decoration: none;
            color: rgba(30, 58, 100, 0.72);
            padding: 0 1.1rem;
            border-radius: 999px;
            white-space: nowrap;
            z-index: 1;
            transition:
                color .22s ease,
                transform .14s ease;
            -webkit-user-select: none;
            user-select: none;
            letter-spacing: .01em;
        }

        .kiosk-nav-link:hover:not(.active) {
            color: rgba(30, 58, 100, 0.95);
            transform: none;
        }

        .kiosk-nav-link.active {
            color: #fff;
        }

        .kiosk-nav-link.active::before {
            content: '';
            position: absolute;
            inset: 0;
            border-radius: 999px;
            background: linear-gradient(135deg, #2464b4 0%, #3481d1 50%, #1f5ca8 100%);
            box-shadow:
                0 2px 8px rgba(36, 100, 180, 0.40),
                0 1px 2px rgba(36, 100, 180, 0.22),
                inset 0 1px 0 rgba(255,255,255,0.25);
            z-index: -1;
            animation: segmentSlideIn .22s cubic-bezier(.34,1.56,.64,1);
        }

        @keyframes segmentSlideIn {
            from { opacity: .55; transform: scaleX(.85) scaleY(.85); }
            to   { opacity: 1;  transform: scaleX(1)   scaleY(1); }
        }

        .kiosk-main {
            display: grid;
            gap: .9rem;
            padding: 1rem;
            animation: pageRise .46s ease;
        }

        .panel {
            background: var(--panel);
            border: 1px solid var(--line);
            border-radius: 1rem;
            padding: 1rem;
            box-shadow: 0 10px 24px rgba(18, 37, 63, 0.1);
            position: relative;
            overflow: hidden;
            transition: transform .18s ease, box-shadow .18s ease;
        }

        .panel::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, rgba(17, 102, 156, 0.75), rgba(26, 121, 184, 0.6), rgba(24, 168, 112, 0.45));
            pointer-events: none;
        }

        .panel:hover {
            transform: translateY(-2px);
            box-shadow: 0 16px 30px rgba(18, 37, 63, 0.14);
        }

        .title {
            margin: 0 0 .25rem;
            font-size: 1.2rem;
        }

        .muted {
            color: var(--muted);
            margin: 0 0 .8rem;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(140px, 1fr));
            gap: .6rem;
            align-items: end;
        }

        label {
            display: block;
            font-size: .9rem;
            font-weight: 600;
            margin-bottom: .35rem;
        }

        input, select {
            width: 100%;
            border: 1px solid #c8d8ee;
            border-radius: .6rem;
            padding: .55rem .65rem;
            font-size: .95rem;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border: 0;
            border-radius: .65rem;
            background: linear-gradient(135deg, var(--primary), var(--primary-2));
            color: #fff;
            font-weight: 700;
            padding: .72rem 1.1rem;
            min-height: 2.75rem;
            font-size: .98rem;
            letter-spacing: .15px;
            line-height: 1;
            text-decoration: none;
            text-shadow: 0 1px 0 rgba(9, 44, 76, 0.35);
            cursor: pointer;
            box-shadow: 0 8px 16px rgba(17, 102, 156, 0.24);
            transition: transform .15s ease, filter .15s ease;
        }

        .btn:hover {
            transform: translateY(-1px);
            filter: brightness(1.03);
        }

        .result {
            animation: pageRise .34s ease;
        }

        @keyframes headerSlide {
            from { opacity: 0; transform: translateY(-12px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes navFade {
            from { opacity: 0; transform: translateY(-6px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes pageRise {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation: none !important;
                transition: none !important;
            }
        }

        .result {
            margin-top: .7rem;
            border-radius: .65rem;
            border: 1px solid #cfe0f4;
            padding: .7rem .8rem;
            font-weight: 700;
        }

        .result-ok {
            background: var(--ok-bg);
            border-color: #b9e6cc;
            color: var(--ok-text);
        }

        .result-err {
            background: var(--err-bg);
            border-color: #f0c9c9;
            color: var(--err-text);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: .9rem;
        }

        th, td {
            text-align: left;
            padding: .55rem;
            border-bottom: 1px solid var(--line);
        }

        .pill {
            display: inline-block;
            border-radius: 999px;
            padding: .18rem .52rem;
            font-size: .75rem;
            font-weight: 700;
            text-transform: uppercase;
        }

        .pill-ok {
            background: #dff4e8;
            color: #0f5a32;
        }

        .pill-stop {
            background: #fde5e5;
            color: #7f1d1d;
        }

        .row-actions {
            display: grid;
            grid-template-columns: repeat(3, minmax(96px, 1fr));
            gap: .45rem;
            align-items: center;
        }

        .history-filter {
            display: grid;
            grid-template-columns: 1fr 1fr auto;
            gap: .55rem;
            margin-bottom: .7rem;
            align-items: end;
        }

        .history-filter-actions {
            display: flex;
            align-items: end;
            gap: .45rem;
        }

        .btn-filter {
            min-width: 130px;
            justify-content: center;
        }

        .meal-btn {
            width: 100%;
            border: 1px solid transparent;
            border-radius: .58rem;
            padding: .52rem .45rem;
            font-size: .8rem;
            font-weight: 800;
            cursor: pointer;
            text-transform: uppercase;
            letter-spacing: .2px;
        }

        .meal-btn-open {
            background: #dff4e8;
            color: #0f5a32;
            border-color: #b8e4cb;
        }

        .meal-btn-eaten {
            background: #fde5e5;
            color: #7f1d1d;
            border-color: #efbbbb;
        }

        .meal-qty-block {
            display: flex;
            flex-direction: column;
        }

        .meal-qty-form {
            display: none;
            gap: .35rem;
            margin-top: .35rem;
        }

        .meal-qty-form.visible {
            display: flex;
        }

        .meal-qty-input {
            width: 4.2rem;
            text-align: center;
        }

        .meal-qty-submit {
            padding: .4rem .6rem;
            min-height: unset;
            font-size: .8rem;
        }

        .suggestions-list {
            position: absolute;
            z-index: 20;
            top: 100%;
            left: 0;
            right: 0;
            margin: 2px 0 0;
            padding: .3rem;
            list-style: none;
            background: var(--panel);
            border: 1px solid var(--line);
            border-radius: .6rem;
            box-shadow: 0 12px 24px rgba(18, 37, 63, 0.16);
            max-height: 220px;
            overflow-y: auto;
        }

        .suggestions-list li {
            padding: .5rem .6rem;
            border-radius: .4rem;
            cursor: pointer;
            font-size: .9rem;
        }

        .suggestions-list li:hover,
        .suggestions-list li:focus {
            background: var(--bg);
        }

        @media (max-width: 980px) {
            .form-grid { grid-template-columns: 1fr; }
            .row-actions { grid-template-columns: 1fr; }
            .history-filter { grid-template-columns: 1fr; }
            .history-filter-actions { width: 100%; }
            .btn-filter { width: 100%; }
        }
    </style>
</head>
<body>
@php
    $authUser = auth()->user();
    $kioskHideNav = $authUser && !$authUser->is_admin && count($authUser->getAccessiblePages()) === 1;
@endphp

@php
    $extraResult = $extraResult ?? session('kiosk_extra_result');
    $mealRules = collect($mealRules ?? []);
@endphp

<div class="kiosk-shell">
    <header class="kiosk-header">
        <a class="kiosk-brand" href="{{ route('home') }}" aria-label="Retour à l'accueil">
            <img class="kiosk-logo" src="{{ asset('assets/logo-sca.JPG') }}" alt="SCA">
            <span>SCA • Pointage kiosque</span>
        </a>
        <div class="kiosk-header-right">
            <form method="POST" action="{{ route('logout') }}"
                  data-confirm="true"
                  data-confirm-type="warning"
                  data-confirm-title="Déconnexion"
                  data-confirm-message="Voulez-vous vraiment vous déconnecter ?"
                  data-confirm-approve-label="Oui, me déconnecter"
                  data-confirm-cancel-label="Annuler">
                @csrf
                <button type="submit" class="logout-btn">Déconnexion</button>
            </form>
        </div>
    </header>

    @if(!$kioskHideNav)
    <nav class="kiosk-nav" aria-label="Navigation kiosk">
        <div class="kiosk-nav-segment" role="tablist">
            <a class="kiosk-nav-link" href="{{ route('kiosk.index') }}" role="tab" aria-selected="false">Scan NFC</a>
            <a class="kiosk-nav-link" href="{{ route('kiosk.la-releve.page') }}" role="tab" aria-selected="false">La Relève</a>
            <a class="kiosk-nav-link active" href="{{ route('kiosk.extra.page') }}" role="tab" aria-selected="true">Extra</a>
        </div>
    </nav>
    @endif

    <main class="kiosk-main">
        <section class="panel">
            <h2 class="title">Entrée rapide Extra</h2>
            <p class="muted">Pour les personnes sans carte NFC et hors liste La Releve: enregistrez la personne, puis marquez son repas depuis les boutons de la ligne.</p>

            <form method="POST" action="{{ route('kiosk.extra.store') }}" class="form-grid">
                @csrf
                <div>
                    <label for="first_name">Nom</label>
                    <input id="first_name" type="text" name="first_name" value="{{ old('first_name') }}" required>
                </div>
                <div>
                    <label for="last_name">Prénom</label>
                    <input id="last_name" type="text" name="last_name" value="{{ old('last_name') }}" required>
                </div>
                <div>
                    <label for="company">Compagnie</label>
                    <input id="company" type="text" name="company" value="{{ old('company') }}" required>
                </div>
                <div>
                    <label for="rig">Rig</label>
                    <input id="rig" type="text" name="rig" value="{{ old('rig') }}" required>
                </div>
                <div>
                    <label for="room_number">Numéro de chambre</label>
                    <input id="room_number" type="text" name="room_number" value="{{ old('room_number') }}" placeholder="Optionnel">
                </div>
                <div>
                    <label for="selected_date">Date</label>
                    <input id="selected_date" name="selected_date" type="date" value="{{ old('selected_date', $selectedDate) }}" required>
                </div>
                <div>
                    <button class="btn" type="submit">Enregistrer personne</button>
                </div>
            </form>

            @if($errors->any())
                <div class="result result-err">
                    @foreach($errors->all() as $error)
                        <div>{{ $error }}</div>
                    @endforeach
                </div>
            @endif

            @if(is_array($extraResult))
                <div class="result {{ ($extraResult['status'] ?? '') === 'success' ? 'result-ok' : 'result-err' }}">
                    {{ $extraResult['message'] ?? '' }}
                </div>
            @endif
        </section>

        <section class="panel">
            <h3 class="title">Historique Extra du {{ $selectedDate }}</h3>
            <form method="GET" action="{{ route('kiosk.extra.page') }}" class="history-filter">
                <div style="position:relative;">
                    <label for="q">Recherche</label>
                    <input id="q" name="q" type="text" value="{{ $searchQuery }}" placeholder="Nom, compagnie, rig" autocomplete="off">
                    <ul id="q-suggestions" class="suggestions-list" hidden></ul>
                </div>
                <div>
                    <label for="list_date">Date</label>
                    <input id="list_date" name="list_date" type="date" value="{{ $selectedDate }}">
                </div>
                <div class="history-filter-actions">
                    <button class="btn btn-filter" type="submit">Filtrer</button>
                    <a class="btn btn-filter" href="{{ route('kiosk.extra.page') }}">Réinitialiser</a>
                </div>
            </form>

            <table>
                <thead>
                    <tr>
                        <th>Heure</th>
                        <th>Nom</th>
                        <th>Compagnie</th>
                        <th>Rig</th>
                        <th>Chambre</th>
                        <th>Repas jour (quantité)</th>
                        <th>Statut</th>
                        <th>Actions repas</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($entries as $entry)
                        @php
                            $entryDate = optional($entry->entry_date)->format('Y-m-d');
                            $quantities = [];
                            foreach ($mealRules as $mealRule) {
                                $matchingLogs = $entry->mealLogs->filter(function ($log) use ($mealRule) {
                                    if (!empty($log->meal_rule_id)) {
                                        return (int) $log->meal_rule_id === (int) $mealRule->id;
                                    }

                                    return trim((string) $log->meal_type) === trim((string) $mealRule->name);
                                });
                                $quantities[$mealRule->id] = (int) $matchingLogs->sum('quantity');
                            }
                            $total = array_sum($quantities);
                        @endphp
                        <tr>
                            <td>{{ optional($entry->created_at)->format('H:i:s') ?: '-' }}</td>
                            <td>{{ $entry->full_name }}</td>
                            <td>{{ $entry->rig_company ?: '-' }}</td>
                            <td>{{ $entry->position ?: '-' }}</td>
                            <td>{{ $entry->room_number ?: '-' }}</td>
                            <td>
                                {{ $mealRules->map(fn ($mealRule) => $mealRule->name . '=' . ($quantities[$mealRule->id] ?? 0))->implode(', ') }}
                            </td>
                            <td>
                                <span class="pill {{ $total > 0 ? 'pill-ok' : 'pill-stop' }}">
                                    {{ $total > 0 ? 'Repas enregistré' : 'Aucun repas' }}
                                </span>
                            </td>
                            <td>
                                <div class="row-actions">
                                    @foreach($mealRules as $mealRule)
                                        @php($qty = $quantities[$mealRule->id] ?? 0)
                                        <div class="meal-qty-block">
                                            <button
                                                type="button"
                                                class="meal-btn {{ $qty > 0 ? 'meal-btn-eaten' : 'meal-btn-open' }}"
                                                onclick="showExtraQtyForm(this)"
                                            >
                                                {{ $mealRule->name }}
                                                <small style="display:block; font-size:.72rem; opacity:.85; margin-top:.15rem;">{{ $qty }}</small>
                                            </button>
                                            <form method="POST" action="{{ route('kiosk.extra.toggle') }}" class="meal-qty-form">
                                                @csrf
                                                <input type="hidden" name="entry_id" value="{{ $entry->id }}">
                                                <input type="hidden" name="selected_date" value="{{ $entryDate }}">
                                                <input type="hidden" name="meal_rule_id" value="{{ $mealRule->id }}">
                                                <input type="hidden" name="notes" value="Action rapide bouton repas Extra">
                                                <input type="number" name="quantity" min="0" max="999" value="{{ $qty }}" class="meal-qty-input" aria-label="Quantité pour {{ $mealRule->name }}" required>
                                                <button type="submit" class="btn meal-qty-submit">OK</button>
                                            </form>
                                        </div>
                                    @endforeach
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="8">Aucune entrée Extra pour cette date.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>

            <div style="margin-top:.7rem;">{{ $entries->links() }}</div>
        </section>
    </main>
</div>

@include('partials.footer')

<script>
    function showExtraQtyForm(button) {
        var block = button.closest('.meal-qty-block');
        var form = block.querySelector('.meal-qty-form');
        button.style.display = 'none';
        form.classList.add('visible');
        var input = form.querySelector('.meal-qty-input');
        input.focus();
        input.select();
    }

    (function () {
        var input = document.getElementById('q');
        var list = document.getElementById('q-suggestions');
        if (!input || !list) {
            return;
        }

        var suggestUrl = '{{ route('kiosk.extra.suggest') }}';
        var debounceTimer = null;

        function renderSuggestions(names) {
            list.innerHTML = '';
            if (!names.length) {
                list.hidden = true;
                return;
            }

            names.forEach(function (name) {
                var item = document.createElement('li');
                item.textContent = name;
                item.tabIndex = 0;
                item.addEventListener('click', function () {
                    input.value = name;
                    list.hidden = true;
                    input.form.submit();
                });
                list.appendChild(item);
            });

            list.hidden = false;
        }

        input.addEventListener('input', function () {
            var term = input.value.trim();
            clearTimeout(debounceTimer);

            if (term.length < 2) {
                list.hidden = true;
                return;
            }

            debounceTimer = setTimeout(function () {
                fetch(suggestUrl + '?q=' + encodeURIComponent(term))
                    .then(function (response) { return response.json(); })
                    .then(function (data) { renderSuggestions(data.suggestions || []); })
                    .catch(function () { list.hidden = true; });
            }, 200);
        });

        document.addEventListener('click', function (event) {
            if (event.target !== input && !list.contains(event.target)) {
                list.hidden = true;
            }
        });
    })();
</script>
</body>
</html>
