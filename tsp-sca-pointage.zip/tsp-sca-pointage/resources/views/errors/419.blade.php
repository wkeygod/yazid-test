<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Session expirée - SCA</title>
    <style>
        :root {
            --bg: #edf4ff;
            --card: #ffffff;
            --line: #d6e3f6;
            --text: #12253f;
            --muted: #5a6f8d;
            --primary: #11669c;
            --primary-2: #1a79b8;
            --warn: #b86f18;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: "Avenir Next", "Nunito Sans", "Segoe UI", sans-serif;
            color: var(--text);
            background:
                radial-gradient(circle at 6% 2%, #dce9ff 0%, transparent 34%),
                radial-gradient(circle at 94% 8%, #d6e9ff 0%, transparent 36%),
                linear-gradient(180deg, #f9fbff 0%, var(--bg) 100%);
            display: grid;
            place-items: center;
            padding: 1.25rem;
        }

        .error-card {
            width: min(720px, 100%);
            background: var(--card);
            border: 1px solid var(--line);
            border-radius: 1.1rem;
            box-shadow: 0 18px 34px rgba(17, 57, 107, 0.15);
            overflow: hidden;
        }

        .error-top {
            padding: 1rem 1.2rem;
            background: linear-gradient(120deg, var(--primary), var(--primary-2));
            color: #fff;
            font-weight: 800;
            letter-spacing: .25px;
        }

        .error-body {
            padding: 1.2rem;
            display: grid;
            gap: .9rem;
        }

        .badge {
            display: inline-block;
            width: fit-content;
            border-radius: 999px;
            background: #fff4e6;
            color: var(--warn);
            border: 1px solid #f2d1a3;
            font-weight: 800;
            font-size: .8rem;
            padding: .2rem .6rem;
        }

        h1 {
            margin: 0;
            font-size: 1.35rem;
            line-height: 1.2;
        }

        p {
            margin: 0;
            color: var(--muted);
            line-height: 1.55;
        }

        .actions {
            display: flex;
            flex-wrap: wrap;
            gap: .6rem;
            margin-top: .25rem;
        }

        .btn {
            border: 0;
            border-radius: .7rem;
            padding: .72rem .95rem;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-2));
            color: #fff;
            box-shadow: 0 8px 18px rgba(17, 102, 156, 0.26);
        }

        .btn-ghost {
            background: #f3f8ff;
            color: #1f4f86;
            border: 1px solid #cdddf2;
        }

        .inline-form {
            margin: 0;
        }

        @media (max-width: 680px) {
            .actions {
                display: grid;
                grid-template-columns: 1fr;
            }

            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <main class="error-card" role="main">
        <div class="error-top">SCA - Restaurant Pointage</div>
        <section class="error-body">
            <span class="badge">Erreur 419</span>
            <h1>Session expirée (Page Expired)</h1>
            <p>
                Le token de sécurité de votre session a expiré ou la page est restée ouverte trop longtemps.
                Cela arrive souvent après inactivité, actualisation tardive, ou ancien formulaire.
            </p>
            <p>
                Vous pouvez vous déconnecter proprement puis revenir, ou revenir à la page précédente.
            </p>

            <div class="actions">
                @auth
                    <form class="inline-form" method="POST" action="{{ route('logout') }}">
                        @csrf
                        <button class="btn btn-primary" type="submit">Se déconnecter</button>
                    </form>
                @else
                    <a class="btn btn-primary" href="{{ route('login') }}">Se reconnecter</a>
                @endauth
                <button class="btn btn-ghost" type="button" onclick="window.history.back()">Retour</button>
            </div>
        </section>
    </main>
</body>
</html>
