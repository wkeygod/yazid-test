@extends('layouts.app')

@section('title', 'Tableau de bord')

@section('content')
<div class="card">
    <h1>Systeme Restaurant Employes</h1>
    <p class="muted">Application Laravel avec modules employes, cartes, regles repas, logs et page kiosk de pointage.</p>
</div>
@endsection
