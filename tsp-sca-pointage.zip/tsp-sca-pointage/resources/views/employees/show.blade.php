@extends('layouts.app')

@section('title', 'Fiche employe')
@section('topbar_actions')
    <a class="btn" href="{{ route('employees.edit', $employee) }}">Modifier</a>
    <a class="btn btn-secondary" href="{{ route('employees.index') }}">Retour liste</a>
@endsection

@section('content')
    @php
        $cardStatusTone = match($employee->card?->status) {
            \App\Models\Card::STATUS_ACTIVE => 'active',
            \App\Models\Card::STATUS_BLOCKED, \App\Models\Card::STATUS_LOST => 'warning',
            \App\Models\Card::STATUS_REPLACED => 'info',
            \App\Models\Card::STATUS_INACTIVE => 'inactive',
            default => 'inactive',
        };
    @endphp

    <x-admin.page-header
        title="Fiche employe"
        :subtitle="trim($employee->first_name . ' ' . $employee->last_name)"
    />

    <div class="grid" style="grid-template-columns:minmax(0, 1fr) 340px; align-items:start; gap:1rem;">
        <div style="min-width:0;">
            <div class="card" style="background:linear-gradient(120deg, #e6f0ff, #f7fbff); border-color:#c9dbf3;">
                <div class="panel-header" style="margin-bottom:0; align-items:flex-start;">
                    <div>
                        <div style="font-size:.82rem; letter-spacing:.6px; color:#48607d; text-transform:uppercase; font-weight:700;">Identite employe</div>
                        <h2 style="margin:.2rem 0 0;">{{ $employee->first_name }} {{ $employee->last_name }}</h2>
                        <div class="muted" style="margin-top:.2rem;">Profil employe NFC</div>
                    </div>
                    <x-admin.badge :tone="$employee->is_active ? 'active' : 'inactive'">
                        {{ $employee->is_active ? 'ACTIF' : 'INACTIF' }}
                    </x-admin.badge>
                </div>
            </div>

            <div class="card">
                <h3 style="margin-top:0;">Informations courantes</h3>
                <x-admin.data-table>
                    <tbody>
                    <tr>
                        <th style="width:220px;">Nom complet</th>
                        <td>{{ $employee->first_name }} {{ $employee->last_name }}</td>
                    </tr>
                    <tr>
                        <th>Poste</th>
                        <td>{{ $employee->position ?: '-' }}</td>
                    </tr>
                    <tr>
                        <th>RiG (entreprise)</th>
                        <td>{{ $employee->rig_company ?: '-' }}</td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td>{{ $employee->user?->email ?: '-' }}</td>
                    </tr>
                    <tr>
                        <th>Carte actuelle</th>
                        <td>
                            @if($employee->card)
                                <span style="font-weight:700;">{{ $employee->card->uid }}</span>
                                <x-admin.badge :tone="$cardStatusTone" style="margin-left:.4rem;">
                                    {{ strtoupper(str_replace('_', ' ', $employee->card->status)) }}
                                </x-admin.badge>
                            @else
                                <x-admin.badge tone="inactive">AUCUNE</x-admin.badge>
                            @endif
                        </td>
                    </tr>
                    <tr>
                        <th>Dernier repas</th>
                        <td>
                            @if($employee->lastMealLog)
                                {{ $employee->lastMealLog->logged_at?->format('Y-m-d H:i:s') ?: '-' }}
                            @else
                                -
                            @endif
                        </td>
                    </tr>
                    </tbody>
                </x-admin.data-table>
            </div>

            <div class="card">
                <div class="panel-header">
                    <h3 style="margin:0;">Logs repas recents</h3>
                    <a class="btn-action" style="background:#3f6bb5;" href="{{ route('meal-logs.index', ['employee_id' => $employee->id]) }}">Voir tous</a>
                </div>

                <x-admin.data-table>
                    <thead>
                        <tr>
                            <th>Date/Heure</th>
                            <th>Carte</th>
                            <th>Resultat</th>
                            <th>Motif</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($employee->mealLogs as $log)
                            <tr>
                                <td>{{ $log->logged_at?->format('Y-m-d H:i:s') ?: '-' }}</td>
                                <td>
                                    @if($log->card)
                                        {{ $log->card->uid }}
                                    @else
                                        {{ $log->card_uid ?: '-' }}
                                    @endif
                                </td>
                                <td>
                                    <x-admin.badge :tone="$log->status === 'approved' ? 'approved' : 'rejected'">
                                        {{ $log->status === 'approved' ? 'AUTORISE' : 'REFUSE' }}
                                    </x-admin.badge>
                                </td>
                                <td>{{ $log->reason ?: '-' }}</td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5">
                                    <x-admin.empty-state title="Aucun historique repas" message="Cet employe n'a pas encore de passages enregistres." />
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </x-admin.data-table>
            </div>

            <div class="card">
                <h3 style="margin-top:0;">Historique cartes</h3>
                @if($cardHistory->isEmpty())
                    <x-admin.empty-state title="Aucun historique carte" message="Aucune carte n'a encore ete attribuee ou remplacee." />
                @else
                    <x-admin.data-table>
                        <thead>
                            <tr>
                                <th>Carte</th>
                                <th>Assignee le</th>
                                <th>Retiree le</th>
                                <th>Par</th>
                                <th>Motif</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($cardHistory as $item)
                                <tr>
                                    <td>
                                        @if($item->card)
                                            {{ $item->card->uid }}
                                        @else
                                            -
                                        @endif
                                    </td>
                                    <td>{{ $item->assigned_at?->format('Y-m-d H:i:s') ?: '-' }}</td>
                                    <td>{{ $item->unassigned_at?->format('Y-m-d H:i:s') ?: '-' }}</td>
                                    <td>{{ $item->changedBy?->name ?: '-' }}</td>
                                    <td>{{ $item->change_reason ?: '-' }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </x-admin.data-table>
                @endif
            </div>
        </div>

        <aside class="card" style="position:sticky; top:82px;">
            <h3 style="margin-top:0;">Actions</h3>

            <div style="display:grid; gap:.55rem;">
                <a class="btn" href="{{ route('employees.edit', $employee) }}">Modifier employe</a>

                @if($employee->is_active)
                    <form method="POST" action="{{ route('employees.deactivate', $employee) }}"
                          data-confirm="true"
                          data-confirm-type="warning"
                          data-confirm-title="Desactiver employe : {{ $employee->first_name }} {{ $employee->last_name }}"
                          data-confirm-message="Confirmer la desactivation de cet employe ? Il ne pourra plus utiliser sa carte."
                          data-confirm-cancel-label="Annuler"
                          data-confirm-approve-label="Confirmer">
                        @csrf
                        @method('PATCH')
                        <input type="text" name="reason" placeholder="Motif desactivation (optionnel)">
                        <button class="btn" type="submit" style="width:100%; background:#566f8f;">
                            Desactiver
                        </button>
                    </form>
                @else
                    <form method="POST" action="{{ route('employees.reactivate', $employee) }}"
                          data-confirm="true"
                          data-confirm-type="info"
                          data-confirm-title="Reactiver employe"
                          data-confirm-message="Confirmer la reactivation de cet employe ?">
                        @csrf
                        @method('PATCH')
                        <input type="text" name="reason" placeholder="Motif reactivation (optionnel)">
                        <button class="btn" type="submit" style="width:100%; background:#2b8a3e;">
                            Reactiver
                        </button>
                    </form>
                @endif

                @if($employee->card)
                    <a class="btn" style="background:#1f8f4e;" href="{{ route('employees.edit', $employee) }}">Modifier UID NFC</a>
                @else
                    <a class="btn" style="background:#1f8f4e;" href="{{ route('employees.edit', $employee) }}">Assigner UID NFC</a>
                @endif

                @if($employee->card)
                    <form method="POST" action="{{ route('cards.block', $employee->card) }}"
                          data-confirm="true"
                          data-confirm-type="danger"
                          data-confirm-title="Bloquer carte"
                          data-confirm-message="Confirmer le blocage de la carte actuelle ?">
                        @csrf
                        @method('PATCH')
                        <input type="text" name="block_reason" placeholder="Motif blocage" required>
                        <button class="btn" type="submit" style="width:100%; background:#c53030;">Bloquer carte actuelle</button>
                    </form>

                    @if($employee->card->status === \App\Models\Card::STATUS_BLOCKED)
                        <form method="POST" action="{{ route('cards.unblock', $employee->card) }}"
                              data-confirm="true"
                              data-confirm-type="warning"
                              data-confirm-title="Debloquer carte"
                              data-confirm-message="Confirmer le debloquage de la carte actuelle ?">
                            @csrf
                            @method('PATCH')
                            <button class="btn" type="submit" style="width:100%; background:#2b8a3e;">Debloquer carte actuelle</button>
                        </form>
                    @endif

                    @if($employee->card->status !== \App\Models\Card::STATUS_LOST)
                        <form method="POST" action="{{ route('cards.mark-lost', $employee->card) }}"
                              data-confirm="true"
                              data-confirm-type="danger"
                              data-confirm-title="Marquer carte perdue"
                              data-confirm-message="Confirmer le passage de la carte au statut perdue ?">
                            @csrf
                            @method('PATCH')
                            <input type="text" name="block_reason" placeholder="Motif carte perdue" required>
                            <button class="btn" type="submit" style="width:100%; background:#8b1f1f;">Marquer carte perdue</button>
                        </form>
                    @endif

                    <form method="POST" action="{{ route('cards.replace', $employee->card) }}"
                          data-confirm="true"
                          data-confirm-type="warning"
                          data-confirm-title="Remplacer carte"
                          data-confirm-message="Confirmer le remplacement de la carte actuelle ?">
                        @csrf
                        <input type="text" name="new_uid" placeholder="Nouveau UID carte" required>
                        <input type="hidden" name="employee_id" value="{{ $employee->id }}">
                        <input type="text" name="reason" placeholder="Motif remplacement (optionnel)">
                        <button class="btn" type="submit" style="width:100%; background:#5f3dc4;">Remplacer carte</button>
                    </form>
                @endif

                <a class="btn" style="background:#3f6bb5;" href="{{ route('meal-logs.index', ['employee_id' => $employee->id]) }}">Voir tous les logs</a>
            </div>

            @if($availableCards->isNotEmpty())
                <hr>
                <h4 style="margin-top:0;">Assigner une carte disponible</h4>
                <form method="POST" action="{{ route('cards.reassign', $employee->card ?? $availableCards->first()) }}">
                    @csrf
                    @method('PATCH')
                    <label>Selection</label>
                    <select id="card_select_action" required>
                        @foreach($availableCards as $candidate)
                            <option value="{{ route('cards.reassign', $candidate) }}">{{ $candidate->uid }}</option>
                        @endforeach
                    </select>
                    <input type="hidden" name="employee_id" value="{{ $employee->id }}">
                    <button class="btn" type="submit" style="width:100%;">Assigner</button>
                </form>
                <script>
                    (function () {
                        var form = document.currentScript.previousElementSibling;
                        var select = document.getElementById('card_select_action');
                        if (form && select) {
                            form.addEventListener('submit', function () {
                                form.action = select.value;
                            });
                        }
                    })();
                </script>
            @endif
        </aside>
    </div>

    <div class="card">
        <h3 style="margin-top:0;">Journal d'audit des actions admin</h3>
        @if($auditLogs->isEmpty())
            <x-admin.empty-state title="Aucune action admin" message="Aucun evenement administratif n'a ete enregistre pour ce profil." />
        @else
            <x-admin.data-table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Action</th>
                        <th>Admin</th>
                        <th>Motif</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($auditLogs as $entry)
                        <tr>
                            <td>{{ optional($entry->performed_at)->format('Y-m-d H:i:s') ?: '-' }}</td>
                            <td>{{ $entry->action_type }}</td>
                            <td>{{ $entry->performedBy?->name ?? '-' }}</td>
                            <td>{{ $entry->reason ?: '-' }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </x-admin.data-table>
        @endif
    </div>
@endsection
