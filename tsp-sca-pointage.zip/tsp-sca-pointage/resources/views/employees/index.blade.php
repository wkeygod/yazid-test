@extends('layouts.app')

@section('title', 'Employes')
@section('topbar_actions')
    <a class="btn" href="{{ route('employees.create') }}">Nouvel employe</a>
@endsection

@section('content')
    <x-admin.panel>
        <x-admin.page-header title="Gestion des employes" subtitle="Recherche rapide et actions quotidiennes" />

        <x-admin.filter-bar action="{{ route('employees.index') }}" style="margin-bottom:.9rem;">
            <div>
                <label>Recherche (nom, poste, entreprise, UID NFC)</label>
                <input type="text" name="q" value="{{ $search }}" placeholder="Ex: Amina, Soudeur, Rig 17, 04A1B2C3D4">
            </div>
            <div>
                <label>Statut</label>
                <select name="status">
                    <option value="">Tous</option>
                    <option value="active" {{ $status === 'active' ? 'selected' : '' }}>Actifs</option>
                    <option value="inactive" {{ $status === 'inactive' ? 'selected' : '' }}>Inactifs</option>
                </select>
            </div>
            <div class="actions" style="align-self: end;">
                <button class="btn" type="submit">Filtrer</button>
                     <a class="btn btn-secondary" href="{{ route('employees.index') }}"
                         data-confirm-url="{{ route('employees.index') }}"
                         data-confirm-only-when-active="true"
                         data-confirm-active-params="q,status"
                         data-confirm-type="warning"
                         data-confirm-title="Réinitialiser les filtres"
                         data-confirm-message="Réinitialiser tous les filtres et revenir à la vue par défaut ?"
                         data-confirm-cancel-label="Annuler"
                         data-confirm-approve-label="Réinitialiser">Réinitialiser</a>
            </div>
        </x-admin.filter-bar>

        <x-admin.data-table class="table-sticky table-compact">
            <thead>
                <tr>
                    <th>Nom complet</th>
                    <th>Poste</th>
                    <th>RiG (entreprise)</th>
                    <th>UID NFC</th>
                    <th class="status-col">Statut</th>
                    <th>Dernier repas</th>
                    <th class="actions-col">Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($employees as $employee)
                    <tr>
                        <td>{{ $employee->first_name }} {{ $employee->last_name }}</td>
                        <td>{{ $employee->position ?: '-' }}</td>
                        <td>{{ $employee->rig_company ?: '-' }}</td>
                        <td>
                            @if($employee->card)
                                <x-admin.badge tone="active">{{ $employee->card->uid }}</x-admin.badge>
                            @else
                                <x-admin.badge tone="inactive">Aucune</x-admin.badge>
                            @endif
                        </td>
                        <td class="status-col">
                            <x-admin.badge :tone="$employee->is_active ? 'active' : 'inactive'">
                                {{ $employee->is_active ? 'ACTIF' : 'INACTIF' }}
                            </x-admin.badge>
                        </td>
                        <td>
                            @if($employee->lastMealLog)
                                <div>{{ $employee->lastMealLog->logged_at?->format('Y-m-d H:i') }}</div>
                                <x-admin.badge :tone="$employee->lastMealLog->status === 'approved' ? 'approved' : 'rejected'">
                                    {{ $employee->lastMealLog->status === 'approved' ? 'AUTORISE' : 'REFUSE' }}
                                </x-admin.badge>
                            @else
                                -
                            @endif
                        </td>
                        <td class="actions-col">
                            <x-admin.table-actions>
                            <a class="btn-action" href="{{ route('employees.show', $employee) }}">Details</a>
                            <a class="btn-action" href="{{ route('employees.edit', $employee) }}">Modifier</a>
                            <form class="inline" method="POST" action="{{ route('employees.toggle-status', $employee) }}"
                                  @if($employee->is_active)
                                      data-confirm="true"
                                      data-confirm-type="warning"
                                      data-confirm-title="Desactiver employe : {{ $employee->first_name }} {{ $employee->last_name }}"
                                      data-confirm-message="Confirmer la desactivation de cet employe ? Il ne pourra plus utiliser sa carte."
                                      data-confirm-cancel-label="Annuler"
                                      data-confirm-approve-label="Confirmer"
                                  @endif>
                                @csrf
                                @method('PATCH')
                                <button class="btn-action btn-action-muted" type="submit">
                                    {{ $employee->is_active ? 'Desactiver' : 'Activer' }}
                                </button>
                            </form>
                            <a class="btn-action btn-action-success" href="{{ route('employees.edit', $employee) }}">
                                Modifier UID NFC
                            </a>
                            <a class="btn-action btn-action-info" href="{{ route('meal-logs.index', ['employee_id' => $employee->id]) }}">Historique repas</a>
                            <form class="inline" method="POST" action="{{ route('employees.destroy', $employee) }}"
                                  data-confirm="true"
                                  data-confirm-type="danger"
                                  data-confirm-title="Supprimer employe"
                                  data-confirm-message="Voulez-vous vraiment supprimer cet employe ?"
                                  data-confirm-cancel-label="Annuler"
                                  data-confirm-approve-label="Supprimer">
                                @csrf
                                @method('DELETE')
                                <button class="btn-action btn-action-danger" type="submit">Supprimer</button>
                            </form>
                            </x-admin.table-actions>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7">
                            <x-admin.empty-state
                                title="Aucun employe trouve"
                                message="Ajustez les filtres ou creez un nouvel employe." />
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </x-admin.data-table>

        <div class="pager">{{ $employees->links() }}</div>
    </x-admin.panel>
@endsection
