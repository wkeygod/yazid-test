@extends('layouts.app')

@section('title', 'Modifier employe')
@section('topbar_actions')
    <a class="btn btn-secondary" href="{{ route('employees.show', $employee) }}">Retour fiche</a>
@endsection

@section('content')
    <x-admin.panel>
        <x-admin.page-header title="Modifier employe" :subtitle="trim($employee->first_name . ' ' . $employee->last_name)" />
        <form method="POST" action="{{ route('employees.update', $employee) }}" class="ds-form" novalidate>
            @csrf
            @method('PUT')

            <section class="ds-form-section" aria-labelledby="employee-main-title">
                <h3 id="employee-main-title" class="ds-form-section-title">Informations principales</h3>
                <p class="ds-form-section-subtitle">Mettez a jour l'identite et l'affectation de l'employe.</p>

                <div class="grid grid-2">
                    <div class="ds-field">
                        <label for="first_name">Prenom</label>
                        <input id="first_name" type="text" name="first_name" value="{{ old('first_name', $employee->first_name) }}" required autofocus
                               @error('first_name') aria-invalid="true" aria-describedby="first_name_error" class="input-error" @enderror>
                        @error('first_name')<p id="first_name_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>

                    <div class="ds-field">
                        <label for="last_name">Nom</label>
                        <input id="last_name" type="text" name="last_name" value="{{ old('last_name', $employee->last_name) }}" required
                               @error('last_name') aria-invalid="true" aria-describedby="last_name_error" class="input-error" @enderror>
                        @error('last_name')<p id="last_name_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>

                    <div class="ds-field">
                        <label for="position">Poste</label>
                        <input id="position" type="text" name="position" value="{{ old('position', $employee->position) }}" required
                               @error('position') aria-invalid="true" aria-describedby="position_error" class="input-error" @enderror>
                        @error('position')<p id="position_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>

                    <div class="ds-field">
                        <label for="rig_company">RiG (entreprise)</label>
                        <input id="rig_company" type="text" name="rig_company" value="{{ old('rig_company', $employee->rig_company) }}" required
                               @error('rig_company') aria-invalid="true" aria-describedby="rig_company_error" class="input-error" @enderror>
                        @error('rig_company')<p id="rig_company_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>
                </div>
            </section>

            <section class="ds-form-section" aria-labelledby="employee-nfc-title">
                <h3 id="employee-nfc-title" class="ds-form-section-title">Carte NFC</h3>
                <p class="ds-form-section-subtitle">Vous pouvez scanner une nouvelle carte pour remplacer l'UID actuel en toute securite.</p>

                <div class="grid grid-2">
                    <div class="ds-field">
                        <label for="card_uid">UID carte NFC</label>
                        <input
                            id="card_uid"
                            type="text"
                            name="card_uid"
                            value="{{ old('card_uid', $employee->card?->uid) }}"
                            placeholder="Ex: 04A1B2C3D4"
                            required
                            autocomplete="off"
                            spellcheck="false"
                            @error('card_uid') aria-invalid="true" aria-describedby="card_uid_error" class="input-error" @enderror
                        >
                        <small class="muted">UID actuel: {{ $employee->card?->uid ?: 'Aucune carte assignee' }}</small>
                        @error('card_uid')<p id="card_uid_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>
                </div>
            </section>

            <section class="ds-form-section" aria-labelledby="employee-meals-title">
                <h3 id="employee-meals-title" class="ds-form-section-title">Repas autorises</h3>
                <p class="ds-form-section-subtitle">Selectionnez les repas que l'employe peut consommer par jour.</p>

                @if($mealRules->isEmpty())
                    <p class="ds-field-error">Aucune regle de repas active. Veuillez d'abord en creer dans la section Regles de repas.</p>
                @else
                    <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
                        @foreach($mealRules as $rule)
                            <label class="ds-checkbox">
                                <input type="checkbox" name="allowed_meal_types[]" value="{{ $rule->id }}"
                                       {{ in_array($rule->id, old('allowed_meal_types', $employee->allowed_meal_types ?? [])) ? 'checked' : '' }}>
                                <span>{{ $rule->name }}</span>
                            </label>
                        @endforeach
                    </div>
                @endif
                @error('allowed_meal_types')<p class="ds-field-error">{{ $message }}</p>@enderror
            </section>

            <div class="ds-form-actions">
                <a class="btn btn-secondary" href="{{ route('employees.show', $employee) }}">Annuler</a>
                <button class="btn" type="submit">Mettre a jour</button>
            </div>
        </form>
    </x-admin.panel>
@endsection
