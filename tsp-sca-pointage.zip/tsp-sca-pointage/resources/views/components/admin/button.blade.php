@props([
    'variant' => 'primary',
    'size' => 'md',
    'type' => null,
])

@php
    $variantClass = match($variant) {
        'danger' => 'btn-danger',
        'success' => 'btn-ok',
        'secondary' => 'btn-secondary',
        default => '',
    };

    $sizeClass = match($size) {
        'sm' => 'btn-sm',
        'lg' => 'btn-lg',
        default => '',
    };

    $tag = $type ? 'button' : 'a';
@endphp

@if($tag === 'button')
    <button type="{{ $type }}" {{ $attributes->class(['btn', $variantClass, $sizeClass]) }}>
        {{ $slot }}
    </button>
@else
    <a {{ $attributes->class(['btn', $variantClass, $sizeClass]) }}>
        {{ $slot }}
    </a>
@endif
