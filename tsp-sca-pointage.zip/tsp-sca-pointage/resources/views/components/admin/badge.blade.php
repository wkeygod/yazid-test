@props([
    'tone' => 'neutral',
])

@php
    $toneClass = match($tone) {
        'active', 'approved', 'success' => 'status-active',
        'inactive', 'rejected', 'danger' => 'status-inactive',
        'warning' => 'ds-badge-warning',
        'info' => 'ds-badge-info',
        default => 'ds-badge-neutral',
    };
@endphp

<span {{ $attributes->class(['status-badge', $toneClass]) }}>
    {{ $slot }}
</span>
