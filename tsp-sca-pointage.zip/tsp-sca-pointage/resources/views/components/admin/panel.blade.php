@props([
    'soft' => false,
    'tight' => false,
])

<div {{ $attributes->class([
    'card',
    'ds-card-soft' => $soft,
    'ds-card-tight' => $tight,
]) }}>
    {{ $slot }}
</div>
