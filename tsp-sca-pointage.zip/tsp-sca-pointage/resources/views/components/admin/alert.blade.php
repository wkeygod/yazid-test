@props([
    'type' => 'info',
])

@php
    $alertClass = match($type) {
        'success' => 'alert-success',
        'error', 'danger' => 'alert-error',
        default => 'ds-alert-info',
    };
@endphp

<div {{ $attributes->class(['alert', $alertClass]) }}>
    {{ $slot }}
</div>
