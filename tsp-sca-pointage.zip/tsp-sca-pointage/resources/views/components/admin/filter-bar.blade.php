@props([
    'action' => '',
    'method' => 'GET',
])

<form method="{{ strtoupper($method) === 'GET' ? 'GET' : 'POST' }}" action="{{ $action }}" {{ $attributes->class(['ds-filter-bar', 'grid']) }}>
    @if(strtoupper($method) !== 'GET')
        @csrf
    @endif

    {{ $slot }}
</form>
