<div {{ $attributes->class(['table-actions', 'ds-table-actions']) }}>
    {{ $slot }}
</div>
