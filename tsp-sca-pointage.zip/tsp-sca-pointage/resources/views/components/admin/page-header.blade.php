@props([
    'title',
    'subtitle' => null,
])

<div {{ $attributes->class(['ds-page-header']) }}>
    <div>
        <h2 class="ds-page-title">{{ $title }}</h2>
        @if($subtitle)
            <p class="muted ds-page-subtitle">{{ $subtitle }}</p>
        @endif
    </div>

    @if(isset($actions))
        <div class="ds-page-actions">{{ $actions }}</div>
    @endif
</div>
