@props([
    'responsive' => true,
])

@if($responsive)
    <div class="ds-table-wrap" {{ $attributes }}>
        <table>
            {{ $slot }}
        </table>
    </div>
@else
    <table {{ $attributes }}>
        {{ $slot }}
    </table>
@endif
