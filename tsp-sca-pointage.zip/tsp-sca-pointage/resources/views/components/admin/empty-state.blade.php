@props([
    'title' => 'Aucune donnee disponible',
    'message' => null,
])

<div {{ $attributes->class(['ds-empty']) }}>
    <p class="ds-empty-title">{{ $title }}</p>

    @if($message)
        <p class="ds-empty-text">{{ $message }}</p>
    @endif

    @if(isset($actions))
        <div class="ds-empty-actions">
            {{ $actions }}
        </div>
    @endif
</div>
