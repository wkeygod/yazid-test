@props([
    'label',
    'value',
    'tone' => 'primary',
    'meta' => null,
])

@php
    $toneClass = match($tone) {
        'success' => 'ds-kpi-success',
        'danger' => 'ds-kpi-danger',
        'info' => 'ds-kpi-info',
        default => 'ds-kpi-primary',
    };
@endphp

<div {{ $attributes->class(['card', 'ds-kpi-card', $toneClass]) }}>
    <div class="ds-kpi-label">{{ $label }}</div>
    <div class="ds-kpi-value">{{ $value }}</div>
    @if($meta)
        <div class="muted ds-kpi-meta">{{ $meta }}</div>
    @endif
</div>
