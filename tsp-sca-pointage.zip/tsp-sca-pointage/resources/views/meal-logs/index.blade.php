@extends('layouts.app')

@section('title', 'Logs repas unifies')
@section('topbar_actions')
    <a class="btn btn-secondary" href="{{ route('meal-logs.index') }}"
       data-confirm-url="{{ route('meal-logs.index') }}"
       data-confirm-only-when-active="true"
       data-confirm-active-params="filter_mode,date,date_from,date_to,source,employee_id,card_uid,result,department_id,denial_reason,meal_type,rig_company,rig,q"
       data-confirm-type="warning"
       data-confirm-title="Réinitialiser les filtres"
       data-confirm-message="Réinitialiser tous les filtres et revenir à la vue par défaut ?"
       data-confirm-cancel-label="Annuler"
       data-confirm-approve-label="Réinitialiser">Réinitialiser les filtres</a>
    <a class="btn btn-ok" href="{{ route('kiosk.index') }}">Aller au kiosk</a>
@endsection

@section('styles')
    <style>
        .logs-filter-summary {
            display: flex;
            gap: .4rem;
            flex-wrap: wrap;
            margin-top: .55rem;
        }

        .field-hidden {
            display: none !important;
        }

        .meal-logs-wide-table table {
            min-width: 1750px;
        }

        .meal-logs-wide-table th,
        .meal-logs-wide-table td {
            white-space: nowrap;
        }

        .meal-logs-wide-table th:last-child,
        .meal-logs-wide-table td:last-child {
            min-width: 260px;
            white-space: normal;
        }
    </style>
@endsection

@section('content')
    @php
        $filterMode = $filters['filter_mode'] ?? 'range';
        $selectedDate = $filters['date'] ?? '';
        $dateFrom = $filters['date_from'] ?? '';
        $dateTo = $filters['date_to'] ?? '';
        $sourceFilter = $filters['source'] ?? 'all';
        $employeeFilter = (int) ($filters['employee_id'] ?? 0);
        $cardUidFilter = $filters['card_uid'] ?? '';
        $resultFilter = $filters['result'] ?? '';
        $departmentFilter = (int) ($filters['department_id'] ?? 0);
        $denialReasonFilter = $filters['denial_reason'] ?? '';
        $mealTypeFilter = $filters['meal_type'] ?? '';
        $companyFilter = $filters['rig_company'] ?? '';
        $rigFilter = $filters['rig'] ?? '';
        $searchFilter = $filters['q'] ?? '';

        $activeFilters = collect([
            $filterMode !== '' ? 'Mode: ' . $filterMode : null,
            $selectedDate !== '' && $filterMode === 'day' ? 'Date: ' . $selectedDate : null,
            $dateFrom !== '' && $filterMode === 'range' ? 'Date debut: ' . $dateFrom : null,
            $dateTo !== '' && $filterMode === 'range' ? 'Date fin: ' . $dateTo : null,
            $sourceFilter !== 'all' ? 'Source: ' . ($sources[$sourceFilter] ?? $sourceFilter) : null,
            $employeeFilter > 0 ? 'Employe sélectionné' : null,
            $cardUidFilter !== '' ? 'UID: ' . $cardUidFilter : null,
            $resultFilter !== '' ? 'Resultat: ' . strtoupper($resultFilter) : null,
            $departmentFilter > 0 ? 'Departement sélectionné' : null,
            $denialReasonFilter !== '' ? 'Motif refus: ' . $denialReasonFilter : null,
            $mealTypeFilter !== '' ? 'Type repas: ' . $mealTypeFilter : null,
            $companyFilter !== '' ? 'Compagnie: ' . $companyFilter : null,
            $rigFilter !== '' ? 'Rig/Poste: ' . $rigFilter : null,
            $searchFilter !== '' ? 'Recherche: ' . $searchFilter : null,
        ])->filter()->values();
    @endphp

    <x-admin.page-header title="Journal des repas unifié" subtitle="NFC + La Releve + Extra avec filtres intelligents" />

    @if($scopedEmployee)
        <div class="card" style="margin-bottom:1rem; border-left:4px solid #1f5fbf;">
            <div style="font-weight:700;">Historique filtré</div>
            <div class="muted">{{ $scopedEmployee->employee_no }} - {{ $scopedEmployee->first_name }} {{ $scopedEmployee->last_name }}</div>
            <div class="muted" style="font-size:.85rem; margin-top:.2rem;">Cette vue affiche uniquement les repas de cet employé.</div>
        </div>
    @endif

    <div class="grid grid-2" style="margin-bottom:1rem;">
        <x-admin.kpi-card label="Total logs" :value="number_format((int) ($summary['total'] ?? 0))" />
        <x-admin.kpi-card label="Plats consommes" :value="number_format((int) ($summary['consumed_total'] ?? 0))" tone="success" />
        <x-admin.kpi-card label="Refuses" :value="number_format((int) ($summary['denied'] ?? 0))" tone="danger" />
        <x-admin.kpi-card label="NFC" :value="number_format((int) ($summary['source_employee'] ?? 0))" tone="info" />
        <x-admin.kpi-card label="La Releve" :value="number_format((int) ($summary['source_la_releve'] ?? 0))" tone="primary" />
        <x-admin.kpi-card label="Extra" :value="number_format((int) ($summary['source_extra'] ?? 0))" tone="warning" />
        <x-admin.kpi-card label="Petit-dejeuner" :value="number_format((int) ($mealTypeSummary['breakfast'] ?? 0))" tone="info" />
        <x-admin.kpi-card label="Dejeuner" :value="number_format((int) ($mealTypeSummary['lunch'] ?? 0))" tone="primary" />
        <x-admin.kpi-card label="Diner" :value="number_format((int) ($mealTypeSummary['dinner'] ?? 0))" tone="warning" />
        <x-admin.kpi-card label="Montant total" :value="number_format((float) ($summary['amount_total'] ?? 0), 2)" tone="info" />
    </div>

    <div class="card" style="margin-bottom:1rem;">
        <div class="panel-header">
            <h2>Filtres intelligents</h2>
        </div>

        <x-admin.filter-bar action="{{ route('meal-logs.index') }}" style="grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));">
            <div>
                <label>Mode de date</label>
                <select id="meal_logs_filter_mode" name="filter_mode">
                    <option value="day" {{ $filterMode === 'day' ? 'selected' : '' }}>Date unique</option>
                    <option value="range" {{ $filterMode === 'range' ? 'selected' : '' }}>Intervalle</option>
                </select>
            </div>

            <div id="meal_logs_day_wrap">
                <label>Date (jour)</label>
                <input type="date" name="date" value="{{ $selectedDate }}">
            </div>

            <div id="meal_logs_from_wrap">
                <label>Date debut</label>
                <input type="date" name="date_from" value="{{ $dateFrom }}">
            </div>

            <div id="meal_logs_to_wrap">
                <label>Date fin</label>
                <input type="date" name="date_to" value="{{ $dateTo }}">
            </div>

            <div>
                <label>Source</label>
                <select name="source">
                    @foreach($sources as $sourceKey => $sourceLabel)
                        <option value="{{ $sourceKey }}" {{ $sourceFilter === $sourceKey ? 'selected' : '' }}>{{ $sourceLabel }}</option>
                    @endforeach
                </select>
            </div>

            <div>
                <label>Employe NFC</label>
                <select name="employee_id">
                    <option value="">Tous</option>
                    @foreach($employees as $employee)
                        <option value="{{ $employee->id }}" {{ $employeeFilter === (int) $employee->id ? 'selected' : '' }}>
                            {{ $employee->employee_no }} - {{ $employee->first_name }} {{ $employee->last_name }}
                        </option>
                    @endforeach
                </select>
            </div>

            <div>
                <label>Compagnie</label>
                <select name="rig_company">
                    <option value="">Toutes</option>
                    @foreach($companies as $company)
                        <option value="{{ $company }}" {{ $companyFilter === $company ? 'selected' : '' }}>{{ $company }}</option>
                    @endforeach
                </select>
            </div>

            <div>
                <label>Rig / Poste</label>
                <select name="rig">
                    <option value="">Tous</option>
                    @foreach($rigs as $rig)
                        <option value="{{ $rig }}" {{ $rigFilter === $rig ? 'selected' : '' }}>{{ $rig }}</option>
                    @endforeach
                </select>
            </div>

            <div>
                <label>Type repas</label>
                <input type="text" name="meal_type" value="{{ $mealTypeFilter }}" placeholder="Ex: breakfast, lunch, dinner">
            </div>

            <div>
                <label>UID carte</label>
                <input type="text" name="card_uid" value="{{ $cardUidFilter }}" placeholder="Ex: TEST001">
            </div>

            <div>
                <label>Résultat</label>
                <select name="result">
                    <option value="">Tous</option>
                    <option value="approved" {{ $resultFilter === 'approved' ? 'selected' : '' }}>Autorisé</option>
                    <option value="rejected" {{ $resultFilter === 'rejected' ? 'selected' : '' }}>Refusé</option>
                </select>
            </div>

            <div>
                <label>Departement</label>
                <select name="department_id">
                    <option value="">Tous</option>
                    @foreach($departments as $department)
                        <option value="{{ $department->id }}" {{ $departmentFilter === (int) $department->id ? 'selected' : '' }}>
                            {{ $department->name }}
                        </option>
                    @endforeach
                </select>
            </div>

            <div>
                <label>Motif refus</label>
                <select name="denial_reason">
                    <option value="">Tous</option>
                    @foreach($denialReasons as $reason)
                        <option value="{{ $reason }}" {{ $denialReasonFilter === $reason ? 'selected' : '' }}>{{ $reason }}</option>
                    @endforeach
                </select>
            </div>

            <div>
                <label>Recherche globale</label>
                <input type="text" name="q" value="{{ $searchFilter }}" placeholder="Nom, matricule, compagnie, rig, repas...">
            </div>

            <div class="actions" style="align-self:end; display:flex; gap:.45rem; flex-wrap:wrap;">
                <button class="btn" type="submit">Filtrer</button>
                <a class="btn btn-secondary" href="{{ route('meal-logs.index') }}"
                   data-confirm-url="{{ route('meal-logs.index') }}"
                   data-confirm-only-when-active="true"
                   data-confirm-active-params="filter_mode,date,date_from,date_to,source,employee_id,card_uid,result,department_id,denial_reason,meal_type,rig_company,rig,q"
                   data-confirm-type="warning"
                   data-confirm-title="Réinitialiser les filtres"
                   data-confirm-message="Réinitialiser tous les filtres et revenir à la vue par défaut ?"
                   data-confirm-cancel-label="Annuler"
                   data-confirm-approve-label="Réinitialiser">Réinitialiser</a>
                <a class="btn export-link" style="background:#1f7a4f;" data-export-url="{{ route('meal-logs.export', array_merge(request()->query(), ['format' => 'excel'])) }}" href="#">Exporter Excel Pro</a>
            </div>
        </x-admin.filter-bar>

        @if($activeFilters->isNotEmpty())
            <div class="logs-filter-summary">
                @foreach($activeFilters as $chip)
                    <x-admin.badge tone="info">{{ $chip }}</x-admin.badge>
                @endforeach
            </div>
        @endif
    </div>

    <div class="card">
        <div class="panel-header">
            <h2 style="margin:0;">Journal unifié des repas</h2>
            <span class="muted">{{ $mealLogs->total() }} lignes</span>
        </div>

        <x-admin.data-table class="table-sticky table-compact meal-logs-wide-table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Heure</th>
                    <th>Source</th>
                    <th>Statut</th>
                    <th>Type repas</th>
                    <th>Matricule / ID</th>
                    <th>Nom complet</th>
                    <th>Compagnie</th>
                    <th>Rig / Poste</th>
                    <th>Departement</th>
                    <th>UID carte</th>
                    <th>Montant</th>
                    <th>Motif</th>
                </tr>
            </thead>
            <tbody>
            @forelse($mealLogs as $log)
                <tr>
                    <td>{{ $log['date'] ?: '-' }}</td>
                    <td>{{ $log['time'] ?: '-' }}</td>
                    <td>{{ $log['source_label'] ?: '-' }}</td>
                    <td>
                        <x-admin.badge :tone="$log['status'] === 'approved' ? 'approved' : 'rejected'">
                            {{ $log['status'] === 'approved' ? 'AUTORISE' : 'REFUSE' }}
                        </x-admin.badge>
                    </td>
                    <td>{{ $log['meal'] ?: '-' }}</td>
                    <td>{{ $log['employee_no'] ?: '-' }}</td>
                    <td>{{ $log['full_name'] ?: '-' }}</td>
                    <td>{{ $log['company'] ?: '-' }}</td>
                    <td>{{ $log['rig'] ?: '-' }}</td>
                    <td>{{ $log['department'] ?: '-' }}</td>
                    <td>{{ $log['card_uid'] ?: '-' }}</td>
                    <td>{{ number_format((float) ($log['amount'] ?? 0), 2) }}</td>
                    <td>{{ $log['reason'] ?: '-' }}</td>
                </tr>
            @empty
                <tr>
                    <td colspan="13">
                        <x-admin.empty-state
                            title="Aucun log trouve"
                            message="Aucun enregistrement ne correspond aux filtres sélectionnés." />
                    </td>
                </tr>
            @endforelse
            </tbody>
        </x-admin.data-table>

        <div class="pager">{{ $mealLogs->links() }}</div>
    </div>
@endsection

@section('scripts')
    <script>
        (function () {
            var modeEl = document.getElementById('meal_logs_filter_mode');
            var dayWrap = document.getElementById('meal_logs_day_wrap');
            var fromWrap = document.getElementById('meal_logs_from_wrap');
            var toWrap = document.getElementById('meal_logs_to_wrap');

            if (!modeEl || !dayWrap || !fromWrap || !toWrap) {
                return;
            }

            function syncDateFields() {
                var isRange = (modeEl.value || 'range') === 'range';
                dayWrap.classList.toggle('field-hidden', isRange);
                fromWrap.classList.toggle('field-hidden', !isRange);
                toWrap.classList.toggle('field-hidden', !isRange);
            }

            modeEl.addEventListener('change', syncDateFields);
            syncDateFields();
        })();
    </script>
@endsection
