@extends('layouts.app')

@section('title', 'Historique Employes')

@section('styles')
    <style>
        .employee-history-export-csv {
            background: linear-gradient(180deg, #1f7a4f, #17613e) !important;
            color: #fff !important;
        }

        .field-hidden {
            display: none !important;
        }
    </style>
@endsection

@section('content')
    @php
        $historyAuthUser = auth()->user();
        $historyAccessiblePages = $historyAuthUser ? $historyAuthUser->getAccessiblePages() : [];
        $canEditEmployeesFromHistory = $historyAuthUser && ($historyAuthUser->is_admin || in_array('employees.index', $historyAccessiblePages, true));
    @endphp

    <x-admin.panel>
        <x-admin.page-header title="Historique Employes" subtitle="Suivi des repas consommés par les employés." />

        <div class="grid grid-2" style="margin-bottom:.9rem;">
            <x-admin.kpi-card label="Total logs" :value="$summary['total']" tone="primary" />
            <x-admin.kpi-card label="Autorises" :value="$summary['authorized']" tone="success" />
            <x-admin.kpi-card label="Refuses" :value="$summary['denied']" tone="danger" />
            <x-admin.kpi-card label="Employes uniques" :value="$summary['employees']" tone="info" />
            <x-admin.kpi-card label="Petit-dejeuner" :value="$summary['breakfast']" tone="warning" />
            <x-admin.kpi-card label="Dejeuner" :value="$summary['lunch']" tone="primary" />
            <x-admin.kpi-card label="Diner" :value="$summary['dinner']" tone="info" />
        </div>

        <x-admin.filter-bar action="{{ route('employee-history.index') }}" style="margin-bottom:.9rem;">
            <div>
                <label>Mode de date</label>
                <select name="filter_mode" id="employee_history_filter_mode">
                    <option value="day" {{ $filterMode === 'day' ? 'selected' : '' }}>Date unique</option>
                    <option value="range" {{ $filterMode === 'range' ? 'selected' : '' }}>Intervalle</option>
                </select>
            </div>
            <div id="employee_history_day_wrap">
                <label>Date (jour)</label>
                <input type="date" id="employee_history_date" name="date" value="{{ $selectedDate }}">
            </div>
            <div id="employee_history_from_wrap">
                <label>Date debut</label>
                <input type="date" id="employee_history_date_from" name="date_from" value="{{ $selectedDateFrom }}">
            </div>
            <div id="employee_history_to_wrap">
                <label>Date fin</label>
                <input type="date" id="employee_history_date_to" name="date_to" value="{{ $selectedDateTo }}">
            </div>
            <div>
                <label>Recherche</label>
                <input id="employee_history_realtime_search" type="text" name="q" value="{{ $search }}" placeholder="Nom, matricule, poste, entreprise, type repas..." autocomplete="off">
            </div>
            <div class="actions" style="align-self: end;">
                <button class="btn" type="submit">Filtrer</button>
                <a class="btn btn-secondary" href="{{ route('employee-history.index') }}">Reinitialiser</a>
                <a class="btn employee-history-export-csv export-link" data-export-url="{{ route('employee-history.export', array_merge(request()->query(), ['format' => 'excel'])) }}" href="#">Exporter Excel Pro</a>
            </div>
        </x-admin.filter-bar>

        <x-admin.data-table class="table-sticky table-compact">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Heure</th>
                    <th>Matricule</th>
                    <th>Nom complet</th>
                    <th>Poste</th>
                    <th>Entreprise</th>
                    <th>Type repas</th>
                    <th>Statut</th>
                    <th>Motif refus</th>
                    <th class="actions-col">Actions</th>
                </tr>
            </thead>
            <tbody id="employee_history_table_body">
            @forelse($logs as $log)
                @php
                    $statusLabel = $log->status === 'approved' ? 'Autorise' : 'Refuse';
                    $statusClass = $log->status === 'approved' ? 'status-approved' : 'status-rejected';
                    $employee = $log->employee;
                    $searchIndex = strtolower(trim(implode(' ', array_filter([
                        $log->logged_at?->format('Y-m-d'),
                        $log->logged_at?->format('H:i:s'),
                        $employee?->employee_no,
                        trim(($employee?->first_name ?? '') . ' ' . ($employee?->last_name ?? '')),
                        $employee?->position,
                        $employee?->rig_company,
                        $log->meal_type_label,
                        $statusLabel,
                        $log->reason,
                    ]))));
                @endphp
                <tr data-history-row data-search="{{ $searchIndex }}">
                    <td>{{ $log->logged_at?->format('Y-m-d') ?: '-' }}</td>
                    <td>{{ $log->logged_at?->format('H:i:s') ?: '-' }}</td>
                    <td>{{ $employee?->employee_no ?: '-' }}</td>
                    <td>{{ trim(($employee?->first_name ?? '') . ' ' . ($employee?->last_name ?? '')) ?: '-' }}</td>
                    <td>{{ $employee?->position ?: '-' }}</td>
                    <td>{{ $employee?->rig_company ?: '-' }}</td>
                    <td>{{ $log->meal_type_label ?: '-' }}</td>
                    <td><span class="status-badge {{ $statusClass }}">{{ $statusLabel }}</span></td>
                    <td>{{ $log->status === 'rejected' ? ($log->reason ?: '-') : '-' }}</td>
                    <td>
                        @if($canEditEmployeesFromHistory && $employee)
                            <x-admin.table-actions>
                                <a class="btn-action btn-action-info" href="{{ route('employees.edit', $employee) }}">Modifier</a>
                            </x-admin.table-actions>
                        @else
                            -
                        @endif
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="10">
                        <x-admin.empty-state
                            title="Aucun historique employe"
                            message="Aucune consommation trouvée pour les filtres sélectionnés." />
                    </td>
                </tr>
            @endforelse
            </tbody>
        </x-admin.data-table>

        <div id="employee_history_no_results" class="card" style="padding:.8rem; margin-bottom:.75rem; display:none;">
            Aucun résultat trouvé pour la recherche en temps réel.
        </div>

        <div class="pager">{{ $logs->links() }}</div>
    </x-admin.panel>
@endsection

@section('scripts')
    <script>
        (function () {
            var modeEl = document.getElementById('employee_history_filter_mode');
            var dayWrap = document.getElementById('employee_history_day_wrap');
            var fromWrap = document.getElementById('employee_history_from_wrap');
            var toWrap = document.getElementById('employee_history_to_wrap');

            function syncFilterFields() {
                if (!modeEl || !dayWrap || !fromWrap || !toWrap) {
                    return;
                }

                var mode = modeEl.value || 'range';
                var isRange = mode === 'range';

                dayWrap.classList.toggle('field-hidden', isRange);
                fromWrap.classList.toggle('field-hidden', !isRange);
                toWrap.classList.toggle('field-hidden', !isRange);
            }

            if (modeEl) {
                modeEl.addEventListener('change', syncFilterFields);
            }
            syncFilterFields();

            var realtimeInput = document.getElementById('employee_history_realtime_search');
            var noResultsBox = document.getElementById('employee_history_no_results');

            function normalize(value) {
                return (value || '')
                    .toString()
                    .normalize('NFD')
                    .replace(/[\u0300-\u036f]/g, '')
                    .toLowerCase()
                    .trim();
            }

            function applyRealtimeFilter() {
                var rows = document.querySelectorAll('[data-history-row]');
                if (!rows.length) {
                    return;
                }

                var term = normalize(realtimeInput ? realtimeInput.value : '');
                var visibleCount = 0;

                rows.forEach(function (row) {
                    var haystack = normalize(row.getAttribute('data-search'));
                    var visible = term === '' || haystack.indexOf(term) !== -1;
                    row.style.display = visible ? '' : 'none';
                    if (visible) {
                        visibleCount += 1;
                    }
                });

                if (noResultsBox) {
                    noResultsBox.style.display = visibleCount === 0 ? '' : 'none';
                }
            }

            if (realtimeInput) {
                realtimeInput.addEventListener('input', applyRealtimeFilter);
                applyRealtimeFilter();
            }
        })();
    </script>
@endsection
