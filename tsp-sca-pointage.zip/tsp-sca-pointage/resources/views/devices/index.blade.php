@extends('layouts.app')

@section('title', 'Appareils')
@section('topbar_actions')
    <a class="btn" href="{{ route('devices.create') }}">Nouvel appareil</a>
@endsection

@section('content')
    <x-admin.panel>
        <x-admin.page-header title="Appareils" subtitle="Bornes et lecteurs de pointage rattaches au systeme." />

        <x-admin.data-table class="table-sticky table-compact">
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Nom</th>
                    <th>Emplacement</th>
                    <th>Adresse IP</th>
                    <th>Derniere activite</th>
                    <th class="status-col">Statut</th>
                    <th class="actions-col">Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($devices as $device)
                    <tr>
                        <td>{{ $device->code }}</td>
                        <td>{{ $device->name }}</td>
                        <td>{{ $device->location ?: '—' }}</td>
                        <td>{{ $device->ip_address ?: '—' }}</td>
                        <td>{{ $device->last_seen_at?->format('d/m/Y H:i') ?: 'Jamais' }}</td>
                        <td class="status-col">
                            <x-admin.badge :tone="$device->is_active ? 'active' : 'inactive'">
                                {{ $device->is_active ? 'Actif' : 'Inactif' }}
                            </x-admin.badge>
                        </td>
                        <td class="actions-col">
                            <x-admin.table-actions>
                                <a class="btn-action" href="{{ route('devices.edit', $device) }}">Modifier</a>
                                <form class="inline" method="POST" action="{{ route('devices.destroy', $device) }}"
                                      data-confirm="true"
                                      data-confirm-type="danger"
                                      data-confirm-title="Supprimer appareil"
                                      data-confirm-message="Supprimer cet appareil ? Cette action est irreversible.">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn-action btn-action-danger" type="submit">Supprimer</button>
                                </form>
                            </x-admin.table-actions>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7">
                            <x-admin.empty-state
                                title="Aucun appareil trouve"
                                message="Ajoutez une borne ou un lecteur pour l'identifier dans les journaux de pointage." />
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </x-admin.data-table>

        <div class="pager">{{ $devices->links() }}</div>
    </x-admin.panel>
@endsection
