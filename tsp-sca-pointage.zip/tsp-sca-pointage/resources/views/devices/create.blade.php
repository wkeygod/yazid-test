@extends('layouts.app')

@section('title', 'Nouvel appareil')
@section('topbar_actions')
    <a class="btn btn-secondary" href="{{ route('devices.index') }}">Retour liste</a>
@endsection

@section('content')
    <x-admin.panel>
        <x-admin.page-header title="Creer un appareil" subtitle="Enregistrez une nouvelle borne ou un nouveau lecteur." />
        <form method="POST" action="{{ route('devices.store') }}" class="ds-form" novalidate>
            @csrf

            <section class="ds-form-section" aria-labelledby="device-main-title">
                <h3 id="device-main-title" class="ds-form-section-title">Configuration principale</h3>
                <p class="ds-form-section-subtitle">Identification et emplacement de l'appareil.</p>

                <div class="grid grid-2">
                    <div class="ds-field">
                        <label for="code">Code</label>
                        <input id="code" type="text" name="code" value="{{ old('code') }}" required autofocus
                               @error('code') aria-invalid="true" aria-describedby="code_error" class="input-error" @enderror>
                        @error('code')<p id="code_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>

                    <div class="ds-field">
                        <label for="name">Nom</label>
                        <input id="name" type="text" name="name" value="{{ old('name') }}" required
                               @error('name') aria-invalid="true" aria-describedby="name_error" class="input-error" @enderror>
                        @error('name')<p id="name_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>

                    <div class="ds-field">
                        <label for="location">Emplacement</label>
                        <input id="location" type="text" name="location" value="{{ old('location') }}"
                               @error('location') aria-invalid="true" aria-describedby="location_error" class="input-error" @enderror>
                        @error('location')<p id="location_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>

                    <div class="ds-field">
                        <label for="ip_address">Adresse IP</label>
                        <input id="ip_address" type="text" name="ip_address" value="{{ old('ip_address') }}" placeholder="192.168.1.10"
                               @error('ip_address') aria-invalid="true" aria-describedby="ip_address_error" class="input-error" @enderror>
                        @error('ip_address')<p id="ip_address_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>
                </div>

                <div class="ds-field">
                    <label for="notes">Notes</label>
                    <textarea id="notes" name="notes" rows="3"
                              @error('notes') aria-invalid="true" aria-describedby="notes_error" class="input-error" @enderror>{{ old('notes') }}</textarea>
                    @error('notes')<p id="notes_error" class="ds-field-error">{{ $message }}</p>@enderror
                </div>

                <div class="ds-field">
                    <label class="ds-checkbox" for="is_active">
                        <input id="is_active" type="checkbox" name="is_active" value="1" {{ old('is_active', 1) ? 'checked' : '' }}>
                        Appareil actif
                    </label>
                </div>
            </section>

            <div class="ds-form-actions" style="margin-top:.6rem;">
                <a class="btn btn-secondary" href="{{ route('devices.index') }}">Annuler</a>
                <button class="btn" type="submit">Enregistrer</button>
            </div>
        </form>
    </x-admin.panel>
@endsection
