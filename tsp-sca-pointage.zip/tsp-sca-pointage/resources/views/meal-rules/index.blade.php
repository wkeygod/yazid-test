@extends('layouts.app')

@section('title', 'Regles repas')
@section('topbar_actions')
    <a class="btn" href="{{ route('meal-rules.create') }}">Nouvelle regle</a>
@endsection

@section('content')
    <x-admin.panel>
        <x-admin.page-header title="Regles repas" subtitle="Configuration des fenetres, couts et plafonds de consommation." />

        <x-admin.data-table class="table-sticky table-compact">
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Horaire</th>
                    <th>Cout</th>
                    <th>Limites</th>
                    <th class="status-col">Actif</th>
                    <th class="actions-col">Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($mealRules as $rule)
                    <tr>
                        <td>{{ $rule->name }}</td>
                        <td>{{ $rule->start_time }} - {{ $rule->end_time }}</td>
                        <td>{{ number_format((float) $rule->cost, 2) }}</td>
                        <td>{{ $rule->max_meals_per_day }}/jour, {{ $rule->max_meals_per_week }}/semaine</td>
                        <td class="status-col">
                            <x-admin.badge :tone="$rule->is_active ? 'active' : 'inactive'">
                                {{ $rule->is_active ? 'Active' : 'Inactive' }}
                            </x-admin.badge>
                        </td>
                        <td class="actions-col">
                            <x-admin.table-actions>
                                <a class="btn-action" href="{{ route('meal-rules.edit', $rule) }}">Modifier</a>
                                <form class="inline" method="POST" action="{{ route('meal-rules.destroy', $rule) }}"
                                      data-confirm="true"
                                      data-confirm-type="danger"
                                      data-confirm-title="Supprimer regle repas"
                                      data-confirm-message="Supprimer cette regle ? Cette action est irreversible.">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn-action btn-action-danger" type="submit">Supprimer</button>
                                </form>
                            </x-admin.table-actions>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6">
                            <x-admin.empty-state
                                title="Aucune regle trouvee"
                                message="Ajoutez une regle repas pour definir les contraintes de service." />
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </x-admin.data-table>

        <div class="pager">{{ $mealRules->links() }}</div>
    </x-admin.panel>
@endsection
