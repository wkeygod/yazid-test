@extends('layouts.app')

@section('title', 'Nouvelle regle repas')
@section('topbar_actions')
    <a class="btn btn-secondary" href="{{ route('meal-rules.index') }}">Retour liste</a>
@endsection

@section('content')
    <x-admin.panel>
        <x-admin.page-header title="Creer une regle repas" subtitle="Definissez une fenetre repas et ses contraintes." />
        <form method="POST" action="{{ route('meal-rules.store') }}" class="ds-form" novalidate>
            @csrf

            <section class="ds-form-section" aria-labelledby="meal-rule-main-title">
                <h3 id="meal-rule-main-title" class="ds-form-section-title">Configuration principale</h3>
                <p class="ds-form-section-subtitle">Nom, fenetre horaire et cout de la regle.</p>

                <div class="grid grid-2">
                    <div class="ds-field">
                        <label for="name">Nom</label>
                        <input id="name" type="text" name="name" value="{{ old('name') }}" required autofocus
                               @error('name') aria-invalid="true" aria-describedby="name_error" class="input-error" @enderror>
                        @error('name')<p id="name_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>

                    <div class="ds-field">
                        <label for="cost">Cout</label>
                        <input id="cost" type="number" min="0" step="0.01" name="cost" value="{{ old('cost', '0') }}" required
                               @error('cost') aria-invalid="true" aria-describedby="cost_error" class="input-error" @enderror>
                        @error('cost')<p id="cost_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>

                    <div class="ds-field">
                        <label for="start_time">Heure debut (HH:MM)</label>
                        <input id="start_time" type="time" name="start_time" value="{{ old('start_time', '11:30') }}" required
                               @error('start_time') aria-invalid="true" aria-describedby="start_time_error" class="input-error" @enderror>
                        @error('start_time')<p id="start_time_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>

                    <div class="ds-field">
                        <label for="end_time">Heure fin (HH:MM)</label>
                        <input id="end_time" type="time" name="end_time" value="{{ old('end_time', '14:30') }}" required
                               @error('end_time') aria-invalid="true" aria-describedby="end_time_error" class="input-error" @enderror>
                        @error('end_time')<p id="end_time_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>
                </div>
            </section>

            <section class="ds-form-section" aria-labelledby="meal-rule-advanced-title">
                <h3 id="meal-rule-advanced-title" class="ds-form-section-title">Champs avances</h3>
                <p class="ds-form-section-subtitle">Limites de consommation et jours actifs.</p>

                <div class="grid grid-2">
                    <div class="ds-field">
                        <label for="max_meals_per_day">Max repas / jour</label>
                        <input id="max_meals_per_day" type="number" min="1" name="max_meals_per_day" value="{{ old('max_meals_per_day', '1') }}" required
                               @error('max_meals_per_day') aria-invalid="true" aria-describedby="max_meals_per_day_error" class="input-error" @enderror>
                        @error('max_meals_per_day')<p id="max_meals_per_day_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>

                    <div class="ds-field">
                        <label for="max_meals_per_week">Max repas / semaine</label>
                        <input id="max_meals_per_week" type="number" min="1" name="max_meals_per_week" value="{{ old('max_meals_per_week', '5') }}" required
                               @error('max_meals_per_week') aria-invalid="true" aria-describedby="max_meals_per_week_error" class="input-error" @enderror>
                        @error('max_meals_per_week')<p id="max_meals_per_week_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>
                </div>

                <div class="ds-field">
                    <label>Jours autorises</label>
                    <div class="ds-checkbox-group" role="group" aria-label="Jours autorises">
                        @foreach([1 => 'Lundi', 2 => 'Mardi', 3 => 'Mercredi', 4 => 'Jeudi', 5 => 'Vendredi', 6 => 'Samedi', 7 => 'Dimanche'] as $value => $label)
                            <label class="ds-checkbox" for="day_{{ $value }}">
                                <input id="day_{{ $value }}" type="checkbox" name="days_of_week[]" value="{{ $value }}" {{ in_array($value, old('days_of_week', [1,2,3,4,5])) ? 'checked' : '' }}>
                                {{ $label }}
                            </label>
                        @endforeach
                    </div>
                    @error('days_of_week')<p class="ds-field-error">{{ $message }}</p>@enderror
                </div>

                <div class="ds-field">
                    <label class="ds-checkbox" for="authorize_for_all_employees">
                        <input id="authorize_for_all_employees" type="checkbox" name="authorize_for_all_employees" value="1" {{ old('authorize_for_all_employees', true) ? 'checked' : '' }}>
                        Autoriser pour tous les employes existants
                    </label>
                </div>

                <div class="ds-field">
                    <label class="ds-checkbox" for="is_active">
                        <input id="is_active" type="checkbox" name="is_active" value="1" {{ old('is_active', 1) ? 'checked' : '' }}>
                        Regle active
                    </label>
                </div>
            </section>

            <div class="ds-form-actions" style="margin-top:.6rem;">
                <a class="btn btn-secondary" href="{{ route('meal-rules.index') }}">Annuler</a>
                <button class="btn" type="submit">Enregistrer</button>
            </div>
        </form>
    </x-admin.panel>
@endsection
