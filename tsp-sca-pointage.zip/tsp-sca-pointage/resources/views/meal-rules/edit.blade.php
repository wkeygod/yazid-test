@extends('layouts.app')

@section('title', 'Modifier regle repas')
@section('topbar_actions')
    <a class="btn btn-secondary" href="{{ route('meal-rules.index') }}">Retour liste</a>
@endsection

@section('content')
    <x-admin.panel>
        <x-admin.page-header title="Modifier regle repas" :subtitle="$mealRule->name" />
        <form method="POST" action="{{ route('meal-rules.update', $mealRule) }}" class="ds-form" novalidate>
            @csrf
            @method('PUT')

            <section class="ds-form-section" aria-labelledby="meal-rule-main-title">
                <h3 id="meal-rule-main-title" class="ds-form-section-title">Configuration principale</h3>
                <p class="ds-form-section-subtitle">Mettre a jour l'identite, les horaires et le cout de la regle.</p>

                <div class="grid grid-2">
                    <div class="ds-field">
                        <label for="name">Nom</label>
                        <input id="name" type="text" name="name" value="{{ old('name', $mealRule->name) }}" required autofocus
                               @error('name') aria-invalid="true" aria-describedby="name_error" class="input-error" @enderror>
                        @error('name')<p id="name_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>

                    <div class="ds-field">
                        <label for="cost">Cout</label>
                        <input id="cost" type="number" min="0" step="0.01" name="cost" value="{{ old('cost', $mealRule->cost) }}" required
                               @error('cost') aria-invalid="true" aria-describedby="cost_error" class="input-error" @enderror>
                        @error('cost')<p id="cost_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>

                    <div class="ds-field">
                        <label for="start_time">Heure debut</label>
                        <input id="start_time" type="time" name="start_time" value="{{ old('start_time', substr($mealRule->start_time, 0, 5)) }}" required
                               @error('start_time') aria-invalid="true" aria-describedby="start_time_error" class="input-error" @enderror>
                        @error('start_time')<p id="start_time_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>

                    <div class="ds-field">
                        <label for="end_time">Heure fin</label>
                        <input id="end_time" type="time" name="end_time" value="{{ old('end_time', substr($mealRule->end_time, 0, 5)) }}" required
                               @error('end_time') aria-invalid="true" aria-describedby="end_time_error" class="input-error" @enderror>
                        @error('end_time')<p id="end_time_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>
                </div>
            </section>

            @php
                $selectedDaysRaw = old('days_of_week', $mealRule->days_of_week ?? []);

                if (is_string($selectedDaysRaw)) {
                    $decoded = json_decode($selectedDaysRaw, true);
                    $selectedDaysRaw = is_array($decoded) ? $decoded : [];
                }

                if (!is_array($selectedDaysRaw)) {
                    $selectedDaysRaw = [];
                }

                $dayNameToNumber = [
                    'monday' => 1,
                    'tuesday' => 2,
                    'wednesday' => 3,
                    'thursday' => 4,
                    'friday' => 5,
                    'saturday' => 6,
                    'sunday' => 7,
                ];

                $selectedDays = array_values(array_unique(array_filter(array_map(function ($day) use ($dayNameToNumber) {
                    if (is_numeric($day)) {
                        return (int) $day;
                    }

                    $key = strtolower((string) $day);
                    return $dayNameToNumber[$key] ?? null;
                }, $selectedDaysRaw), fn ($day) => is_int($day) && $day >= 1 && $day <= 7)));
            @endphp
            <section class="ds-form-section" aria-labelledby="meal-rule-advanced-title">
                <h3 id="meal-rule-advanced-title" class="ds-form-section-title">Champs avances</h3>
                <p class="ds-form-section-subtitle">Limites de consommation et activations hebdomadaires.</p>

                <div class="grid grid-2">
                    <div class="ds-field">
                        <label for="max_meals_per_day">Max repas / jour</label>
                        <input id="max_meals_per_day" type="number" min="1" name="max_meals_per_day" value="{{ old('max_meals_per_day', $mealRule->max_meals_per_day) }}" required
                               @error('max_meals_per_day') aria-invalid="true" aria-describedby="max_meals_per_day_error" class="input-error" @enderror>
                        @error('max_meals_per_day')<p id="max_meals_per_day_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>

                    <div class="ds-field">
                        <label for="max_meals_per_week">Max repas / semaine</label>
                        <input id="max_meals_per_week" type="number" min="1" name="max_meals_per_week" value="{{ old('max_meals_per_week', $mealRule->max_meals_per_week) }}" required
                               @error('max_meals_per_week') aria-invalid="true" aria-describedby="max_meals_per_week_error" class="input-error" @enderror>
                        @error('max_meals_per_week')<p id="max_meals_per_week_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>
                </div>

                <div class="ds-field">
                    <label>Jours autorises</label>
                    <div class="ds-checkbox-group" role="group" aria-label="Jours autorises">
                        @foreach([1 => 'Lundi', 2 => 'Mardi', 3 => 'Mercredi', 4 => 'Jeudi', 5 => 'Vendredi', 6 => 'Samedi', 7 => 'Dimanche'] as $value => $label)
                            <label class="ds-checkbox" for="day_{{ $value }}">
                                <input id="day_{{ $value }}" type="checkbox" name="days_of_week[]" value="{{ $value }}" {{ in_array($value, $selectedDays) ? 'checked' : '' }}>
                                {{ $label }}
                            </label>
                        @endforeach
                    </div>
                    @error('days_of_week')<p class="ds-field-error">{{ $message }}</p>@enderror
                </div>

                <div class="ds-field">
                    <label class="ds-checkbox" for="authorize_for_all_employees">
                        <input id="authorize_for_all_employees" type="checkbox" name="authorize_for_all_employees" value="1" {{ old('authorize_for_all_employees', $mealRule->authorize_for_all_employees) ? 'checked' : '' }}>
                        Autoriser pour tous les employes existants
                    </label>
                </div>

                <div class="ds-field">
                    <label class="ds-checkbox" for="is_active">
                        <input id="is_active" type="checkbox" name="is_active" value="1" {{ old('is_active', $mealRule->is_active) ? 'checked' : '' }}>
                        Regle active
                    </label>
                </div>
            </section>

            <div class="ds-form-actions" style="margin-top:.6rem;">
                <a class="btn btn-secondary" href="{{ route('meal-rules.index') }}">Annuler</a>
                <button class="btn" type="submit">Mettre a jour</button>
            </div>
        </form>
    </x-admin.panel>
@endsection
