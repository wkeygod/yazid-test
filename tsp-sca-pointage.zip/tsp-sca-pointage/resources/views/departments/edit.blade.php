@extends('layouts.app')

@section('title', 'Modifier departement')
@section('topbar_actions')
    <a class="btn btn-secondary" href="{{ route('departments.index') }}">Retour liste</a>
@endsection

@section('content')
    <x-admin.panel>
        <x-admin.page-header title="Modifier departement" :subtitle="$department->name" />
        <form method="POST" action="{{ route('departments.update', $department) }}" class="ds-form" novalidate>
            @csrf
            @method('PUT')

            <section class="ds-form-section" aria-labelledby="department-main-title">
                <h3 id="department-main-title" class="ds-form-section-title">Configuration</h3>
                <p class="ds-form-section-subtitle">Mettre a jour le code et le nom du departement.</p>

                <div class="grid grid-2">
                    <div class="ds-field">
                        <label for="code">Code</label>
                        <input id="code" type="text" name="code" value="{{ old('code', $department->code) }}" required autofocus
                               @error('code') aria-invalid="true" aria-describedby="code_error" class="input-error" @enderror>
                        @error('code')<p id="code_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>

                    <div class="ds-field">
                        <label for="name">Nom</label>
                        <input id="name" type="text" name="name" value="{{ old('name', $department->name) }}" required
                               @error('name') aria-invalid="true" aria-describedby="name_error" class="input-error" @enderror>
                        @error('name')<p id="name_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>
                </div>

                <div class="ds-field">
                    <label class="ds-checkbox" for="is_active">
                        <input id="is_active" type="checkbox" name="is_active" value="1" {{ old('is_active', $department->is_active) ? 'checked' : '' }}>
                        Departement actif
                    </label>
                </div>
            </section>

            <div class="ds-form-actions" style="margin-top:.6rem;">
                <a class="btn btn-secondary" href="{{ route('departments.index') }}">Annuler</a>
                <button class="btn" type="submit">Mettre a jour</button>
            </div>
        </form>
    </x-admin.panel>
@endsection
