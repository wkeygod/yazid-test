@extends('layouts.app')

@section('title', 'Departements')
@section('topbar_actions')
    <a class="btn" href="{{ route('departments.create') }}">Nouveau departement</a>
@endsection

@section('content')
    <x-admin.panel>
        <x-admin.page-header title="Departements" subtitle="Segmentation organisationnelle des employes." />

        <x-admin.data-table class="table-sticky table-compact">
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Nom</th>
                    <th>Employes</th>
                    <th class="status-col">Actif</th>
                    <th class="actions-col">Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($departments as $department)
                    <tr>
                        <td>{{ $department->code }}</td>
                        <td>{{ $department->name }}</td>
                        <td>{{ $department->employees_count }}</td>
                        <td class="status-col">
                            <x-admin.badge :tone="$department->is_active ? 'active' : 'inactive'">
                                {{ $department->is_active ? 'Actif' : 'Inactif' }}
                            </x-admin.badge>
                        </td>
                        <td class="actions-col">
                            <x-admin.table-actions>
                                <a class="btn-action" href="{{ route('departments.edit', $department) }}">Modifier</a>
                                <form class="inline" method="POST" action="{{ route('departments.destroy', $department) }}"
                                      data-confirm="true"
                                      data-confirm-type="danger"
                                      data-confirm-title="Supprimer departement"
                                      data-confirm-message="Supprimer ce departement ? Cette action est irreversible.">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn-action btn-action-danger" type="submit">Supprimer</button>
                                </form>
                            </x-admin.table-actions>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5">
                            <x-admin.empty-state
                                title="Aucun departement trouve"
                                message="Ajoutez un departement pour segmenter les employes." />
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </x-admin.data-table>

        <div class="pager">{{ $departments->links() }}</div>
    </x-admin.panel>
@endsection
