@extends('layouts.app')

@section('title', 'Nouveau departement')
@section('topbar_actions')
    <a class="btn btn-secondary" href="{{ route('departments.index') }}">Retour liste</a>
@endsection

@section('content')
    <x-admin.panel>
        <x-admin.page-header title="Creer un departement" subtitle="Ajoutez un nouveau departement organisationnel." />
        <form method="POST" action="{{ route('departments.store') }}" class="ds-form" novalidate>
            @csrf

            <section class="ds-form-section" aria-labelledby="department-main-title">
                <h3 id="department-main-title" class="ds-form-section-title">Configuration</h3>
                <p class="ds-form-section-subtitle">Code et nom du departement.</p>

                <div class="grid grid-2">
                    <div class="ds-field">
                        <label for="code">Code</label>
                        <input id="code" type="text" name="code" value="{{ old('code') }}" required autofocus
                               @error('code') aria-invalid="true" aria-describedby="code_error" class="input-error" @enderror>
                        @error('code')<p id="code_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>

                    <div class="ds-field">
                        <label for="name">Nom</label>
                        <input id="name" type="text" name="name" value="{{ old('name') }}" required
                               @error('name') aria-invalid="true" aria-describedby="name_error" class="input-error" @enderror>
                        @error('name')<p id="name_error" class="ds-field-error">{{ $message }}</p>@enderror
                    </div>
                </div>

                <div class="ds-field">
                    <label class="ds-checkbox" for="is_active">
                        <input id="is_active" type="checkbox" name="is_active" value="1" {{ old('is_active', 1) ? 'checked' : '' }}>
                        Departement actif
                    </label>
                </div>
            </section>

            <div class="ds-form-actions" style="margin-top:.6rem;">
                <a class="btn btn-secondary" href="{{ route('departments.index') }}">Annuler</a>
                <button class="btn" type="submit">Enregistrer</button>
            </div>
        </form>
    </x-admin.panel>
@endsection
