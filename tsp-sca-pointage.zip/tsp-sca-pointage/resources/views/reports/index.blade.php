@extends('layouts.app')

@section('title', 'Reports')

@section('topbar_actions')
    <a class="btn" style="background:#5d708a;" href="{{ route('reports.index') }}">Réinitialiser</a>
@endsection

@section('content')
    @php
        $dateFrom = $filters['date_from'] ?? '';
        $dateTo = $filters['date_to'] ?? '';
        $departmentFilter = (int) ($filters['department_id'] ?? 0);
        $resultTypeFilter = $filters['result_type'] ?? '';
        $sourceFilter = $filters['source'] ?? 'all';
        $budgetPerDay = (float) ($filters['budget_per_day'] ?? 0);

        $dailyMax = (int) ($dailyReport->max('total') ?? 0);
        $weeklyMax = (int) ($weeklyReport->max('total') ?? 0);
        $monthlyMax = (int) ($monthlyReport->max('total') ?? 0);
        $denialMax = (int) ($denialReasons->max('count') ?? 0);

        $cmpTotal = $comparison['total'] ?? ['delta' => 0, 'pct' => null];
        $cmpAmount = $comparison['amount'] ?? ['delta' => 0, 'pct' => null];
        $cmpRejected = $comparison['rejected'] ?? ['delta' => 0, 'pct' => null];

        $trendClass = static function (float|int $delta): string {
            if ($delta > 0) {
                return 'trend-up';
            }
            if ($delta < 0) {
                return 'trend-down';
            }

            return 'trend-neutral';
        };

        $trendText = static function (float|int|null $pct): string {
            if ($pct === null) {
                return 'N/A';
            }

            $sign = $pct > 0 ? '+' : '';

            return $sign . number_format((float) $pct, 1) . '%';
        };
    @endphp

    <style>
        .report-grid {
            display: grid;
            gap: 1rem;
        }

        .report-alerts {
            display: grid;
            gap: .6rem;
        }

        .report-alert {
            border-radius: 12px;
            padding: .72rem .85rem;
            border: 1px solid transparent;
            box-shadow: 0 8px 20px rgba(14, 37, 64, 0.08);
        }

        .report-alert strong {
            display: block;
            margin-bottom: .12rem;
        }

        .report-alert-success { background: #e6f8ee; border-color: #bae7cc; color: #145b33; }
        .report-alert-info { background: #e9f2ff; border-color: #cddfff; color: #1d4f90; }
        .report-alert-warning { background: #fff3de; border-color: #f4d39d; color: #7a5210; }
        .report-alert-danger { background: #feeaea; border-color: #f5c0c0; color: #842626; }

        .compare-grid {
            display: grid;
            gap: .75rem;
            grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
        }

        .compare-card {
            border: 1px solid #d8e4f3;
            border-radius: 12px;
            background: linear-gradient(180deg, #ffffff, #f8fbff);
            padding: .72rem .8rem;
        }

        .compare-label {
            color: #5b7696;
            font-size: .76rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: .55px;
        }

        .compare-value {
            margin-top: .2rem;
            font-weight: 800;
            font-size: 1.02rem;
            color: #1a3f6d;
        }

        .compare-trend {
            margin-top: .2rem;
            font-weight: 700;
            font-size: .82rem;
        }

        .trend-up { color: #145b33; }
        .trend-down { color: #8f2b2b; }
        .trend-neutral { color: #5d738f; }

        .bar-track {
            width: 100%;
            height: 10px;
            border-radius: 999px;
            background: #e9f0fa;
            overflow: hidden;
        }

        .bar-fill {
            height: 100%;
            border-radius: 999px;
            background: linear-gradient(90deg, #1e5bb9, #4b86de);
        }

        .forecast-card {
            border: 1px solid #d8e4f3;
            border-radius: 12px;
            background: linear-gradient(180deg, #ffffff, #f8fbff);
            padding: .8rem;
        }

        .forecast-value {
            font-size: 1.15rem;
            font-weight: 800;
            color: #19406e;
            margin-top: .15rem;
        }
    </style>

    <x-admin.page-header title="Rapports opérationnels" subtitle="Centre de décision: alertes, comparaison, budget, prévision et export" />

    <div class="report-grid">
        <div class="card">
            <div class="panel-header">
                <h2>Filtres avancés</h2>
            </div>

            <x-admin.filter-bar action="{{ route('reports.index') }}">
                <div>
                    <label>Date début</label>
                    <input type="date" name="date_from" value="{{ $dateFrom }}">
                </div>

                <div>
                    <label>Date fin</label>
                    <input type="date" name="date_to" value="{{ $dateTo }}">
                </div>

                <div>
                    <label>Source</label>
                    <select name="source">
                        <option value="all" {{ $sourceFilter === 'all' ? 'selected' : '' }}>Tout</option>
                        <option value="employee" {{ $sourceFilter === 'employee' ? 'selected' : '' }}>Employés NFC</option>
                        <option value="la_releve" {{ $sourceFilter === 'la_releve' ? 'selected' : '' }}>La Relève</option>
                        <option value="extra" {{ $sourceFilter === 'extra' ? 'selected' : '' }}>Extra</option>
                    </select>
                </div>

                <div>
                    <label>Département</label>
                    <select name="department_id">
                        <option value="">Tous</option>
                        @foreach($departments as $department)
                            <option value="{{ $department->id }}" {{ $departmentFilter === (int) $department->id ? 'selected' : '' }}>{{ $department->name }}</option>
                        @endforeach
                    </select>
                </div>

                <div>
                    <label>Type résultat</label>
                    <select name="result_type">
                        <option value="">Tous</option>
                        <option value="approved" {{ $resultTypeFilter === 'approved' ? 'selected' : '' }}>Autorisé</option>
                        <option value="rejected" {{ $resultTypeFilter === 'rejected' ? 'selected' : '' }}>Refusé</option>
                    </select>
                </div>

                <div>
                    <label>Budget / jour</label>
                    <input type="number" step="0.01" min="0" name="budget_per_day" value="{{ number_format($budgetPerDay, 2, '.', '') }}" placeholder="0.00">
                </div>

                <div style="display:flex; gap:.45rem; flex-wrap:wrap;">
                    <button class="btn" type="submit">Appliquer</button>
                    <a class="btn export-link" style="background:#1f7a4f;" data-export-url="{{ route('reports.export', array_merge(request()->query(), ['format' => 'excel'])) }}" href="#">Exporter Excel Pro</a>
                    <a class="btn export-link" style="background:#3f6bb5;" data-export-url="{{ route('reports.export', array_merge(request()->query(), ['format' => 'json'])) }}" href="#">Exporter JSON</a>
                </div>
            </x-admin.filter-bar>
        </div>

        <div class="report-alerts">
            @foreach($alerts as $alert)
                <div class="report-alert report-alert-{{ $alert['level'] ?? 'info' }}">
                    <strong>{{ $alert['title'] ?? 'Information' }}</strong>
                    <span>{{ $alert['message'] ?? '' }}</span>
                </div>
            @endforeach
        </div>

        <div class="grid grid-2" style="margin-bottom: .2rem;">
            <x-admin.kpi-card label="Total logs" :value="number_format((int) $kpi['total_logs'])" />
            <x-admin.kpi-card label="Autorisés" :value="number_format((int) $kpi['approved_logs'])" tone="success" />
            <x-admin.kpi-card label="Refusés" :value="number_format((int) $kpi['rejected_logs'])" tone="danger" />
            <x-admin.kpi-card label="Taux d'approbation" :value="number_format((float) $kpi['approval_rate'], 1) . '%'" tone="info" />
            <x-admin.kpi-card label="Montant total" :value="number_format((float) $kpi['total_amount'], 2)" tone="info" />
            <x-admin.kpi-card label="Budget total" :value="number_format((float) $kpi['budget_total'], 2)" tone="primary" />
            <x-admin.kpi-card label="Écart budget" :value="number_format((float) $kpi['budget_gap'], 2)" :tone="(float) $kpi['budget_gap'] < 0 ? 'danger' : 'success'" />
            <x-admin.kpi-card label="Logs Employés" :value="number_format((int) $kpi['employee_logs'])" tone="primary" />
            <x-admin.kpi-card label="Logs La Relève" :value="number_format((int) $kpi['la_releve_logs'])" tone="primary" />
            <x-admin.kpi-card label="Logs Extra" :value="number_format((int) $kpi['extra_logs'])" tone="primary" />
        </div>

        <div class="card">
            <div class="panel-header">
                <h2>Comparaison vs période précédente</h2>
                <span class="muted">Période de référence: {{ $comparison['previous_period_label'] ?? '-' }}</span>
            </div>

            <div class="compare-grid">
                <div class="compare-card">
                    <div class="compare-label">Volume total</div>
                    <div class="compare-value">{{ number_format((int) ($cmpTotal['current'] ?? 0)) }}</div>
                    <div class="compare-trend {{ $trendClass($cmpTotal['delta'] ?? 0) }}">
                        Δ {{ number_format((float) ($cmpTotal['delta'] ?? 0), 0) }} • {{ $trendText($cmpTotal['pct'] ?? null) }}
                    </div>
                </div>

                <div class="compare-card">
                    <div class="compare-label">Montant total</div>
                    <div class="compare-value">{{ number_format((float) ($cmpAmount['current'] ?? 0), 2) }}</div>
                    <div class="compare-trend {{ $trendClass($cmpAmount['delta'] ?? 0) }}">
                        Δ {{ number_format((float) ($cmpAmount['delta'] ?? 0), 2) }} • {{ $trendText($cmpAmount['pct'] ?? null) }}
                    </div>
                </div>

                <div class="compare-card">
                    <div class="compare-label">Refus</div>
                    <div class="compare-value">{{ number_format((int) ($cmpRejected['current'] ?? 0)) }}</div>
                    <div class="compare-trend {{ $trendClass(($cmpRejected['delta'] ?? 0) * -1) }}">
                        Δ {{ number_format((float) ($cmpRejected['delta'] ?? 0), 0) }} • {{ $trendText($cmpRejected['pct'] ?? null) }}
                    </div>
                </div>

                <div class="forecast-card">
                    <div class="compare-label">Prévision (J+1)</div>
                    <div class="forecast-value">{{ number_format((int) ($forecast['next_day_total_estimate'] ?? 0)) }} logs</div>
                    <div class="muted" style="font-size:.82rem; margin-top:.2rem;">Montant estimé: {{ number_format((float) ($forecast['next_day_amount_estimate'] ?? 0), 2) }}</div>
                    <div class="muted" style="font-size:.78rem; margin-top:.2rem;">Basé sur {{ $forecast['reference_days'] ?? 0 }} jours récents</div>
                </div>
            </div>
        </div>

        <div class="grid" style="grid-template-columns:minmax(0, 1fr) minmax(0, 1fr);">
            <div class="card">
                <div class="panel-header">
                    <h3 style="margin:0;">Rapport journalier</h3>
                    <span class="muted">{{ $dailyReport->count() }} périodes</span>
                </div>

                @if($dailyReport->isEmpty())
                    <p class="muted">Aucune donnée.</p>
                @else
                    <table>
                        <thead>
                            <tr>
                                <th>Jour</th>
                                <th>Total</th>
                                <th>Autorisé</th>
                                <th>Refusé</th>
                                <th>Montant</th>
                                <th>Tendance</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($dailyReport->take(14) as $row)
                                @php($width = $dailyMax > 0 ? (int) round(($row['total'] / $dailyMax) * 100) : 0)
                                <tr>
                                    <td>{{ $row['bucket'] }}</td>
                                    <td>{{ $row['total'] }}</td>
                                    <td>{{ $row['approved'] }}</td>
                                    <td>{{ $row['rejected'] }}</td>
                                    <td>{{ number_format((float) $row['amount'], 2) }}</td>
                                    <td><span style="font-family:monospace; color:#1e5bb9; letter-spacing:1px;">{{ str_repeat('█', max(1, (int) floor($width / 6))) }}</span></td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                @endif
            </div>

            <div class="card">
                <div class="panel-header">
                    <h3 style="margin:0;">Rapport hebdomadaire</h3>
                    <span class="muted">{{ $weeklyReport->count() }} périodes</span>
                </div>

                @if($weeklyReport->isEmpty())
                    <p class="muted">Aucune donnée.</p>
                @else
                    <table>
                        <thead>
                            <tr>
                                <th>Semaine</th>
                                <th>Total</th>
                                <th>Autorisé</th>
                                <th>Refusé</th>
                                <th>Montant</th>
                                <th>Tendance</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($weeklyReport->take(12) as $row)
                                @php($width = $weeklyMax > 0 ? (int) round(($row['total'] / $weeklyMax) * 100) : 0)
                                <tr>
                                    <td>{{ $row['bucket'] }}</td>
                                    <td>{{ $row['total'] }}</td>
                                    <td>{{ $row['approved'] }}</td>
                                    <td>{{ $row['rejected'] }}</td>
                                    <td>{{ number_format((float) $row['amount'], 2) }}</td>
                                    <td><span style="font-family:monospace; color:#1e5bb9; letter-spacing:1px;">{{ str_repeat('█', max(1, (int) floor($width / 6))) }}</span></td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                @endif
            </div>
        </div>

        <div class="card">
            <div class="panel-header">
                <h3 style="margin:0;">Rapport mensuel</h3>
                <span class="muted">{{ $monthlyReport->count() }} périodes</span>
            </div>

            @if($monthlyReport->isEmpty())
                <p class="muted">Aucune donnée.</p>
            @else
                <table>
                    <thead>
                        <tr>
                            <th>Mois</th>
                            <th>Total</th>
                            <th>Autorisé</th>
                            <th>Refusé</th>
                            <th>Montant</th>
                            <th>Tendance</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($monthlyReport->take(12) as $row)
                            @php($width = $monthlyMax > 0 ? (int) round(($row['total'] / $monthlyMax) * 100) : 0)
                            <tr>
                                <td>{{ $row['bucket'] }}</td>
                                <td>{{ $row['total'] }}</td>
                                <td>{{ $row['approved'] }}</td>
                                <td>{{ $row['rejected'] }}</td>
                                <td>{{ number_format((float) $row['amount'], 2) }}</td>
                                <td><span style="font-family:monospace; color:#1e5bb9; letter-spacing:1px;">{{ str_repeat('█', max(1, (int) floor($width / 6))) }}</span></td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            @endif
        </div>

        <div class="grid" style="grid-template-columns:minmax(0, 1fr) minmax(0, 1fr);">
            <div class="card">
                <div class="panel-header">
                    <h3 style="margin:0;">Scorecards département</h3>
                    <span class="muted">{{ $departmentSummary->count() }} lignes</span>
                </div>

                @if($departmentSummary->isEmpty())
                    <p class="muted">Aucune donnée.</p>
                @else
                    <table>
                        <thead>
                            <tr>
                                <th>Département</th>
                                <th>Total</th>
                                <th>Autorisé</th>
                                <th>Refusé</th>
                                <th>Taux</th>
                                <th>Montant</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($departmentSummary as $row)
                                <tr>
                                    <td>{{ $row['label'] }}</td>
                                    <td>{{ $row['total'] }}</td>
                                    <td>{{ $row['approved'] }}</td>
                                    <td>{{ $row['rejected'] }}</td>
                                    <td>{{ number_format((float) $row['approval_rate'], 1) }}%</td>
                                    <td>{{ number_format((float) $row['amount'], 2) }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                @endif
            </div>

            <div class="card">
                <div class="panel-header">
                    <h3 style="margin:0;">Motifs de refus</h3>
                    <span class="muted">{{ $denialReasons->count() }} motifs</span>
                </div>

                @if($denialReasons->isEmpty())
                    <p class="muted">Aucun refus enregistré.</p>
                @else
                    <table>
                        <thead>
                            <tr>
                                <th>Motif</th>
                                <th>Occurrences</th>
                                <th>Poids</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($denialReasons as $row)
                                @php($width = $denialMax > 0 ? (int) round(($row['count'] / $denialMax) * 100) : 0)
                                <tr>
                                    <td>{{ $row['reason'] }}</td>
                                    <td>{{ $row['count'] }}</td>
                                    <td><span style="font-family:monospace; color:#c53030; letter-spacing:1px;">{{ str_repeat('█', max(1, (int) floor($width / 6))) }}</span></td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                @endif
            </div>
        </div>

        <div class="card">
            <div class="panel-header">
                <h3 style="margin:0;">Derniers logs inclus dans le rapport</h3>
                <span class="muted">{{ $latestLogs->count() }} lignes</span>
            </div>

            @if($latestLogs->isEmpty())
                <p class="muted">Aucun log.</p>
            @else
                <table>
                    <thead>
                        <tr>
                            <th>Date/Heure</th>
                            <th>Source</th>
                            <th>Résultat</th>
                            <th>Département</th>
                            <th>Plat</th>
                            <th>Montant</th>
                            <th>Motif</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($latestLogs as $log)
                            <tr>
                                <td>{{ \Carbon\Carbon::parse($log['at'])->format('Y-m-d H:i:s') }}</td>
                                <td>{{ strtoupper($log['source']) }}</td>
                                <td>
                                    <x-admin.badge :tone="$log['status'] === 'approved' ? 'approved' : 'rejected'">
                                        {{ $log['status'] === 'approved' ? 'AUTORISE' : 'REFUSE' }}
                                    </x-admin.badge>
                                </td>
                                <td>{{ $log['department'] ?: '-' }}</td>
                                <td>{{ $log['meal'] ?: '-' }}</td>
                                <td>{{ number_format((float) $log['amount'], 2) }}</td>
                                <td>{{ $log['reason'] ?: '-' }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            @endif
        </div>
    </div>
@endsection
