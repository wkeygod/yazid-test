@extends('layouts.app')

@section('title', 'La Releve')
@section('topbar_actions')
    <div style="display: flex; gap: 0.5rem;">
        <a class="btn" href="{{ route('la-releve.create', ['date' => $selectedDate]) }}">Nouvelle entrée</a>
        <a class="btn releve-import-csv" href="{{ route('la-releve.import', ['date' => $selectedDate]) }}">Importer des entrées</a>
    </div>
@endsection

@section('styles')
    <style>
        .releve-export-csv,
        .releve-import-csv {
            background: linear-gradient(180deg, #1f7a4f, #17613e) !important;
            color: white !important;
        }
    </style>
@endsection

@section('content')
    @php($mealTypeLabels = ['breakfast' => 'Petit-déjeuner', 'lunch' => 'Déjeuner', 'dinner' => 'Dîner'])

    <x-admin.panel>
        <x-admin.page-header title="La Releve" subtitle="Gestion des accès repas manuels sans carte NFC." />

        <div class="grid grid-2" style="margin-bottom:.9rem;">
            <x-admin.kpi-card label="Entrées du jour" :value="$summary['total_entries']" tone="primary" />
            <x-admin.kpi-card label="Ont déjà mangé" :value="$summary['already_eaten']" tone="info" />
            <x-admin.kpi-card label="Quota atteint" :value="$summary['quota_reached']" tone="danger" />
            <x-admin.kpi-card label="Repas restants" :value="$summary['remaining_meals_total']" tone="success" />
        </div>

        <div class="card" style="padding:.7rem .9rem; margin-bottom:.9rem;">
            <strong>Statistiques en temps réel (liste visible)</strong>
            <span class="muted" style="margin-left:.45rem;">
                Entrées: <strong id="live_total">{{ $summary['total_entries'] }}</strong> |
                Ont déjà mangé: <strong id="live_already">{{ $summary['already_eaten'] }}</strong> |
                Quota atteint: <strong id="live_quota">{{ $summary['quota_reached'] }}</strong> |
                Repas restants: <strong id="live_remaining">{{ $summary['remaining_meals_total'] }}</strong>
            </span>
        </div>

        <x-admin.filter-bar action="{{ route('la-releve.index') }}" style="margin-bottom:.9rem;">
            <div>
                <label>Mode de date</label>
                <select name="filter_mode" id="filter_mode">
                    <option value="day" {{ $filterMode === 'day' ? 'selected' : '' }}>Date unique</option>
                    <option value="range" {{ $filterMode === 'range' ? 'selected' : '' }}>Intervalle</option>
                </select>
            </div>
            <div>
                <label>Date (jour)</label>
                <input type="date" id="date_day" name="date" value="{{ $selectedDate }}">
            </div>
            <div>
                <label>Date début</label>
                <input type="date" id="date_from" name="date_from" value="{{ $selectedDateFrom }}">
            </div>
            <div>
                <label>Date fin</label>
                <input type="date" id="date_to" name="date_to" value="{{ $selectedDateTo }}">
            </div>
            <div>
                <label>Recherche (nom / poste / entreprise)</label>
                <input id="releve_realtime_search" type="text" name="q" value="{{ $search }}" placeholder="Ex: Ahmed Ali ou Soudeur" autocomplete="off">
            </div>
            <div class="actions" style="align-self: end;">
                <button class="btn" type="submit">Filtrer</button>
                <a class="btn btn-secondary" href="{{ route('la-releve.index') }}">Réinitialiser</a>
                <a class="btn releve-export-csv export-link" data-export-url="{{ route('la-releve.export', array_merge(request()->query(), ['format' => 'excel'])) }}" href="#">Exporter Excel Pro</a>
            </div>
        </x-admin.filter-bar>

        <div class="card" style="padding:.8rem; margin-bottom:.75rem;">
            <div class="panel-header" style="margin-bottom:.5rem;">
                <h3 style="margin:0;">Liste La Releve</h3>
                <span class="muted">Filtrée par la période sélectionnée</span>
            </div>

            <x-admin.data-table class="table-sticky table-compact">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Nom complet</th>
                        <th>Poste</th>
                        <th>RiG (entreprise)</th>
                        <th>Plats autorisés</th>
                        <th>Repas consommés</th>
                        <th>Restant</th>
                        <th>Statut</th>
                        <th class="actions-col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($entries as $entry)
                        @php($allowedTypes = collect($entry->allowed_meal_types ?? [])->filter(fn($type) => isset($mealTypeLabels[$type]))->values())
                        @php($allowedCount = $allowedTypes->count())
                        @php($consumedCount = (int) $entry->consumed_meals_count)
                        @php($remaining = max(0, $allowedCount - $consumedCount))
                        @php($statusClass = $remaining > 0 ? 'status-approved' : 'status-rejected')
                        @php($statusLabel = $remaining > 0 ? 'Autorisé' : 'Quota atteint')
                        <tr
                            data-releve-row
                            data-search="{{ strtolower(($entry->entry_date?->format('Y-m-d') ?? '') . ($entry->end_date ? ' ' . $entry->end_date->format('Y-m-d') : '') . ' ' . $entry->full_name . ' ' . ($entry->position ?? '') . ' ' . ($entry->rig_company ?? '') . ' ' . $allowedTypes->map(fn($v) => $mealTypeLabels[$v])->implode(' ')) }}"
                            data-consumed="{{ $consumedCount }}"
                            data-remaining="{{ $remaining }}"
                        >
                            <td>
                                @if($entry->end_date)
                                    <span style="font-size:0.85rem;">{{ $entry->entry_date->format('Y-m-d') }}<br><small class="muted">au</small><br>{{ $entry->end_date->format('Y-m-d') }}</span>
                                @else
                                    {{ optional($entry->entry_date)->format('Y-m-d') ?: '-' }}
                                @endif
                            </td>
                            <td>{{ $entry->full_name }}</td>
                            <td>{{ $entry->position ?: '-' }}</td>
                            <td>{{ $entry->rig_company ?: '-' }}</td>
                            <td>{{ $allowedTypes->map(fn($v) => $mealTypeLabels[$v])->implode(', ') ?: '-' }}</td>
                            <td>{{ $consumedCount }}</td>
                            <td>{{ $remaining }}</td>
                            <td><span class="status-badge {{ $statusClass }}">{{ $statusLabel }}</span></td>
                            <td>
                                @if($consumedCount === 0)
                                    <x-admin.table-actions>
                                        <a class="btn-action btn-action-info" href="{{ route('la-releve.edit', $entry) }}">Modifier</a>
                                    </x-admin.table-actions>
                                @else
                                    <span class="muted">Verrouillé</span>
                                @endif
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="9">
                                <x-admin.empty-state title="Aucune entrée La Releve" description="Créez une entrée pour autoriser un accès repas manuel." />
                            </td>
                        </tr>
                    @endforelse
                    <tr id="releve_no_results" hidden>
                        <td colspan="9">Aucun résultat trouvé pour la recherche en temps réel.</td>
                    </tr>
                </tbody>
            </x-admin.data-table>
        </div>

        <div class="pager">{{ $entries->links() }}</div>
    </x-admin.panel>

    <script>
        (function () {
            var modeSelect = document.getElementById('filter_mode');
            var dayInput = document.getElementById('date_day');
            var fromInput = document.getElementById('date_from');
            var toInput = document.getElementById('date_to');
            var filterForm = modeSelect ? modeSelect.closest('form') : null;
            var searchInput = document.getElementById('releve_realtime_search');
            var rows = Array.prototype.slice.call(document.querySelectorAll('tr[data-releve-row]'));
            var noResultsBox = document.getElementById('releve_no_results');
            var liveTotal = document.getElementById('live_total');
            var liveAlready = document.getElementById('live_already');
            var liveQuota = document.getElementById('live_quota');
            var liveRemaining = document.getElementById('live_remaining');

            if (!modeSelect || !dayInput || !fromInput || !toInput) {
                return;
            }

            function applyDateMode() {
                var isRange = modeSelect.value === 'range';
                dayInput.disabled = isRange;
                fromInput.disabled = !isRange;
                toInput.disabled = !isRange;
            }

            modeSelect.addEventListener('change', function () {
                applyDateMode();
                if (filterForm) {
                    filterForm.submit();
                }
            });
            applyDateMode();

            [dayInput, fromInput, toInput].forEach(function (input) {
                if (!input) {
                    return;
                }
                input.addEventListener('change', function () {
                    if (filterForm) {
                        filterForm.submit();
                    }
                });
            });

            function updateLiveStats() {
                if (!liveTotal || !liveAlready || !liveQuota || !liveRemaining) {
                    return;
                }

                var visibleRows = rows.filter(function (row) {
                    return row.style.display !== 'none';
                });

                var total = visibleRows.length;
                var already = 0;
                var quota = 0;
                var remainingSum = 0;

                visibleRows.forEach(function (row) {
                    var consumed = Number(row.getAttribute('data-consumed') || '0');
                    var remaining = Number(row.getAttribute('data-remaining') || '0');
                    if (consumed > 0) {
                        already += 1;
                    }
                    if (remaining <= 0) {
                        quota += 1;
                    }
                    remainingSum += remaining;
                });

                liveTotal.textContent = String(total);
                liveAlready.textContent = String(already);
                liveQuota.textContent = String(quota);
                liveRemaining.textContent = String(remainingSum);
            }

            function applyRealtimeFilter() {
                if (!searchInput) {
                    return;
                }

                var term = (searchInput.value || '').toLowerCase().trim();
                rows.forEach(function (row) {
                    var haystack = (row.getAttribute('data-search') || '').toLowerCase();
                    var visible = term === '' || haystack.indexOf(term) !== -1;
                    row.style.display = visible ? '' : 'none';
                });

                updateLiveStats();

                var visibleRows = rows.filter(function (row) {
                    return row.style.display !== 'none';
                }).length;
                if (noResultsBox) {
                    noResultsBox.style.display = visibleRows === 0 ? '' : 'none';
                }
            }

            if (searchInput) {
                searchInput.addEventListener('input', applyRealtimeFilter);
            }

            applyRealtimeFilter();
        })();
    </script>
@endsection
