@extends('layouts.app')

@section('title', 'La Releve - Nouveau')
@section('topbar_actions')
    <a class="btn btn-secondary" href="{{ route('la-releve.index', ['date' => $selectedDate]) }}">Retour liste</a>
@endsection

@section('content')
    <x-admin.panel>
        <x-admin.page-header title="Nouvelle entrée La Releve" subtitle="Ajout manuel des personnes autorisées pour la journée." />

        <form method="POST" action="{{ route('la-releve.store') }}" class="ds-form" novalidate>
            @include('la-releve._form', [
                'entry' => null,
                'selectedDate' => $selectedDate,
                'mealTypeOptions' => $mealTypeOptions,
            ])
        </form>
    </x-admin.panel>
@endsection
