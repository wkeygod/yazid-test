@extends('layouts.app')

@section('title', 'La Releve - Modifier')
@section('topbar_actions')
    <a class="btn btn-secondary" href="{{ route('la-releve.index', ['date' => optional($entry->entry_date)->format('Y-m-d')]) }}">Retour liste</a>
@endsection

@section('content')
    <x-admin.panel>
        <x-admin.page-header title="Modifier entrée La Releve" subtitle="Mise à jour des autorisations manuelles." />

        <form method="POST" action="{{ route('la-releve.update', $entry) }}" class="ds-form" novalidate>
            @method('PUT')
            @include('la-releve._form', [
                'entry' => $entry,
                'selectedDate' => optional($entry->entry_date)->format('Y-m-d'),
                'mealTypeOptions' => $mealTypeOptions,
            ])
        </form>
    </x-admin.panel>
@endsection
