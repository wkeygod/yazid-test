@extends('layouts.app')

@section('title', 'La Releve - Import')
@section('topbar_actions')
    <a class="btn btn-secondary" href="{{ route('la-releve.index', ['date' => $selectedDate]) }}">← Retour liste</a>
@endsection

@section('styles')
    <style>
        .import-hero {
            text-align: center;
            padding: 1.5rem 1rem 1rem;
            margin-bottom: 1rem;
        }

        .import-hero-icon {
            width: 56px;
            height: 56px;
            margin: 0 auto .75rem;
            border-radius: 16px;
            background: linear-gradient(135deg, var(--primary), var(--ok));
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 8px 24px rgba(17, 102, 156, 0.25);
            animation: heroFloat 3s ease-in-out infinite alternate;
        }

        @keyframes heroFloat {
            0% { transform: translateY(0); }
            100% { transform: translateY(-4px); }
        }

        .import-hero-icon svg {
            width: 28px;
            height: 28px;
            fill: #fff;
        }

        .import-hero h2 {
            margin: 0 0 .35rem;
            font-size: 1.2rem;
            font-weight: 800;
            color: #163b6c;
        }

        .import-hero p {
            margin: 0;
            color: var(--muted);
            font-size: .88rem;
        }

        /* Drop zone */
        .import-dropzone {
            border: 2px dashed #c0d4ee;
            border-radius: var(--radius);
            padding: 2rem 1.5rem;
            text-align: center;
            cursor: pointer;
            transition: all .25s ease;
            background: linear-gradient(180deg, #f8fbff, #f0f6ff);
            position: relative;
            overflow: hidden;
        }

        .import-dropzone::before {
            content: "";
            position: absolute;
            inset: 0;
            background: radial-gradient(circle at 50% 50%, rgba(17, 102, 156, 0.04), transparent 70%);
            pointer-events: none;
        }

        .import-dropzone:hover,
        .import-dropzone.drag-over {
            border-color: var(--primary);
            background: linear-gradient(180deg, #f0f6ff, #e6f0ff);
            transform: scale(1.005);
            box-shadow: 0 0 0 4px rgba(17, 102, 156, 0.08);
        }

        .import-dropzone.has-file {
            border-color: var(--ok);
            border-style: solid;
            background: linear-gradient(180deg, #f0faf5, #e5f7ee);
        }

        .import-dropzone-icon {
            width: 48px;
            height: 48px;
            margin: 0 auto .75rem;
            border-radius: 14px;
            background: rgba(17, 102, 156, 0.08);
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all .25s ease;
        }

        .import-dropzone:hover .import-dropzone-icon,
        .import-dropzone.drag-over .import-dropzone-icon {
            background: rgba(17, 102, 156, 0.14);
            transform: translateY(-2px);
        }

        .import-dropzone.has-file .import-dropzone-icon {
            background: rgba(33, 138, 80, 0.12);
        }

        .import-dropzone-icon svg {
            width: 24px;
            height: 24px;
        }

        .import-dropzone-text {
            font-size: .92rem;
            font-weight: 700;
            color: #2e4f78;
            margin-bottom: .25rem;
        }

        .import-dropzone-hint {
            font-size: .8rem;
            color: var(--muted);
        }

        .import-dropzone-file {
            display: none;
            align-items: center;
            justify-content: center;
            gap: .5rem;
            margin-top: .5rem;
            padding: .45rem .75rem;
            background: rgba(33, 138, 80, 0.08);
            border-radius: var(--radius-pill);
            font-size: .82rem;
            font-weight: 700;
            color: var(--ok);
        }

        .import-dropzone.has-file .import-dropzone-file {
            display: inline-flex;
        }

        .import-dropzone.has-file .import-dropzone-text,
        .import-dropzone.has-file .import-dropzone-hint {
            display: none;
        }

        .import-dropzone input[type="file"] {
            position: absolute;
            inset: 0;
            opacity: 0;
            cursor: pointer;
            margin: 0;
            padding: 0;
            border: 0;
        }

        /* Format badges */
        .format-badges {
            display: flex;
            flex-wrap: wrap;
            gap: .45rem;
            justify-content: center;
            margin-top: .65rem;
        }

        .format-badge {
            display: inline-flex;
            align-items: center;
            gap: .3rem;
            padding: .28rem .6rem;
            border-radius: var(--radius-pill);
            font-size: .72rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: .4px;
        }

        .format-badge-csv {
            background: #e8f2ff;
            color: #2f5d9d;
        }

        .format-badge-excel {
            background: #e5f7ee;
            color: #11552f;
        }

        /* Info card */
        .import-info-card {
            display: grid;
            grid-template-columns: auto 1fr;
            gap: .75rem;
            padding: .85rem;
            border-radius: var(--radius-sm);
            background: linear-gradient(135deg, #f0f6ff, #f7faff);
            border: 1px solid #dbe8f8;
            margin-bottom: .9rem;
        }

        .import-info-icon {
            width: 36px;
            height: 36px;
            border-radius: 10px;
            background: linear-gradient(135deg, var(--primary), var(--primary-2));
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .import-info-icon svg {
            width: 18px;
            height: 18px;
            fill: #fff;
        }

        .import-info-content h4 {
            margin: 0 0 .3rem;
            font-size: .88rem;
            font-weight: 800;
            color: #163b6c;
        }

        .import-info-columns {
            display: flex;
            flex-wrap: wrap;
            gap: .35rem;
            margin-bottom: .3rem;
        }

        .import-col-tag {
            display: inline-flex;
            align-items: center;
            gap: .2rem;
            padding: .2rem .5rem;
            border-radius: 8px;
            font-size: .76rem;
            font-weight: 700;
        }

        .import-col-required {
            background: #e8f2ff;
            color: #2056a1;
            border: 1px solid #c8ddf7;
        }

        .import-col-optional {
            background: #f5f7fa;
            color: #6b8098;
            border: 1px solid #e0e8f0;
        }

        .import-col-tag .dot {
            width: 5px;
            height: 5px;
            border-radius: 50%;
        }

        .import-col-required .dot {
            background: #2056a1;
        }

        .import-col-optional .dot {
            background: #9aadbe;
        }

        .import-info-note {
            font-size: .78rem;
            color: var(--muted);
            margin: 0;
        }

        /* Date section */
        .import-dates {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: .75rem;
        }

        /* Meal type cards */
        .meal-type-cards {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: .65rem;
        }

        .meal-type-card {
            position: relative;
            cursor: pointer;
            margin: 0;
        }

        .meal-type-card input[type="checkbox"] {
            position: absolute;
            opacity: 0;
            pointer-events: none;
        }

        .meal-type-card-body {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: .45rem;
            padding: .85rem .5rem;
            border-radius: var(--radius-sm);
            border: 2px solid #dbe8f8;
            background: linear-gradient(180deg, #fff, #f8fbff);
            transition: all .2s ease;
        }

        .meal-type-card input:checked + .meal-type-card-body {
            border-color: var(--primary);
            background: linear-gradient(180deg, #e8f2ff, #f0f6ff);
            box-shadow: 0 0 0 3px rgba(17, 102, 156, 0.1);
        }

        .meal-type-card:hover .meal-type-card-body {
            border-color: #b0c8e8;
            transform: translateY(-1px);
        }

        .meal-type-card-emoji {
            font-size: 1.6rem;
            line-height: 1;
        }

        .meal-type-card-name {
            font-size: .82rem;
            font-weight: 800;
            color: #2e4f78;
            text-align: center;
        }

        .meal-type-card-check {
            position: absolute;
            top: .45rem;
            right: .45rem;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: #dbe8f8;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all .2s ease;
        }

        .meal-type-card input:checked + .meal-type-card-body .meal-type-card-check {
            background: var(--primary);
        }

        .meal-type-card-check svg {
            width: 12px;
            height: 12px;
            fill: #fff;
            opacity: 0;
            transition: opacity .2s ease;
        }

        .meal-type-card input:checked + .meal-type-card-body .meal-type-card-check svg {
            opacity: 1;
        }

        /* Actions */
        .import-actions {
            display: flex;
            gap: .65rem;
            align-items: center;
            justify-content: flex-end;
            padding-top: .5rem;
        }

        .import-actions .btn {
            padding: .62rem 1.4rem;
            font-size: .88rem;
        }

        .btn-import {
            background: linear-gradient(135deg, var(--ok), var(--ok-2)) !important;
            box-shadow: 0 8px 18px rgba(33, 138, 80, 0.25) !important;
        }

        .btn-import:hover {
            box-shadow: 0 12px 22px rgba(33, 138, 80, 0.35) !important;
        }

        .btn-import {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: .4rem;
        }

        .btn-import[disabled] {
            cursor: wait;
            opacity: .78;
            transform: none !important;
            box-shadow: 0 8px 18px rgba(33, 138, 80, 0.16) !important;
        }

        .btn-import-spinner {
            display: none;
            width: 16px;
            height: 16px;
            border: 2px solid rgba(255, 255, 255, .45);
            border-top-color: #fff;
            border-radius: 50%;
            animation: importSpin .75s linear infinite;
        }

        .btn-import.is-loading .btn-import-spinner {
            display: inline-block;
        }

        .btn-import.is-loading .btn-import-icon {
            display: none;
        }

        @keyframes importSpin {
            to { transform: rotate(360deg); }
        }

        /* Error alert */
        .import-alert {
            display: flex;
            align-items: flex-start;
            gap: .65rem;
            padding: .85rem;
            border-radius: var(--radius-sm);
            margin-bottom: .9rem;
            animation: riseIn .3s ease;
        }

        .import-alert-danger {
            background: linear-gradient(135deg, #fef0f0, #fff5f5);
            border: 1px solid #f5c0c0;
        }

        .import-alert-icon {
            width: 32px;
            height: 32px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .import-alert-danger .import-alert-icon {
            background: rgba(201, 55, 55, 0.1);
        }

        .import-alert-danger .import-alert-icon svg {
            fill: var(--danger);
        }

        .import-alert-content {
            flex: 1;
            min-width: 0;
        }

        .import-alert-title {
            font-size: .85rem;
            font-weight: 800;
            color: #842b33;
            margin-bottom: .15rem;
        }

        .import-alert-message {
            font-size: .82rem;
            color: #9c4a4a;
            line-height: 1.4;
        }

        /* Steps indicator */
        .import-steps {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: .5rem;
            margin-bottom: 1.2rem;
        }

        .import-step {
            display: flex;
            align-items: center;
            gap: .4rem;
        }

        .import-step-num {
            width: 26px;
            height: 26px;
            border-radius: 50%;
            background: #dbe8f8;
            color: #6b8098;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: .72rem;
            font-weight: 800;
        }

        .import-step.active .import-step-num {
            background: linear-gradient(135deg, var(--primary), var(--primary-2));
            color: #fff;
            box-shadow: 0 4px 12px rgba(17, 102, 156, 0.25);
        }

        .import-step-label {
            font-size: .78rem;
            font-weight: 700;
            color: #8ba0b8;
        }

        .import-step.active .import-step-label {
            color: #2e4f78;
        }

        .import-step-line {
            width: 32px;
            height: 2px;
            background: #dbe8f8;
            border-radius: 2px;
        }

        @media (max-width: 680px) {
            .meal-type-cards {
                grid-template-columns: 1fr;
            }

            .import-dates {
                grid-template-columns: 1fr;
            }

            .import-actions {
                flex-direction: column;
            }

            .import-actions .btn {
                width: 100%;
            }
        }
    </style>
@endsection

@section('content')
    @php($mealTypeLabels = ['breakfast' => 'Petit-déjeuner', 'lunch' => 'Déjeuner', 'dinner' => 'Dîner'])
    @php($mealTypeEmojis = ['breakfast' => '☀️', 'lunch' => '🍽️', 'dinner' => '🌙'])

    <x-admin.panel>
        {{-- Hero --}}
        <div class="import-hero">
            <div class="import-hero-icon">
                <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6zm-1 8V3.5L18.5 9H13zM8 17h8v-2H8v2zm0-4h8v-2H8v2z"/></svg>
            </div>
            <h2>Importer des entrées</h2>
            <p>Importez vos listes de personnes depuis un fichier CSV ou Excel</p>
            <div class="format-badges">
                <span class="format-badge format-badge-csv">📄 CSV</span>
                <span class="format-badge format-badge-csv">📝 TXT</span>
                <span class="format-badge format-badge-excel">📊 XLSX</span>
                <span class="format-badge format-badge-excel">📗 XLS</span>
            </div>
        </div>

        {{-- Steps --}}
        <div class="import-steps">
            <div class="import-step active">
                <span class="import-step-num">1</span>
                <span class="import-step-label">Fichier</span>
            </div>
            <div class="import-step-line"></div>
            <div class="import-step active">
                <span class="import-step-num">2</span>
                <span class="import-step-label">Période</span>
            </div>
            <div class="import-step-line"></div>
            <div class="import-step active">
                <span class="import-step-num">3</span>
                <span class="import-step-label">Repas</span>
            </div>
        </div>

        {{-- Error --}}
        @if(session('error'))
            <div class="import-alert import-alert-danger">
                <div class="import-alert-icon">
                    <svg width="16" height="16" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
                </div>
                <div class="import-alert-content">
                    <div class="import-alert-title">Erreur lors de l'importation</div>
                    <div class="import-alert-message">{{ session('error') }}</div>
                </div>
            </div>
        @endif

        <form method="POST" action="{{ route('la-releve.import.store') }}" enctype="multipart/form-data" class="ds-form" id="la-releve-import-form" novalidate>
            @csrf

            {{-- Section 1: File Upload --}}
            <div class="ds-form-section">
                <h3 class="ds-form-section-title">📁 Sélection du fichier</h3>
                <p class="ds-form-section-subtitle">Glissez-déposez ou cliquez pour sélectionner votre fichier.</p>

                <div class="import-dropzone" id="dropzone">
                    <input id="csv_file" type="file" name="csv_file" accept=".csv,.txt,.xlsx,.xls" required
                           @error('csv_file') class="input-error" @enderror>
                    <div class="import-dropzone-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#3f7ec7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
                            <polyline points="17 8 12 3 7 8"/>
                            <line x1="12" y1="3" x2="12" y2="15"/>
                        </svg>
                    </div>
                    <div class="import-dropzone-text">Cliquez ici ou glissez votre fichier</div>
                    <div class="import-dropzone-hint">Formats acceptés : CSV, TXT, XLSX, XLS</div>
                    <div class="import-dropzone-file">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                        <span id="dropzone-filename">fichier.csv</span>
                    </div>
                </div>
                @error('csv_file')<p class="ds-field-error">{{ $message }}</p>@enderror

                {{-- Info card --}}
                <div class="import-info-card">
                    <div class="import-info-icon">
                        <svg width="18" height="18" viewBox="0 0 24 24"><path d="M11 7h2v2h-2zm0 4h2v6h-2zm1-9C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/></svg>
                    </div>
                    <div class="import-info-content">
                        <h4>Colonnes attendues</h4>
                        <div class="import-info-columns">
                            <span class="import-col-tag import-col-required"><span class="dot"></span> Nom complet</span>
                            <span class="import-col-tag import-col-required"><span class="dot"></span> Identifiant</span>
                            <span class="import-col-tag import-col-required"><span class="dot"></span> First Name + Last Name</span>
                            <span class="import-col-tag import-col-optional"><span class="dot"></span> Poste</span>
                            <span class="import-col-tag import-col-optional"><span class="dot"></span> Entreprise</span>
                        </div>
                        <p class="import-info-note">L'importateur détecte automatiquement les en-têtes. Les alias comme <em>Nom</em>, <em>Matricule</em>, <em>N</em>, <em>Code</em>, <em>Crew</em>, <em>Compagnie</em> sont aussi acceptés.</p>
                    </div>
                </div>
            </div>

            {{-- Section 2: Dates --}}
            <div class="ds-form-section">
                <h3 class="ds-form-section-title">📅 Période d'autorisation</h3>
                <p class="ds-form-section-subtitle">Définissez la période pendant laquelle les personnes importées auront accès aux repas.</p>

                <div class="import-dates">
                    <div class="ds-field">
                        <label for="entry_date">Date début <span class="text-danger">*</span></label>
                        <input id="entry_date" type="date" name="entry_date" value="{{ old('entry_date', $selectedDate) }}" required
                               @error('entry_date') class="input-error" @enderror>
                        @error('entry_date')<p class="ds-field-error">{{ $message }}</p>@enderror
                    </div>

                    <div class="ds-field">
                        <label for="end_date">Date fin <span class="muted" style="font-weight:400;">(optionnelle)</span></label>
                        <input id="end_date" type="date" name="end_date" value="{{ old('end_date') }}"
                               @error('end_date') class="input-error" @enderror>
                        @error('end_date')<p class="ds-field-error">{{ $message }}</p>@enderror
                    </div>
                </div>
            </div>

            {{-- Section 3: Meal Types --}}
            <div class="ds-form-section">
                <h3 class="ds-form-section-title">🍽️ Plats autorisés</h3>
                <p class="ds-form-section-subtitle">Sélectionnez les repas auxquels ces personnes auront droit.</p>

                @php($selectedMealTypes = collect(old('allowed_meal_types', ['breakfast', 'lunch', 'dinner']))->all())
                <div class="meal-type-cards">
                    @foreach($mealTypeOptions as $type)
                        <label class="meal-type-card">
                            <input type="checkbox" name="allowed_meal_types[]" value="{{ $type }}" {{ in_array($type, $selectedMealTypes, true) ? 'checked' : '' }}>
                            <div class="meal-type-card-body">
                                <div class="meal-type-card-check">
                                    <svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/></svg>
                                </div>
                                <span class="meal-type-card-emoji">{{ $mealTypeEmojis[$type] ?? '🍴' }}</span>
                                <span class="meal-type-card-name">{{ $mealTypeLabels[$type] ?? $type }}</span>
                            </div>
                        </label>
                    @endforeach
                </div>
                @error('allowed_meal_types')<p class="ds-field-error">{{ $message }}</p>@enderror
                @error('allowed_meal_types.*')<p class="ds-field-error">{{ $message }}</p>@enderror
            </div>

            {{-- Actions --}}
            <div class="import-actions">
                <a class="btn btn-secondary" href="{{ route('la-releve.index', ['date' => $selectedDate]) }}">Annuler</a>
                <button class="btn btn-import" type="submit" id="la-releve-import-submit" data-loading-text="Importation...">
                    <span class="btn-import-spinner" aria-hidden="true"></span>
                    <svg class="btn-import-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>
                    </svg>
                    <span class="btn-import-label">Importer les entrées</span>
                </button>
            </div>
        </form>
    </x-admin.panel>

    <script>
        (function () {
            var dropzone = document.getElementById('dropzone');
            var fileInput = document.getElementById('csv_file');
            var filenameSpan = document.getElementById('dropzone-filename');
            var form = document.getElementById('la-releve-import-form');
            var submitBtn = document.getElementById('la-releve-import-submit');
            var submitLabel = submitBtn ? submitBtn.querySelector('.btn-import-label') : null;
            var hasSubmitted = false;

            if (!dropzone || !fileInput) return;

            // Drag & drop events
            ['dragenter', 'dragover'].forEach(function (evt) {
                dropzone.addEventListener(evt, function (e) {
                    e.preventDefault();
                    dropzone.classList.add('drag-over');
                });
            });

            ['dragleave', 'drop'].forEach(function (evt) {
                dropzone.addEventListener(evt, function (e) {
                    e.preventDefault();
                    dropzone.classList.remove('drag-over');
                });
            });

            dropzone.addEventListener('drop', function (e) {
                if (e.dataTransfer && e.dataTransfer.files.length > 0) {
                    fileInput.files = e.dataTransfer.files;
                    updateFilename();
                }
            });

            fileInput.addEventListener('change', updateFilename);

            function updateFilename() {
                if (fileInput.files && fileInput.files.length > 0) {
                    var name = fileInput.files[0].name;
                    filenameSpan.textContent = name;
                    dropzone.classList.add('has-file');
                } else {
                    dropzone.classList.remove('has-file');
                }
            }

            if (form && submitBtn) {
                form.addEventListener('submit', function (e) {
                    if (hasSubmitted) {
                        e.preventDefault();
                        return;
                    }

                    hasSubmitted = true;
                    submitBtn.disabled = true;
                    submitBtn.classList.add('is-loading');
                    submitBtn.setAttribute('aria-busy', 'true');

                    if (submitLabel) {
                        submitLabel.textContent = submitBtn.dataset.loadingText || 'Importation...';
                    }
                });
            }
        })();
    </script>
@endsection
