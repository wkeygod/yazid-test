@csrf

@php($mealTypeLabels = ['breakfast' => 'Petit-déjeuner', 'lunch' => 'Déjeuner', 'dinner' => 'Dîner'])

<div class="ds-form-section" aria-labelledby="releve-main-title">
    <h3 id="releve-main-title" class="ds-form-section-title">Informations principales</h3>
    <p class="ds-form-section-subtitle">Renseignez uniquement les informations nécessaires pour l'employé.</p>

    <div class="grid grid-2">
        <div class="ds-field">
            <label for="full_name">Nom et prénom</label>
            <input id="full_name" type="text" name="full_name" value="{{ old('full_name', $entry->full_name ?? '') }}" required
                   @error('full_name') class="input-error" @enderror>
            @error('full_name')<p class="ds-field-error">{{ $message }}</p>@enderror
        </div>

        <div class="ds-field">
            <label for="position">Poste</label>
            <input id="position" type="text" name="position" value="{{ old('position', $entry->position ?? '') }}" required
                   @error('position') class="input-error" @enderror>
            @error('position')<p class="ds-field-error">{{ $message }}</p>@enderror
        </div>

        <div class="ds-field">
            <label for="entry_date">Date début <span class="text-danger">*</span></label>
            <input id="entry_date" type="date" name="entry_date" value="{{ old('entry_date', isset($entry) ? optional($entry->entry_date)->format('Y-m-d') : $selectedDate) }}" required
                   @error('entry_date') class="input-error" @enderror>
            @error('entry_date')<p class="ds-field-error">{{ $message }}</p>@enderror
        </div>

        <div class="ds-field">
            <label for="end_date">Date fin (optionnelle)</label>
            <input id="end_date" type="date" name="end_date" value="{{ old('end_date', (isset($entry) && $entry->end_date) ? $entry->end_date->format('Y-m-d') : '') }}"
                   @error('end_date') class="input-error" @enderror>
            @error('end_date')<p class="ds-field-error">{{ $message }}</p>@enderror
        </div>

        <div class="ds-field">
            <label for="rig_company">RiG (entreprise)</label>
            <input id="rig_company" type="text" name="rig_company" value="{{ old('rig_company', $entry->rig_company ?? '') }}" required
                   @error('rig_company') class="input-error" @enderror>
            @error('rig_company')<p class="ds-field-error">{{ $message }}</p>@enderror
        </div>
    </div>
</div>

<div class="ds-form-section" aria-labelledby="releve-meal-types-title">
    <h3 id="releve-meal-types-title" class="ds-form-section-title">Plats autorisés</h3>
    <p class="ds-form-section-subtitle">Cochez un ou plusieurs plats parmi les 3 plats disponibles.</p>

    @php($selectedMealTypes = collect(old('allowed_meal_types', $entry->allowed_meal_types ?? []))->all())
    <div class="ds-checkbox-group">
        @foreach($mealTypeOptions as $type)
            <label class="ds-checkbox">
                <input type="checkbox" name="allowed_meal_types[]" value="{{ $type }}" {{ in_array($type, $selectedMealTypes, true) ? 'checked' : '' }}>
                <span>{{ $mealTypeLabels[$type] ?? $type }}</span>
            </label>
        @endforeach
    </div>
    @error('allowed_meal_types')<p class="ds-field-error">{{ $message }}</p>@enderror
    @error('allowed_meal_types.*')<p class="ds-field-error">{{ $message }}</p>@enderror
</div>

<div class="ds-form-section" aria-labelledby="releve-notes-title">
    <h3 id="releve-notes-title" class="ds-form-section-title">Notes</h3>
    <textarea id="notes" name="notes" rows="4" placeholder="Notes opérationnelles (optionnel)" @error('notes') class="input-error" @enderror>{{ old('notes', $entry->notes ?? '') }}</textarea>
    @error('notes')<p class="ds-field-error">{{ $message }}</p>@enderror
</div>

<div class="ds-form-actions">
    <button class="btn" type="submit">Enregistrer</button>
    <a class="btn btn-secondary" href="{{ route('la-releve.index') }}">Annuler</a>
</div>
