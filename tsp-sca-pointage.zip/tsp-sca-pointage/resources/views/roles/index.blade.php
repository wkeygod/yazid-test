@extends('layouts.app')

@section('content')
<div class="container-fluid px-4 py-6">
    <x-admin.page-header title="Gestion des utilisateurs" subtitle="Modifier les rôles, mot de passe et accès des utilisateurs" />

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i>{{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <div class="card shadow-sm">
        <div class="card-header d-flex flex-wrap align-items-center justify-content-between gap-2 bg-light">
            <h6 class="mb-0 text-dark fw-bold">
                <i class="fas fa-users me-2"></i>Liste des employés ({{ $users->total() }})
            </h6>

            <a href="{{ route('roles.create') }}" class="btn btn-success">
                <i class="fas fa-plus me-1"></i>Nouveau utilisateur
            </a>
        </div>

        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0 align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Nom</th>
                            <th>Email</th>
                            <th>Accès</th>
                            <th class="text-center" style="width: 230px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($users as $user)
                            @php
                                $permissionCount = $user->roles->flatMap(fn($role) => $role->permissions)->unique('id')->count();
                            @endphp

                            <tr>
                                <td class="fw-semibold">
                                    {{ $user->first_name }} {{ $user->last_name }}
                                    @if($user->is_admin)
                                        <span class="badge bg-primary ms-2">Admin</span>
                                    @endif
                                </td>
                                <td class="text-muted">{{ $user->email }}</td>
                                <td>
                                    @if($user->is_admin)
                                        <span class="badge bg-primary">Accès complet</span>
                                    @else
                                        <span class="badge bg-info">{{ $permissionCount }} page(s)</span>
                                    @endif
                                </td>
                                <td class="text-center">
                                    @if(!$user->is_admin)
                                        <a href="{{ route('roles.edit', $user) }}" class="btn btn-sm btn-outline-primary" title="Modifier utilisateur">
                                            <i class="fas fa-pen me-1"></i>Modifier
                                        </a>

                                        <form action="{{ route('roles.destroy', $user) }}" method="POST" class="d-inline"
                                              data-confirm="true"
                                              data-confirm-type="danger"
                                              data-confirm-title="Supprimer utilisateur"
                                              data-confirm-message="Supprimer l'utilisateur {{ $user->first_name }} {{ $user->last_name }} ? Cette action est irreversible."
                                              data-confirm-cancel-label="Annuler"
                                              data-confirm-approve-label="Supprimer">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-outline-danger" title="Supprimer utilisateur">
                                                <i class="fas fa-trash me-1"></i>Supprimer
                                            </button>
                                        </form>
                                    @else
                                        <span class="badge bg-secondary">Non modifiable</span>
                                    @endif
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="4" class="text-center py-5 text-muted">
                                    <i class="fas fa-inbox fa-2x d-block mb-2 opacity-50"></i>
                                    Aucun utilisateur trouvé.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        @if($users->hasPages())
            <div class="card-footer bg-light">
                {{ $users->links('pagination::bootstrap-4') }}
            </div>
        @endif
    </div>
</div>

@endsection

@section('scripts')
@endsection
