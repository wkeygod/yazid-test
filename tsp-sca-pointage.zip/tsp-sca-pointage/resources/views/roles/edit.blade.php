@extends('layouts.app')

@section('content')
<div class="container-fluid px-4 py-6">
    <x-admin.page-header title="Modifier utilisateur" subtitle="Modifier les rôles, informations et mot de passe" />

    <div class="row justify-content-center">
        <div class="col-xl-8 col-lg-10">
            <div class="card shadow-sm">
                <div class="card-header d-flex justify-content-between align-items-center bg-light">
                    <h6 class="mb-0 fw-bold text-dark">
                        <i class="fas fa-user-edit me-2"></i>{{ $user->first_name }} {{ $user->last_name }}
                    </h6>
                    <a href="{{ route('roles.index') }}" class="btn btn-outline-secondary btn-sm">
                        <i class="fas fa-arrow-left me-1"></i>Retour à la liste
                    </a>
                </div>

                <form method="POST" action="{{ route('roles.update', $user) }}" class="card-body">
                    @csrf
                    @method('PATCH')

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="first_name" class="form-label fw-bold">Prénom <span class="text-danger">*</span></label>
                            <input
                                type="text"
                                class="form-control @error('first_name') is-invalid @enderror"
                                id="first_name"
                                name="first_name"
                                value="{{ old('first_name', $user->first_name) }}"
                                required
                            >
                            @error('first_name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="col-md-6">
                            <label for="last_name" class="form-label fw-bold">Nom <span class="text-danger">*</span></label>
                            <input
                                type="text"
                                class="form-control @error('last_name') is-invalid @enderror"
                                id="last_name"
                                name="last_name"
                                value="{{ old('last_name', $user->last_name) }}"
                                required
                            >
                            @error('last_name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="col-12">
                            <label for="email" class="form-label fw-bold">Email <span class="text-danger">*</span></label>
                            <input
                                type="email"
                                class="form-control @error('email') is-invalid @enderror"
                                id="email"
                                name="email"
                                value="{{ old('email', $user->email) }}"
                                required
                            >
                            @error('email')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="col-12">
                            <label for="password" class="form-label fw-bold">Nouveau mot de passe</label>
                            <div class="input-group">
                                <input
                                    type="password"
                                    class="form-control @error('password') is-invalid @enderror"
                                    id="password"
                                    name="password"
                                    placeholder="Laisser vide pour garder le mot de passe actuel"
                                >
                                <button type="button" class="btn btn-outline-secondary password-toggle-btn" id="togglePasswordBtn">
                                    <i class="fas fa-eye me-1"></i>
                                    <span id="togglePasswordLabel">Afficher</span>
                                </button>
                                @error('password')
                                    <div class="invalid-feedback d-block">{{ $message }}</div>
                                @enderror
                            </div>
                            <small class="text-muted">Le mot de passe actuel ne peut pas être affiché pour des raisons de sécurité.</small>
                        </div>

                        <div class="col-12">
                            <hr class="my-2">
                            <label class="form-label fw-bold">Pages autorisées</label>
                            <small class="d-block text-muted mb-2">Cochez les pages accessibles pour cet utilisateur.</small>

                            @php
                                $userPermissionIds = $user->roles->flatMap(fn($role) => $role->permissions->pluck('id'))->unique()->values()->toArray();
                                $oldPermissionIds = old('permissions', $userPermissionIds);
                            @endphp

                            <div class="permissions-grid">
                                @foreach($permissions as $permission)
                                    <label class="permission-item">
                                        <input
                                            type="checkbox"
                                            class="form-check-input me-2"
                                            name="permissions[]"
                                            value="{{ $permission->id }}"
                                            {{ in_array($permission->id, $oldPermissionIds) ? 'checked' : '' }}
                                        >
                                        <span class="fw-500">{{ $permission->name }}</span>
                                        <small class="d-block text-muted">{{ $permission->description }}</small>
                                    </label>
                                @endforeach
                            </div>
                            @error('permissions.*')
                                <div class="text-danger small mt-2">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <div class="d-flex gap-2 mt-4 pt-3 border-top">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Enregistrer les modifications
                        </button>
                        <button type="button" id="cancelBtn" data-cancel-url="{{ route('roles.index') }}" class="btn btn-outline-secondary">
                            <i class="fas fa-times me-1"></i>Annuler
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@section('styles')
<style>
    .permissions-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 0.75rem;
    }

    .permission-item {
        border: 1px solid #dee2e6;
        border-radius: 0.375rem;
        padding: 0.75rem;
        background: #f8f9fa;
        cursor: pointer;
    }

    .permission-item:hover {
        border-color: #0d6efd;
        background: #fff;
    }

    .fw-500 {
        font-weight: 500;
    }

    .password-toggle-btn {
        min-width: 120px;
        font-weight: 500;
    }

    @media (max-width: 767px) {
        .permissions-grid {
            grid-template-columns: 1fr;
        }
    }
</style>
@endsection

@section('scripts')
<script>
    const togglePasswordBtn = document.getElementById('togglePasswordBtn');
    const passwordInput = document.getElementById('password');
    const togglePasswordLabel = document.getElementById('togglePasswordLabel');
    const form = document.querySelector("form[action='{{ route('roles.update', $user) }}']");
    const cancelBtn = document.getElementById('cancelBtn');
    const initialFormState = new URLSearchParams(new FormData(form)).toString();

    function hasFormChanges() {
        const currentFormState = new URLSearchParams(new FormData(form)).toString();
        return currentFormState !== initialFormState;
    }

    function updateCancelButtonState() {
        const isDirty = hasFormChanges();
        cancelBtn.classList.toggle('btn-danger', isDirty);
        cancelBtn.classList.toggle('btn-outline-secondary', !isDirty);
    }

    togglePasswordBtn.addEventListener('click', function () {
        const isHidden = passwordInput.type === 'password';
        passwordInput.type = isHidden ? 'text' : 'password';
        togglePasswordBtn.querySelector('i').className = isHidden
            ? 'fas fa-eye-slash me-1'
            : 'fas fa-eye me-1';
        togglePasswordLabel.textContent = isHidden ? 'Masquer' : 'Afficher';
    });

    form.addEventListener('input', updateCancelButtonState);
    form.addEventListener('change', updateCancelButtonState);

    cancelBtn.addEventListener('click', function (event) {
        event.preventDefault();
        const cancelUrl = cancelBtn.dataset.cancelUrl;

        if (!hasFormChanges()) {
            window.location.href = cancelUrl;
            return;
        }

        const confirmLink = document.createElement('a');
        confirmLink.href = cancelUrl;
        confirmLink.dataset.confirmUrl = cancelUrl;
        confirmLink.dataset.confirmType = 'warning';
        confirmLink.dataset.confirmTitle = 'Annuler les modifications';
        confirmLink.dataset.confirmMessage = 'Des modifications non enregistrees existent. Voulez-vous vraiment annuler ?';
        confirmLink.dataset.confirmCancelLabel = 'Rester';
        confirmLink.dataset.confirmApproveLabel = 'Quitter';
        confirmLink.style.display = 'none';
        document.body.appendChild(confirmLink);
        confirmLink.click();
        confirmLink.remove();
    });
</script>
@endsection
