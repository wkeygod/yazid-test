#!/bin/sh
set -e

# Met en cache la config/les routes maintenant, avec les vraies variables
# d'environnement du conteneur (DB_HOST, DB_PASSWORD, etc.). Le faire au
# build (comme avant) figerait les valeurs de .env.example et ignorerait
# silencieusement tout -e / docker-compose environment au demarrage.
php artisan config:clear
php artisan config:cache
php artisan route:cache

# Lance le planificateur Laravel (backup:database et futures tâches
# planifiées via Schedule dans routes/console.php) en arriere-plan.
cron

exec apache2-foreground
