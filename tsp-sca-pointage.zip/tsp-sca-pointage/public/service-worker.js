const CACHE_NAME = 'sca-pointage-v9';
const APP_SHELL = [
    '/offline.html',
    '/assets/logo-sca.JPG',
    '/favicon.png',
    '/icons/icon-48.png',
    '/icons/icon-96.png',
    '/icons/icon-144.png',
    '/icons/icon-192.png',
    '/icons/icon-512.png'
];

self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then((cache) => cache.addAll(APP_SHELL))
            .then(() => self.skipWaiting())
    );
});

self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((keys) => Promise.all(
            keys
                .filter((key) => key !== CACHE_NAME)
                .map((key) => caches.delete(key))
        )).then(() => self.clients.claim())
    );
});

self.addEventListener('fetch', (event) => {
    const request = event.request;
    const url = new URL(request.url);

    if (request.method !== 'GET') {
        return;
    }

    if (url.origin === self.location.origin && (
        url.pathname === '/manifest.webmanifest' ||
        url.pathname.startsWith('/icons/')
    )) {
        event.respondWith(
            fetch(request).catch(() => caches.match(request))
        );
        return;
    }

    if (request.mode === 'navigate') {
        event.respondWith(
            fetch(request)
                .catch(() => caches.match('/offline.html'))
        );
        return;
    }

    event.respondWith(
        caches.match(request).then((cached) => cached || fetch(request).then((response) => {
            if (!response || response.status !== 200 || response.type === 'opaque') {
                return response;
            }

            const copy = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
            return response;
        }))
    );
});
